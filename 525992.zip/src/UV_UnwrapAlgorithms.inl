// UV unwrap algorithms and xatlas integration. Included by Viewport.cpp; do not compile separately.
#include "UVAtlasPacking.h"

// A closed, nearly spherical genus-zero mesh has a useful deterministic cut:
// one pole-to-pole edge path. Mapping its two banks to U=0 and U=1 creates a
// single rectangular UV island instead of letting automatic chart growth
// fragment a smooth sphere into dozens of tiny charts. Other meshes continue
// through xatlas below.
static bool kuroBuildOrganicSphereUV(const Mesh& m,
                                     std::vector<std::pair<float,float>>& outUV,
                                     std::string& reason,
                                     uint32_t& outSeamVertices) {
    outSeamVertices=0;
    const size_t vertexCount=m.vertices.size(), faceCount=m.faces.size();
    // Also admit low-poly spherical cages (for example a spherized cube with
    // only eight large corner patches). Their face normals are necessarily
    // discontinuous, so the old minimum-size/crease gate incorrectly sent
    // them to generic chart growth even when their vertices lie on a sphere.
    if(vertexCount<6||faceCount<8||vertexCount>200000u||faceCount>300000u||m.uniqueEdges.empty()||
       m.edgeFaceOffsets.size()!=m.uniqueEdges.size()+1u||m.edgeFaceOffsets.back()!=m.edgeFaces.size()) return false;
    // The runtime UV island graph uses indexed geometric edges. Do not apply
    // this path to meshes that only become manifold after welding coincident
    // positions: those would still be disconnected in the editor's real graph.
    if(int64_t(vertexCount)-int64_t(m.uniqueEdges.size())+int64_t(faceCount)!=2) return false;
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei)
        if(m.edgeFaceOffsets[ei+1u]-m.edgeFaceOffsets[ei]!=2u)return false;
    if(m.faceNormals.size()!=faceCount)return false;
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
        const uint32_t begin=m.edgeFaceOffsets[ei];
        const int fa=m.edgeFaces[begin],fb=m.edgeFaces[begin+1u];
        if(fa<0||fb<0||(size_t)fa>=faceCount||(size_t)fb>=faceCount)return false;
    }

    Vec3 lo=m.vertices[0],hi=m.vertices[0];
    for(size_t i=1;i<vertexCount;++i){const Vec3 p=m.vertices[i];
        lo.x=std::min(lo.x,p.x);lo.y=std::min(lo.y,p.y);lo.z=std::min(lo.z,p.z);
        hi.x=std::max(hi.x,p.x);hi.y=std::max(hi.y,p.y);hi.z=std::max(hi.z,p.z);
    }
    const Vec3 center=(lo+hi)*0.5f;
    const float ext[3]={hi.x-lo.x,hi.y-lo.y,hi.z-lo.z};
    const float diagonal=std::sqrt(ext[0]*ext[0]+ext[1]*ext[1]+ext[2]*ext[2]);
    if(diagonal<1.0e-7f)return false;

    // This specialized route requires a genuinely closed indexed sphere. The
    // built-in primitive now uses shared pole vertices, so no position welding
    // or identity remap is needed: logical vertex IDs and positions are exactly
    // the mesh's original vertex IDs and positions. Use the source arrays
    // directly instead of allocating and copying two full-size identity buffers.
    const size_t logicalCount=vertexCount;
    if(logicalCount<6)return false;

    std::vector<uint8_t> logicalUsed(logicalCount,0);
    // Reject non-spherical candidates before allocating the ordered edge map
    // and per-face polygon scratch. This preliminary scan only validates face
    // indices and marks referenced vertices; full polygon/manifold validation
    // below remains authoritative for candidates that pass the geometric gate.
    for(const auto& face:m.faces){
        if(face.size()<3)return false;
        for(uint32_t vi:face){if(vi>=vertexCount)return false;logicalUsed[vi]=1;}
    }
    std::vector<Vec3> radial(logicalCount);
    std::vector<float> radius(logicalCount,0.0f);
    double radiusSum=0.0;size_t radiusN=0;
    for(uint32_t i=0;i<logicalCount;++i)if(logicalUsed[i]){
        radial[i]=m.vertices[i]-center;radius[i]=std::sqrt(len2(radial[i]));
        if(radius[i]<1.0e-7f)return false;
        radiusSum+=radius[i];++radiusN;
    }
    const double meanRadius=radiusSum/double(std::max<size_t>(1,radiusN));
    double variance=0.0;float minRadius=std::numeric_limits<float>::max(),maxRadius=0.0f;
    for(uint32_t i=0;i<logicalCount;++i)if(logicalUsed[i]){
        const double d=double(radius[i])-meanRadius;variance+=d*d;
        minRadius=std::min(minRadius,radius[i]);maxRadius=std::max(maxRadius,radius[i]);
    }
    const double radialCV=std::sqrt(variance/double(std::max<size_t>(1,radiusN)))/meanRadius;
    if(radialCV>0.20||minRadius/maxRadius<0.58f)return false;

    // Radius alone cannot distinguish a cube from a sphere: all cube corners
    // are equidistant from its center. Keep the normal-fit gate before the
    // expensive edge-map construction too.
    double meanRadialNormalFit=0.0;
    if(!kuro::uvunwrap::passesLowPolySphereGate(m.vertices,m.faces,m.faceNormals,center,&meanRadialNormalFit))return false;

    struct LogicalEdge {uint32_t a,b;};
    std::map<std::pair<uint32_t,uint32_t>,uint32_t> edgeLookup;
    std::vector<LogicalEdge> logicalEdges;
    std::vector<uint32_t> edgeUseCount;
    size_t validFaceCount=0;
    for(const auto& face:m.faces){
        std::vector<uint32_t> poly;poly.reserve(face.size());
        for(uint32_t vi:face){const uint32_t li=vi;
            if(poly.empty()||poly.back()!=li)poly.push_back(li);
        }
        if(poly.size()>1&&poly.front()==poly.back())poly.pop_back();
        std::vector<uint32_t> distinct=poly;std::sort(distinct.begin(),distinct.end());
        distinct.erase(std::unique(distinct.begin(),distinct.end()),distinct.end());
        if(distinct.size()<3)return false;
        ++validFaceCount;
        for(size_t k=0;k<poly.size();++k){
            uint32_t a=poly[k],b=poly[(k+1)%poly.size()];if(a==b)continue;if(a>b)std::swap(a,b);
            const auto key=std::make_pair(a,b);auto it=edgeLookup.find(key);
            if(it==edgeLookup.end()){const uint32_t id=(uint32_t)logicalEdges.size();edgeLookup.emplace(key,id);logicalEdges.push_back({a,b});edgeUseCount.push_back(1u);}
            else ++edgeUseCount[it->second];
        }
    }
    size_t usedLogical=0;for(uint8_t b:logicalUsed)usedLogical+=b?1u:0u;
    if(int64_t(usedLogical)-int64_t(logicalEdges.size())+int64_t(validFaceCount)!=2)return false;
    for(uint32_t uses:edgeUseCount)if(uses!=2u)return false;

    int axisIndex=2; // Kuro3D uses Z-up; keep deterministic for nearly equal extents.
    if(ext[0]>ext[axisIndex]*1.025f)axisIndex=0;
    if(ext[1]>ext[axisIndex]*1.025f)axisIndex=1;
    const Vec3 axis=axisIndex==0?Vec3{1,0,0}:(axisIndex==1?Vec3{0,1,0}:Vec3{0,0,1});
    const Vec3 seamDir=axisIndex==0?Vec3{0,1,0}:(axisIndex==1?Vec3{0,0,1}:Vec3{1,0,0});
    const Vec3 sideDir=normalize(cross(axis,seamDir));

    uint32_t start=UINT32_MAX,goal=UINT32_MAX;float bestTop=-2.0f,bestBottom=2.0f;
    for(uint32_t i=0;i<logicalCount;++i)if(logicalUsed[i]){
        const float h=dot(radial[i],axis)/radius[i];
        if(h>bestTop){bestTop=h;start=i;}if(h<bestBottom){bestBottom=h;goal=i;}
    }
    if(start==UINT32_MAX||goal==UINT32_MAX||start==goal)return false;

    std::vector<uint32_t> degree(logicalCount,0),offset(logicalCount+1u,0);
    for(const auto& e:logicalEdges){++degree[e.a];++degree[e.b];}
    for(size_t i=0;i<logicalCount;++i)offset[i+1u]=offset[i]+degree[i];
    std::vector<uint32_t> cursor=offset,neighbors(offset.back());
    for(const auto& e:logicalEdges){neighbors[cursor[e.a]++]=e.b;neighbors[cursor[e.b]++]=e.a;}
    const float inf=std::numeric_limits<float>::infinity();
    std::vector<float> dist(logicalCount,inf);std::vector<uint32_t> parent(logicalCount,UINT32_MAX);
    using QueueItem=std::pair<float,uint32_t>;
    std::priority_queue<QueueItem,std::vector<QueueItem>,std::greater<QueueItem>> heap;
    dist[start]=0.0f;heap.push({0.0f,start});
    while(!heap.empty()){
        const auto item=heap.top();heap.pop();const float d=item.first;const uint32_t v=item.second;
        if(d!=dist[v])continue;
        if(v==goal)break;
        for(uint32_t k=offset[v];k<offset[v+1u];++k){
            const uint32_t n=neighbors[k];
            const Vec3 h0=radial[v]-axis*dot(radial[v],axis),h1=radial[n]-axis*dot(radial[n],axis);
            float align=0.0f;if(len2(h0)>1.0e-10f&&len2(h1)>1.0e-10f)align=std::clamp(dot(normalize(h0+h1),seamDir),-1.0f,1.0f);
            const float edgeLength=std::sqrt(len2(m.vertices[n]-m.vertices[v]));
            const float nd=d+std::max(edgeLength,1.0e-7f)*(1.0f+10.0f*(1.0f-align)*(1.0f-align));
            if(nd<dist[n]){dist[n]=nd;parent[n]=v;heap.push({nd,n});}
        }
    }
    if(!std::isfinite(dist[goal]))return false;
    std::vector<uint8_t> onCut(logicalCount,0);
    std::unordered_set<uint64_t> cutEdgeKeys;
    uint32_t v=goal;size_t pathGuard=0;
    while(v!=UINT32_MAX&&pathGuard++<=logicalCount){
        onCut[v]=1;
        if(v==start)break;
        const uint32_t p=parent[v];if(p==UINT32_MAX)break;
        const uint32_t a=std::min(v,p),b=std::max(v,p);
        cutEdgeKeys.insert((uint64_t(a)<<32)|b);
        v=p;
    }
    if(!onCut[start]||pathGuard>logicalCount||cutEdgeKeys.empty())return false;
    for(uint8_t b:onCut)outSeamVertices+=b?1u:0u;
    if(outSeamVertices<3u)return false;

    size_t totalCorners=0;for(const auto& f:m.faces)totalCorners+=f.size();
    outUV.assign(totalCorners,{0.0f,0.0f});
    const float margin=kuro::uvpacking::kOuterMargin,scale=kuro::uvpacking::kInteriorScale;
    size_t base=0;
    for(const auto& face:m.faces){
        double sideSum=0.0;
        for(uint32_t vi:face){const uint32_t li=vi;const float h=std::fabs(dot(radial[li],axis))/radius[li];if(h<0.99999f)sideSum+=dot(radial[li],sideDir)/radius[li];}
        // A diagonal low-poly patch can straddle the seam and have a nearly
        // zero signed average. Resolve that tie from its strongest non-pole
        // vertex instead of arbitrarily assigning every such face to U=1.
        float strongestSide=0.0f;
        for(uint32_t vi:face){const uint32_t li=vi;const float h=std::fabs(dot(radial[li],axis))/radius[li];
            if(h<0.99999f){const float side=dot(radial[li],sideDir)/radius[li];if(std::fabs(side)>std::fabs(strongestSide))strongestSide=side;}}
        const float faceSide=(std::fabs(sideSum)>1.0e-5?sideSum:strongestSide)>=0.0f?1.0f:-1.0f;
        std::vector<float> faceU(face.size(),0.5f),faceV(face.size(),0.5f);
        float minU=1.0f,maxU=0.0f;
        for(size_t k=0;k<face.size();++k){
            const uint32_t li=face[k];const Vec3 r=radial[li];
            const float h=std::clamp(dot(r,axis)/radius[li],-1.0f,1.0f);
            // Equal-area latitude: for a sphere, UV area tracks surface area instead of
            // over-allocating texels to the compressed polar regions.
            faceV[k]=0.5f*(1.0f-h);
            if(std::fabs(h)>0.99999f){faceU[k]=0.5f;continue;}
            const float x=-dot(r,seamDir),y=dot(r,sideDir);
            float u=std::atan2(y,x)/6.28318530717958647692f+0.5f;
            const float horizontalLength=std::sqrt(std::max(1.0e-12f,radius[li]*radius[li]-dot(r,axis)*dot(r,axis)));
            if(onCut[li]&&dot(r,seamDir)/horizontalLength>0.70f&&std::fabs(y)/horizontalLength<0.16f)
                u=faceSide>0.0f?1.0f:0.0f;
            faceU[k]=u;minU=std::min(minU,u);maxU=std::max(maxU,u);
        }
        if(maxU-minU>0.55f){outUV.clear();return false;}
        for(size_t k=0;k<face.size();++k)outUV[base+k]={margin+faceU[k]*scale,margin+faceV[k]*scale};
        base+=face.size();
    }
    // Validate the generated UV graph exactly as the UV editor consumes it.
    // Every non-cut geometric edge must match at both endpoints; every edge in
    // the cut path must be discontinuous. The remaining face graph must be one
    // connected disk, not several accidental islands.
    std::vector<uint32_t> faceBase(faceCount+1u,0u);
    for(size_t fi=0;fi<faceCount;++fi)faceBase[fi+1u]=faceBase[fi]+(uint32_t)m.faces[fi].size();
    auto findFaceCorner=[&](int fi,uint32_t vi)->size_t{
        if(fi<0||(size_t)fi>=faceCount)return SIZE_MAX;
        const auto& f=m.faces[(size_t)fi];
        for(size_t k=0;k<f.size();++k)if(f[k]==vi)return (size_t)faceBase[(size_t)fi]+k;
        return SIZE_MAX;
    };
    auto uvMatch=[&](size_t a,size_t b){return a<outUV.size()&&b<outUV.size()&&
        std::fabs(outUV[a].first-outUV[b].first)<1.0e-5f&&std::fabs(outUV[a].second-outUV[b].second)<1.0e-5f;};
    std::vector<std::vector<int>> faceAdj(faceCount);
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
        const auto edge=m.uniqueEdges[ei];
        const uint32_t begin=m.edgeFaceOffsets[ei],end=m.edgeFaceOffsets[ei+1u];
        if(end-begin!=2u){outUV.clear();return false;}
        const int fa=m.edgeFaces[begin],fb=m.edgeFaces[begin+1u];
        const size_t a0=findFaceCorner(fa,edge.first),a1=findFaceCorner(fa,edge.second);
        const size_t b0=findFaceCorner(fb,edge.first),b1=findFaceCorner(fb,edge.second);
        if(a0==SIZE_MAX||a1==SIZE_MAX||b0==SIZE_MAX||b1==SIZE_MAX){outUV.clear();return false;}
        const bool continuous=uvMatch(a0,b0)&&uvMatch(a1,b1);
        const uint32_t loV=std::min(edge.first,edge.second);
        const uint32_t hiV=std::max(edge.first,edge.second);
        const bool isCut=cutEdgeKeys.find((uint64_t(loV)<<32)|hiV)!=cutEdgeKeys.end();
        if((isCut&&continuous)||(!isCut&&!continuous)){outUV.clear();return false;}
        if(continuous){faceAdj[(size_t)fa].push_back(fb);faceAdj[(size_t)fb].push_back(fa);}
    }
    std::vector<uint8_t> visited(faceCount,0);std::vector<uint32_t> stack;stack.reserve(faceCount);
    stack.push_back(0u);visited[0]=1;size_t reached=0;
    while(!stack.empty()){
        const uint32_t f=stack.back();stack.pop_back();++reached;
        for(int n:faceAdj[f])if(n>=0&&(size_t)n<faceCount&&!visited[(size_t)n]){visited[(size_t)n]=1;stack.push_back((uint32_t)n);}
    }
    if(reached!=faceCount){outUV.clear();return false;}

    // The parameterization must not collapse or flip any source triangle.
    int winding=0;
    for(size_t ti=0;ti<m.triangleFaces.size()&&ti*3u+2u<m.indices.size();++ti){
        const int fi=m.triangleFaces[ti];
        const size_t ca=findFaceCorner(fi,m.indices[ti*3u]);
        const size_t cb=findFaceCorner(fi,m.indices[ti*3u+1u]);
        const size_t cc=findFaceCorner(fi,m.indices[ti*3u+2u]);
        if(ca==SIZE_MAX||cb==SIZE_MAX||cc==SIZE_MAX){outUV.clear();return false;}
        const auto& a=outUV[ca];const auto& b=outUV[cb];const auto& c=outUV[cc];
        const float area=(b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
        if(!std::isfinite(area)||std::fabs(area)<1.0e-10f){outUV.clear();return false;}
        const int sign=area>0.0f?1:-1;if(winding==0)winding=sign;else if(winding!=sign){outUV.clear();return false;}
    }
    reason="closed sphere-like mesh: pole-to-pole edge cut, single connected UV island, no flipped triangles";
    return true;
}

void App::autoUnwrapSelected(){
    kuroSetCrashContext("App::autoUnwrapSelected: enter");
    // Auto unwrap keeps the existing automatic sharp-fold splitting in addition to user seams.
    autoUnwrapSelectedBySeams(false);
}

void App::unwrapByMarkedSeamsSelected(){
    kuroSetCrashContext("App::unwrapByMarkedSeamsSelected: enter");
    // Mark Seams always rebuilds the complete chart layout through xatlas.
    // That pipeline emits authoritative per-triangle-corner UVs and a fresh
    // independent UV vertex pool when chart boundaries split polygon corners.
    // It is therefore safe for an already-independent layout; unlike the old
    // projection path, it never edits only the faceCornerUV compatibility view.
    autoUnwrapSelectedBySeams(true);
}

// Projection-based UV methods share the same per-polygon-corner storage as
// xatlas. Each selected face is evaluated independently so cylindrical and
// spherical seams can split a shared geometric vertex without corrupting
// neighboring faces. projectionKind: 0=From View, 1=Box, 2=Cylindrical, 3=Spherical.
void App::projectUVSelected(int projectionKind){
    Object* object=scene.selected();
    if(!object){setStatus("UV Projection: select an object");return;}
    Mesh& mesh=object->mesh;
    const bool independentUV=mesh.triangleCornerUVIndependent;
    if(mesh.faces.empty()||mesh.vertices.empty()){setStatus("UV Projection: empty mesh");return;}
    if(projectionKind<0||projectionKind>3)return;

    std::vector<uint8_t> selected(mesh.faces.size(),0u);
    bool hasExplicitSelection=false;
    for(int fi:uvSelectedFaces)if(fi>=0&&(size_t)fi<selected.size()){selected[(size_t)fi]=1u;hasExplicitSelection=true;}
    std::vector<uint32_t> cornerBase(mesh.faces.size()+1u,0u);
    for(size_t fi=0;fi<mesh.faces.size();++fi){
        const size_t count=mesh.faces[fi].size();
        if(count>UINT32_MAX-cornerBase[fi]){setStatus("UV Projection: mesh is too large");return;}
        cornerBase[fi+1u]=cornerBase[fi]+(uint32_t)count;
    }
    const size_t cornerCount=cornerBase.back();
    if(!cornerCount){setStatus("UV Projection: no polygon corners");return;}
    if(!hasExplicitSelection&&!uvSelectedCorners.empty()){
        std::vector<uint8_t> cornerMask(cornerCount,0u);
        for(int ci:uvSelectedCorners)if(ci>=0&&(size_t)ci<cornerCount)cornerMask[(size_t)ci]=1u;
        for(size_t fi=0;fi<mesh.faces.size();++fi)for(uint32_t k=cornerBase[fi];k<cornerBase[fi+1u];++k)if(cornerMask[k]){selected[fi]=1u;hasExplicitSelection=true;break;}
    }
    if(!hasExplicitSelection&&!uvSelectedEdges.empty()){
        for(size_t fi=0;fi<mesh.faces.size();++fi){
            const uint32_t base=cornerBase[fi],count=cornerBase[fi+1u]-base;
            for(uint32_t k=0;k<count;++k){const int a=(int)(base+k),b=(int)(base+(k+1u)%count);
                for(const auto& edge:uvSelectedEdges)if((edge.first==a&&edge.second==b)||(edge.first==b&&edge.second==a)){selected[fi]=1u;hasExplicitSelection=true;break;}
                if(selected[fi])break;
            }
        }
    }
    if(!hasExplicitSelection&&mode==SelectionMode::Face){
        for(int fi:object->selectedFaces)if(fi>=0&&(size_t)fi<selected.size()){selected[(size_t)fi]=1u;hasExplicitSelection=true;}
    }
    if(!hasExplicitSelection)std::fill(selected.begin(),selected.end(),1u);

    // Projection basis matches the renderer's orbit camera exactly: no roll,
    // world Z is up, and yaw supplies a stable right vector even at the poles.
    const Vec3 cameraPosition=target+Vec3{distance*std::cos(pitch)*std::sin(yaw),
        distance*std::cos(pitch)*std::cos(yaw),distance*std::sin(pitch)};
    const Vec3 forward=normalize(target-cameraPosition);
    const Vec3 right=normalize(Vec3{-std::cos(yaw),std::sin(yaw),0.0f});
    const Vec3 up=normalize(cross(right,forward));
    const float aspect=std::max(0.1f,ImGui::GetIO().DisplaySize.x/std::max(1.0f,ImGui::GetIO().DisplaySize.y));
    const float tanHalf=std::tan(45.0f*float(M_PI)/360.0f);
    const float orthoHalf=std::max(0.001f,distance*tanHalf);

    Vec3 boundsMin=mesh.vertices[0],boundsMax=mesh.vertices[0];
    bool haveBounds=false;
    auto include=[&](Vec3 p){if(!haveBounds){boundsMin=boundsMax=p;haveBounds=true;}else{
        boundsMin.x=std::min(boundsMin.x,p.x);boundsMin.y=std::min(boundsMin.y,p.y);boundsMin.z=std::min(boundsMin.z,p.z);
        boundsMax.x=std::max(boundsMax.x,p.x);boundsMax.y=std::max(boundsMax.y,p.y);boundsMax.z=std::max(boundsMax.z,p.z);}};
    // Bounds for primitive projections are computed only from the selected
    // surface, so projecting a few faces does not inherit the object's origin.
    for(size_t fi=0;fi<mesh.faces.size();++fi)if(selected[fi])for(uint32_t vi:mesh.faces[fi])if(vi<mesh.vertices.size())include(mesh.vertices[vi]);
    if(!haveBounds){setStatus("UV Projection: no valid selected faces");return;}
    std::vector<uint8_t> valid(cornerCount,0u);
    std::vector<float> rawU(cornerCount,0.0f),rawV(cornerCount,0.0f);
    for(size_t fi=0;fi<mesh.faces.size();++fi){if(!selected[fi])continue;
        const auto& face=mesh.faces[fi];if(face.size()<3)continue;
        Vec3 normal{};bool normalFound=false;
        for(size_t a=0;a<face.size()&&!normalFound;++a)for(size_t b=a+1;b<face.size()&&!normalFound;++b)for(size_t c=b+1;c<face.size();++c){
            if(face[a]>=mesh.vertices.size()||face[b]>=mesh.vertices.size()||face[c]>=mesh.vertices.size())continue;
            Vec3 n=cross(mesh.vertices[b]-mesh.vertices[a],mesh.vertices[c]-mesh.vertices[a]);
            if(len2(n)>1.0e-12f){normal=normalize(n);normalFound=true;break;}}
        const float ax=std::fabs(normal.x),ay=std::fabs(normal.y),az=std::fabs(normal.z);
        for(size_t k=0;k<face.size();++k){const uint32_t vi=face[k];if(vi>=mesh.vertices.size())continue;
            const size_t ci=(size_t)cornerBase[fi]+k;const Vec3 local=mesh.vertices[vi];Vec3 p{};
            if(projectionKind==0){
                const Vec3 worldPos=world(*object,local),delta=worldPos-cameraPosition;
                const float depth=dot(delta,forward);
                if(orthographicProjection){p={dot(worldPos-target,right)/orthoHalf/aspect,dot(worldPos-target,up)/orthoHalf,0.0f};}
                else {const float safeDepth=(std::fabs(depth)<0.02f)?(depth<0.0f?-0.02f:0.02f):depth;
                    p={dot(delta,right)/(safeDepth*tanHalf*aspect),dot(delta,up)/(safeDepth*tanHalf),0.0f};}
            }else if(projectionKind==1){
                // A 4x3 cube cross keeps the six sides as independent islands
                // instead of stacking opposite faces on top of each other.
                const float nx=std::max(1.0e-6f,boundsMax.x-boundsMin.x);
                const float ny=std::max(1.0e-6f,boundsMax.y-boundsMin.y);
                const float nz=std::max(1.0e-6f,boundsMax.z-boundsMin.z);
                float u=0.0f,v=0.0f;int cellX=1,cellY=1;
                if(ax>=ay&&ax>=az){u=(local.y-boundsMin.y)/ny;v=(local.z-boundsMin.z)/nz;cellX=normal.x>=0.0f?2:0;cellY=1;}
                else if(ay>=ax&&ay>=az){u=(local.x-boundsMin.x)/nx;v=(local.z-boundsMin.z)/nz;cellX=normal.y>=0.0f?1:3;cellY=1;}
                else {u=(local.x-boundsMin.x)/nx;v=(local.y-boundsMin.y)/ny;cellX=1;cellY=normal.z>=0.0f?0:2;}
                p={(float(cellX)+0.02f+u*0.96f)/4.0f,(float(cellY)+0.02f+v*0.96f)/3.0f,0.0f};
            }else if(projectionKind==2){
                p={std::atan2(local.y,local.x)/(2.0f*float(M_PI))+0.5f,local.z,0};
            }else{
                const Vec3 center=(boundsMin+boundsMax)*0.5f;const Vec3 d=local-center;
                const float radius=std::sqrt(std::max(1.0e-20f,len2(d)));
                p={std::atan2(d.y,d.x)/(2.0f*float(M_PI))+0.5f,
                   std::acos(std::clamp(d.z/radius,-1.0f,1.0f))/float(M_PI),0};
            }
            valid[ci]=1u;
            if(projectionKind==0||projectionKind==1){rawU[ci]=p.x;rawV[ci]=p.y;}
        }
    }
    // Never write only part of a polygon when an imported face contains an
    // invalid vertex index. Leave that entire face's existing UVs untouched.
    for(size_t fi=0;fi<mesh.faces.size();++fi)if(selected[fi]){
        bool complete=mesh.faces[fi].size()>=3;
        for(size_t k=0;k<mesh.faces[fi].size()&&complete;++k)complete=valid[(size_t)cornerBase[fi]+k]!=0u;
        if(!complete)for(size_t k=0;k<mesh.faces[fi].size();++k)valid[(size_t)cornerBase[fi]+k]=0u;
    }
    if(projectionKind>=2){
        // Use the selected surface's local-space bounds for axial height and
        // spherical center; this remains stable for partial face selections.
        const Vec3 center=(boundsMin+boundsMax)*0.5f;const float zRange=std::max(1.0e-6f,boundsMax.z-boundsMin.z);
        for(size_t fi=0;fi<mesh.faces.size();++fi)if(selected[fi])for(size_t k=0;k<mesh.faces[fi].size();++k){const size_t ci=(size_t)cornerBase[fi]+k;if(!valid[ci])continue;const Vec3 d=mesh.vertices[mesh.faces[fi][k]]-center;
            if(projectionKind==2){rawU[ci]=std::atan2(d.y,d.x)/(2.0f*float(M_PI))+0.5f;rawV[ci]=(mesh.vertices[mesh.faces[fi][k]].z-boundsMin.z)/zRange;}
            else {const float radius=std::sqrt(std::max(1.0e-20f,len2(d)));rawU[ci]=std::atan2(d.y,d.x)/(2.0f*float(M_PI))+0.5f;rawV[ci]=std::acos(std::clamp(d.z/radius,-1.0f,1.0f))/float(M_PI);}
        }
    }
    // Per-face longitude unwrap: avoid a long UV edge across the 0/1 seam.
    if(projectionKind>=2)for(size_t fi=0;fi<mesh.faces.size();++fi)if(selected[fi]){
        float lo=1.0f,hi=0.0f;for(size_t k=0;k<mesh.faces[fi].size();++k){size_t ci=(size_t)cornerBase[fi]+k;if(valid[ci]){lo=std::min(lo,rawU[ci]);hi=std::max(hi,rawU[ci]);}}
        if(hi-lo>0.5f)for(size_t k=0;k<mesh.faces[fi].size();++k){size_t ci=(size_t)cornerBase[fi]+k;if(valid[ci]&&rawU[ci]<0.5f)rawU[ci]+=1.0f;}
    }
    if(projectionKind==0){
        float minU=std::numeric_limits<float>::max(),minV=minU,maxU=-minU,maxV=-minU;
        for(size_t fi=0;fi<mesh.faces.size();++fi)if(selected[fi])for(size_t k=0;k<mesh.faces[fi].size();++k){size_t ci=(size_t)cornerBase[fi]+k;if(valid[ci]){minU=std::min(minU,rawU[ci]);maxU=std::max(maxU,rawU[ci]);minV=std::min(minV,rawV[ci]);maxV=std::max(maxV,rawV[ci]);}}
        const float du=std::max(1.0e-6f,maxU-minU),dv=std::max(1.0e-6f,maxV-minV);
        // Fit uniformly into the 0..1 tile. Independent X/Y scaling would
        // distort the projected silhouette whenever the viewport is not square.
        const float fit=std::max(du,dv),offsetU=(1.0f-du/fit)*0.5f,offsetV=(1.0f-dv/fit)*0.5f;
        for(size_t ci=0;ci<cornerCount;++ci)if(valid[ci]){rawU[ci]=offsetU+(rawU[ci]-minU)/fit;rawV[ci]=offsetV+(rawV[ci]-minV)/fit;}
    }else if(projectionKind==2){
        // Cylinder U already wraps; V is normalized from object bounds above.
    }
    bool any=false;for(uint8_t v:valid)if(v){any=true;break;}
    if(!any){setStatus("UV Projection: no valid selected faces");return;}
    if(independentUV){
        // Project through the authoritative triangle-corner -> polygon-corner ->
        // independent-UV-vertex mapping. Refuse ambiguous/shared ownership rather
        // than silently moving UVs belonging to an unselected face or collapsing
        // two sides of an existing internal seam.
        const size_t triCornerCount=mesh.indices.size();
        if(mesh.triangleCornerUV.size()!=triCornerCount ||
           mesh.triangleCornerUVVertexIndices.size()!=triCornerCount ||
           mesh.faceTriangleOffsets.size()!=mesh.faces.size()+1u ||
           (mesh.triangleCornerUVMapWide ? mesh.triangleCornerUVIndicesWide.size()!=triCornerCount : mesh.triangleCornerUVIndices.size()!=triCornerCount)){
            setStatus("UV Projection: independent UV corner mapping is incomplete; rebuild Auto UV first");return;
        }
        std::vector<int> idOwner(mesh.uvVertices.size(),-1);
        std::vector<std::pair<float,float>> projected(mesh.uvVertices.size(),{0.0f,0.0f});
        std::vector<uint8_t> hasProjected(mesh.uvVertices.size(),0u);
        for(size_t fi=0;fi<mesh.faces.size();++fi){
            const uint32_t tb=mesh.faceTriangleOffsets[fi],te=mesh.faceTriangleOffsets[fi+1u];
            if(te<tb||size_t(te)*3u>triCornerCount){setStatus("UV Projection: invalid independent UV face mapping");return;}
            for(uint32_t ti=tb;ti<te;++ti)for(uint32_t c=0;c<3u;++c){
                const size_t at=size_t(ti)*3u+c;
                const uint32_t local=mesh.triangleCornerUVMapWide?mesh.triangleCornerUVIndicesWide[at]:mesh.triangleCornerUVIndices[at];
                const uint32_t id=mesh.triangleCornerUVVertexIndices[at];
                if(local>=mesh.faces[fi].size()||id>=mesh.uvVertices.size()){setStatus("UV Projection: invalid independent UV vertex reference");return;}
                const bool faceSelected=selected[fi]!=0u;
                if(idOwner[id]<0)idOwner[id]=faceSelected?1:0;
                else if((idOwner[id]==1)!=faceSelected){setStatus("UV Projection: selected faces share UV vertices with unselected faces; select the complete connected UV region first");return;}
                if(!faceSelected)continue;
                const size_t ci=size_t(cornerBase[fi])+local;
                if(!valid[ci])continue;
                const std::pair<float,float> q{rawU[ci],rawV[ci]};
                if(hasProjected[id] && (std::fabs(projected[id].first-q.first)>1.0e-5f || std::fabs(projected[id].second-q.second)>1.0e-5f)){
                    setStatus("UV Projection: this projection needs an additional UV split; use Auto UV or Mark Seams first");return;
                }
                projected[id]=q;hasProjected[id]=1u;
            }
        }
        pushUndoState();
        for(size_t id=0;id<projected.size();++id)if(hasProjected[id])mesh.uvVertices[id]=projected[id];
        for(size_t at=0;at<triCornerCount;++at){const uint32_t id=mesh.triangleCornerUVVertexIndices[at];if(id<mesh.uvVertices.size())mesh.triangleCornerUV[at]=mesh.uvVertices[id];}
        if(mesh.faceCornerUV.size()!=cornerCount)mesh.faceCornerUV.resize(cornerCount,{0.0f,0.0f});
        for(size_t ci=0;ci<cornerCount;++ci)if(valid[ci])mesh.faceCornerUV[ci]={rawU[ci],rawV[ci]};
        if(!mesh.updateUVsOnly(false,nullptr,true,false,true))mesh.rebuildTriangulation();
    }else{
        pushUndoState();
        if(mesh.faceCornerUV.size()!=cornerCount)mesh.faceCornerUV.resize(cornerCount,{0.0f,0.0f});
        for(size_t ci=0;ci<cornerCount;++ci)if(valid[ci])mesh.faceCornerUV[ci]={rawU[ci],rawV[ci]};
        if(!mesh.updateUVsOnly(true,nullptr,true,false,true))mesh.rebuildTriangulation();
    }
    // UV-only updates above keep topology and adjacency caches intact.
    ++uvPickRevision;
    uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;
    const char* names[]={"From View","Box Projection","Cylindrical Projection","Spherical Projection"};
    setStatus(std::string("UV: ")+names[projectionKind]+" complete");
    logInfo("UV",std::string("projection unwrap: ")+names[projectionKind]+" corners="+std::to_string(cornerCount));
}

void App::autoUnwrapSelectedBySeams(bool seamsOnly){
    kuroSetCrashContext(seamsOnly?"App::autoUnwrapSelectedBySeams: seam-only enter":"App::autoUnwrapSelectedBySeams: automatic enter");
    kuroWriteUVTraceAt(seamsOnly?"unwrap entered: seams-only":"unwrap entered: auto",true);
    // Process every selected visible object as one undoable operation.
    static bool multiObjectUnwrapPass=false;
    if(!multiObjectUnwrapPass){
        std::vector<int> selectedObjects;
        for(int i=0;i<(int)scene.objects.size();++i)
            if(scene.objects[i].selected&&!scene.objects[i].hidden) selectedObjects.push_back(i);
        // If any selected object has component selection, process only objects
        // that actually contribute selected components. Object-only selections
        // still retain the previous whole-object multi-unwrap behavior.
        // Sort component IDs once per object: repeated linear std::find() calls
        // inside every polygon made large Vertex/Edge selections O(corners*selection).
        std::vector<std::vector<int>> sortedSelectedVertices(scene.objects.size());
        std::vector<std::vector<std::pair<int,int>>> sortedSelectedEdges(scene.objects.size());
        if(mode==SelectionMode::Vertex || mode==SelectionMode::Edge){
            for(int idx:selectedObjects){
                const Object& candidate=scene.objects[(size_t)idx];
                if(mode==SelectionMode::Vertex){
                    auto& ids=sortedSelectedVertices[(size_t)idx];
                    ids.assign(candidate.selectedVertices.begin(),candidate.selectedVertices.end());
                    std::sort(ids.begin(),ids.end());
                    ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
                }else{
                    auto& edges=sortedSelectedEdges[(size_t)idx];
                    edges.assign(candidate.selectedEdges.begin(),candidate.selectedEdges.end());
                    for(auto& edge:edges)if(edge.first>edge.second)std::swap(edge.first,edge.second);
                    std::sort(edges.begin(),edges.end());
                    edges.erase(std::unique(edges.begin(),edges.end()),edges.end());
                }
            }
        }
        auto hasRawComponentSelection=[&](const Object& candidate){
            if(mode==SelectionMode::Face)return !candidate.selectedFaces.empty();
            if(mode==SelectionMode::Edge)return !candidate.selectedEdges.empty();
            if(mode==SelectionMode::Vertex)return !candidate.selectedVertices.empty();
            return false;
        };
        auto hasComponentSelection=[&](const Object& candidate){
            const size_t objectIndex=(size_t)(&candidate-scene.objects.data());
            if(mode==SelectionMode::Face){for(int fi:candidate.selectedFaces)if(fi>=0&&(size_t)fi<candidate.mesh.faces.size())return true;}
            if(mode==SelectionMode::Vertex){
                const auto& ids=sortedSelectedVertices[objectIndex];
                for(const auto& face:candidate.mesh.faces){bool all=!face.empty();for(uint32_t vi:face)if(!std::binary_search(ids.begin(),ids.end(),(int)vi)){all=false;break;}if(all)return true;}
            }else if(mode==SelectionMode::Edge){
                const auto& edges=sortedSelectedEdges[objectIndex];
                for(const auto& face:candidate.mesh.faces){bool all=face.size()>=2;for(size_t k=0;k<face.size()&&all;++k){uint32_t a=face[k],b=face[(k+1u)%face.size()];auto edge=std::make_pair((int)std::min(a,b),(int)std::max(a,b));if(!std::binary_search(edges.begin(),edges.end(),edge))all=false;}if(all)return true;}
            }
            return false;
        };
        bool anyRawComponentSelection=false,anyComponentSelection=false;
        for(int idx:selectedObjects){const Object& candidate=scene.objects[(size_t)idx];anyRawComponentSelection=anyRawComponentSelection||hasRawComponentSelection(candidate);anyComponentSelection=anyComponentSelection||hasComponentSelection(candidate);}
        if(anyRawComponentSelection&&!anyComponentSelection){setStatus("Auto UV: select complete faces (all face vertices or edges) to unwrap a subset");return;}
        std::vector<bool> selection(scene.objects.size(),false);
        for(int i:selectedObjects)selection[(size_t)i]=true;
        if(anyComponentSelection)selectedObjects.erase(std::remove_if(selectedObjects.begin(),selectedObjects.end(),[&](int idx){return !hasComponentSelection(scene.objects[(size_t)idx]);}),selectedObjects.end());
        if(selectedObjects.size()>1||anyComponentSelection){
            pushUndoState();
            const int savedActiveObject=activeObject;
            multiObjectUnwrapPass=true;
            for(int idx:selectedObjects){
                for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=(i==idx);
                activeObject=idx;
                logInfo("UV",std::string("UV unwrap object: ")+scene.objects[idx].name);
                autoUnwrapSelectedBySeams(seamsOnly);
            }
            for(int i=0;i<(int)scene.objects.size();++i) scene.objects[i].selected=selection[(size_t)i];
            if(savedActiveObject>=0&&savedActiveObject<(int)scene.objects.size()&&scene.objects[savedActiveObject].selected) activeObject=savedActiveObject;
            else if(!selectedObjects.empty()) activeObject=selectedObjects.front();
            multiObjectUnwrapPass=false;
            setStatus(seamsOnly?"UV Unwrap: selected objects ready":"Auto UV: selected objects ready");
            return;
        }
    }

    Object* o=scene.selected();
    if(!o){setStatus("Auto UV: select an object");return;}
    Mesh& m=o->mesh;
    {std::ostringstream trace;trace<<"source mesh: vertices="<<m.vertices.size()<<" faces="<<m.faces.size()<<" edges="<<m.uniqueEdges.size()<<" seamsOnly="<<seamsOnly;kuroWriteUVTraceAt(trace.str().c_str());}
    if(m.faces.empty()||m.vertices.empty()){setStatus("Auto UV: empty mesh");kuroWriteUVTraceAt("abort: empty mesh");return;}

    // In Face mode, unwrap only the explicitly selected model faces. Run the
    // existing, fully validated xatlas pipeline on a temporary face subset so
    // every unselected polygon keeps its exact corner UVs and island placement.
    // The original mesh is restored before the single undo snapshot is created.
    static bool selectedFaceUnwrapPass=false;
    if(!selectedFaceUnwrapPass){
        std::vector<int> sourceFaces;
        std::vector<uint8_t> faceMask(m.faces.size(),0u);
        auto addSourceFace=[&](int fi){if(fi>=0&&(size_t)fi<m.faces.size()&&!faceMask[(size_t)fi]){faceMask[(size_t)fi]=1u;sourceFaces.push_back(fi);}};
        bool explicitComponentSelection=false;
        if(mode==SelectionMode::Face){
            explicitComponentSelection=!o->selectedFaces.empty();
            for(int fi:o->selectedFaces)addSourceFace(fi);
        }else if(mode==SelectionMode::Vertex&&!o->selectedVertices.empty()){
            explicitComponentSelection=true;
            std::vector<int> selectedVertexIds(o->selectedVertices.begin(),o->selectedVertices.end());
            std::sort(selectedVertexIds.begin(),selectedVertexIds.end());
            selectedVertexIds.erase(std::unique(selectedVertexIds.begin(),selectedVertexIds.end()),selectedVertexIds.end());
            for(size_t fi=0;fi<m.faces.size();++fi){const auto& face=m.faces[fi];bool fullySelected=!face.empty();
                for(uint32_t vi:face)if(!std::binary_search(selectedVertexIds.begin(),selectedVertexIds.end(),(int)vi)){fullySelected=false;break;}
                if(fullySelected)addSourceFace((int)fi);
            }
        }else if(mode==SelectionMode::Edge&&!o->selectedEdges.empty()){
            explicitComponentSelection=true;
            std::vector<std::pair<int,int>> selectedEdgeIds(o->selectedEdges.begin(),o->selectedEdges.end());
            for(auto& edge:selectedEdgeIds)if(edge.first>edge.second)std::swap(edge.first,edge.second);
            std::sort(selectedEdgeIds.begin(),selectedEdgeIds.end());
            selectedEdgeIds.erase(std::unique(selectedEdgeIds.begin(),selectedEdgeIds.end()),selectedEdgeIds.end());
            for(size_t fi=0;fi<m.faces.size();++fi){const auto& face=m.faces[fi];bool fullySelected=face.size()>=2;
                for(size_t k=0;k<face.size()&&fullySelected;++k){const uint32_t a=face[k],b=face[(k+1u)%face.size()];const auto edge=std::make_pair((int)std::min(a,b),(int)std::max(a,b));
                    if(!std::binary_search(selectedEdgeIds.begin(),selectedEdgeIds.end(),edge))fullySelected=false;
                }
                if(fullySelected)addSourceFace((int)fi);
            }
        }
        if(explicitComponentSelection&&sourceFaces.empty()){
            setStatus("Auto UV: select complete faces (all face vertices or edges) to unwrap a subset");
            return;
        }
        if(explicitComponentSelection&&!sourceFaces.empty()&&sourceFaces.size()<m.faces.size()){
            const bool hadIndependent=m.triangleCornerUVIndependent;
            std::vector<CowVector<uint32_t>> originalFaces(m.faces.begin(),m.faces.end());
            std::vector<std::pair<float,float>> originalUV(m.faceCornerUV.begin(),m.faceCornerUV.end());
            size_t originalFullCornerCount=0;for(const auto& face:originalFaces)originalFullCornerCount+=face.size();
            const bool originalFaceUVComplete=originalUV.size()==originalFullCornerCount;
            std::vector<uint32_t> originalIndices(m.indices.begin(),m.indices.end());
            std::vector<int> originalTriangleFaces(m.triangleFaces.begin(),m.triangleFaces.end());
            std::vector<std::pair<float,float>> originalTriangleUV(m.triangleCornerUV.begin(),m.triangleCornerUV.end());
            std::vector<uint32_t> originalSourceIds(m.triangleCornerUVSourceVertexIndices.begin(),m.triangleCornerUVSourceVertexIndices.end());
            const bool originalIndependentValid=hadIndependent && originalFaceUVComplete &&
                originalTriangleUV.size()==originalIndices.size() && originalIndices.size()==originalTriangleFaces.size()*3u &&
                originalSourceIds.size()==originalTriangleUV.size();
            if(hadIndependent&&!originalIndependentValid){
                setStatus("Auto UV: cancelled; existing independent UV data is incomplete");
                logWarning("UV","Selected-face Auto UV cancelled: independent UV streams failed validation before subset unwrap");
                return;
            }

            std::vector<CowVector<uint32_t>> subsetFaces;subsetFaces.reserve(sourceFaces.size());
            size_t subsetCornerCount=0;
            for(int fi:sourceFaces){subsetFaces.push_back(originalFaces[(size_t)fi]);subsetCornerCount+=originalFaces[(size_t)fi].size();}
            m.faces=std::move(subsetFaces);
            m.faceCornerUV.clear();
            m.triangleCornerUV.clear();m.triangleCornerUVVertexIndices.clear();
            m.triangleCornerUVSourceVertexIndices.clear();m.uvVertices.clear();
            m.triangleCornerUVIndependent=false;
            m.rebuildTriangulation();
            selectedFaceUnwrapPass=true;
            autoUnwrapSelectedBySeams(seamsOnly);
            selectedFaceUnwrapPass=false;

            std::vector<std::pair<float,float>> subsetUV(m.faceCornerUV.begin(),m.faceCornerUV.end());
            std::vector<uint32_t> subsetIndices(m.indices.begin(),m.indices.end());
            std::vector<int> subsetTriangleFaces(m.triangleFaces.begin(),m.triangleFaces.end());
            std::vector<std::pair<float,float>> subsetTriangleUV(m.triangleCornerUV.begin(),m.triangleCornerUV.end());
            std::vector<uint32_t> subsetSourceIds;
            if(m.triangleCornerUVIndependent && m.triangleCornerUVSourceVertexIndices.size()==m.triangleCornerUV.size())
                subsetSourceIds.assign(m.triangleCornerUVSourceVertexIndices.begin(),m.triangleCornerUVSourceVertexIndices.end());
            else if(m.triangleCornerUVVertexIndices.size()==m.triangleCornerUV.size())
                subsetSourceIds.assign(m.triangleCornerUVVertexIndices.begin(),m.triangleCornerUVVertexIndices.end());

            // Restore the original topology and its exact independent UV streams before
            // rebuilding derived data. This lets rebuildTriangulation validate/preserve
            // the old full-mesh triangle stream rather than comparing against the subset.
            m.faces=std::move(originalFaces);
            m.faceCornerUV=originalFaceUVComplete?originalUV:std::vector<std::pair<float,float>>(originalFullCornerCount,{0.0f,0.0f});
            m.indices=originalIndices;
            m.triangleFaces=originalTriangleFaces;
            m.triangleCornerUV=hadIndependent?originalTriangleUV:std::vector<std::pair<float,float>>{};
            m.triangleCornerUVSourceVertexIndices=hadIndependent?originalSourceIds:std::vector<uint32_t>{};
            m.triangleCornerUVIndependent=hadIndependent;
            m.rebuildTriangulation();

            // Capture a canonical baseline for unselected triangles. Legacy UVs
            // are converted to explicit source IDs by the mesh's normal UV-pool
            // builder; existing independent streams retain their original IDs.
            std::vector<std::pair<float,float>> baselineTriangleUV(m.triangleCornerUV.begin(),m.triangleCornerUV.end());
            std::vector<uint32_t> baselineSourceIds;
            if(m.triangleCornerUVIndependent && m.triangleCornerUVSourceVertexIndices.size()==m.triangleCornerUV.size())
                baselineSourceIds.assign(m.triangleCornerUVSourceVertexIndices.begin(),m.triangleCornerUVSourceVertexIndices.end());
            else if(m.triangleCornerUVVertexIndices.size()==m.triangleCornerUV.size())
                baselineSourceIds.assign(m.triangleCornerUVVertexIndices.begin(),m.triangleCornerUVVertexIndices.end());
            std::vector<std::pair<float,float>> baselineFaceUV(m.faceCornerUV.begin(),m.faceCornerUV.end());
            size_t fullCornerCount=0;for(const auto& face:m.faces)fullCornerCount+=face.size();
            bool validSubset=subsetUV.size()==subsetCornerCount && subsetTriangleUV.size()==subsetIndices.size() &&
                subsetIndices.size()==subsetTriangleFaces.size()*3u && subsetSourceIds.size()==subsetTriangleUV.size() &&
                baselineTriangleUV.size()==m.indices.size() && baselineSourceIds.size()==baselineTriangleUV.size() &&
                baselineFaceUV.size()==fullCornerCount;
            if(validSubset){
                for(const auto& uv:subsetUV)if(!std::isfinite(uv.first)||!std::isfinite(uv.second)){validSubset=false;break;}
                for(const auto& uv:subsetTriangleUV)if(!std::isfinite(uv.first)||!std::isfinite(uv.second)){validSubset=false;break;}
            }
            const bool fullTopologyRestored=m.indices.size()==originalIndices.size() && m.triangleFaces.size()==originalTriangleFaces.size() &&
                std::equal(m.indices.begin(),m.indices.end(),originalIndices.begin()) &&
                std::equal(m.triangleFaces.begin(),m.triangleFaces.end(),originalTriangleFaces.begin()) &&
                (!hadIndependent || (m.triangleCornerUVIndependent && m.triangleCornerUV.size()==originalTriangleUV.size())) &&
                baselineTriangleUV.size()==m.indices.size() && baselineSourceIds.size()==baselineTriangleUV.size();
            if(!validSubset || !fullTopologyRestored){
                m.faceCornerUV=std::move(originalUV);m.triangleCornerUV=std::move(originalTriangleUV);
                m.triangleCornerUVSourceVertexIndices=std::move(originalSourceIds);m.triangleCornerUVIndependent=hadIndependent;
                m.rebuildTriangulation();
                logWarning("UV","Selected-face Auto UV cancelled: subset output was incomplete or full topology could not be restored; original UVs were preserved");
                setStatus("Auto UV: selected-face result could not be matched safely");
                return;
            }

            // Match each subset triangle to a full-mesh triangle by source face and
            // vertex identity. A corner permutation is handled explicitly; no UV is
            // attached based on triangle order alone.
            // Prefix offsets into faceCornerUV (one contiguous corner range per face).
            std::vector<size_t> fullCornerOffsets(m.faces.size()+1u,0u);
            for(size_t fi=0;fi<m.faces.size();++fi)fullCornerOffsets[fi+1u]=fullCornerOffsets[fi]+m.faces[fi].size();
            std::vector<uint8_t> fullTriangleUsed(m.triangleFaces.size(),0u);
            bool mappingValid=true;
            std::vector<uint32_t> mappedSubsetSlots(subsetIndices.size(),UINT32_MAX);
            for(size_t sti=0;sti<subsetTriangleFaces.size()&&mappingValid;++sti){
                const int localFace=subsetTriangleFaces[sti];
                if(localFace<0||(size_t)localFace>=sourceFaces.size()){mappingValid=false;break;}
                const int fullFace=sourceFaces[(size_t)localFace];
                if(fullFace<0||(size_t)fullFace>=m.faces.size()||m.faceTriangleOffsets.size()!=m.faces.size()+1u){mappingValid=false;break;}
                const size_t sb=sti*3u;
                size_t candidateMatches=0;
                uint32_t candidateTriangle=UINT32_MAX;
                uint32_t candidateSlots[3]={UINT32_MAX,UINT32_MAX,UINT32_MAX};
                for(uint32_t fti=m.faceTriangleOffsets[(size_t)fullFace];fti<m.faceTriangleOffsets[(size_t)fullFace+1u];++fti){
                    if(fti>=fullTriangleUsed.size()||fullTriangleUsed[fti])continue;
                    const size_t fb=(size_t)fti*3u;
                    for(int shift=0;shift<3;++shift){
                        bool same=true;
                        for(int c=0;c<3;++c)if(subsetIndices[sb+(size_t)c]!=m.indices[fb+(size_t)((c+shift)%3)]){same=false;break;}
                        if(!same)continue;
                        ++candidateMatches;candidateTriangle=fti;
                        for(int c=0;c<3;++c)candidateSlots[c]=(uint32_t)(fb+(size_t)((c+shift)%3));
                    }
                }
                if(candidateMatches!=1u||candidateTriangle>=fullTriangleUsed.size())mappingValid=false;
                else{
                    // Record subset-corner -> full-corner correspondence only
                    // when exactly one source triangle/permutation matched.
                    for(int c=0;c<3;++c)mappedSubsetSlots[sb+(size_t)c]=candidateSlots[c];
                    fullTriangleUsed[candidateTriangle]=1u;
                }
            }
            if(!mappingValid){
                m.faceCornerUV=std::move(originalUV);m.triangleCornerUV=std::move(originalTriangleUV);
                m.triangleCornerUVSourceVertexIndices=std::move(originalSourceIds);m.triangleCornerUVIndependent=hadIndependent;
                m.rebuildTriangulation();
                logWarning("UV","Selected-face Auto UV cancelled: subset triangles could not be matched unambiguously to full-mesh triangles");
                setStatus("Auto UV: triangle mapping was ambiguous; original UVs preserved");
                return;
            }

            std::vector<std::pair<float,float>> mergedUV=baselineFaceUV;
            size_t subsetOffset=0;
            for(int fi:sourceFaces){
                const size_t dst=fullCornerOffsets[(size_t)fi],count=m.faces[(size_t)fi].size();
                std::copy_n(subsetUV.begin()+static_cast<std::ptrdiff_t>(subsetOffset),count,mergedUV.begin()+static_cast<std::ptrdiff_t>(dst));
                subsetOffset+=count;
            }

            {
                std::vector<std::pair<float,float>> mergedTriangleUV=baselineTriangleUV;
                std::vector<uint32_t> mergedSourceIds=baselineSourceIds;
                uint32_t maxOldIdentity=0;for(uint32_t id:baselineSourceIds)maxOldIdentity=std::max(maxOldIdentity,id);
                // Selected xatlas IDs occupy a fresh namespace. This prevents an
                // unrelated unselected chart with the same numeric xatlas ID from
                // being welded when rebuildUVVertexPool() consumes source identities.
                const uint64_t identityBase=uint64_t(maxOldIdentity)+1ull;
                std::unordered_map<uint32_t,uint32_t> remappedSelectedIds;
                remappedSelectedIds.reserve(subsetSourceIds.size());
                for(size_t slot=0;slot<subsetTriangleUV.size();++slot){
                    const uint32_t oldSlot=mappedSubsetSlots[slot];
                    if(oldSlot>=mergedTriangleUV.size()){mappingValid=false;break;}
                    const uint32_t subsetId=subsetSourceIds[slot];
                    auto it=remappedSelectedIds.find(subsetId);
                    if(it==remappedSelectedIds.end()){
                        const uint64_t newId=identityBase+uint64_t(remappedSelectedIds.size());
                        if(newId>UINT32_MAX){mappingValid=false;break;}
                        it=remappedSelectedIds.emplace(subsetId,(uint32_t)newId).first;
                    }
                    mergedTriangleUV[oldSlot]=subsetTriangleUV[slot];
                    mergedSourceIds[oldSlot]=it->second;
                }
                if(!mappingValid){
                    m.faceCornerUV=std::move(originalUV);m.triangleCornerUV=std::move(originalTriangleUV);
                    m.triangleCornerUVSourceVertexIndices=std::move(originalSourceIds);m.triangleCornerUVIndependent=hadIndependent;
                    m.rebuildTriangulation();
                    setStatus("Auto UV: selected UV identity range overflow; original UVs preserved");
                    logWarning("UV","Selected-face Auto UV cancelled: independent UV source identity range overflow");
                    return;
                }
                if(!multiObjectUnwrapPass)pushUndoState();
                m.faceCornerUV=std::move(mergedUV);
                m.triangleCornerUV=std::move(mergedTriangleUV);
                m.triangleCornerUVSourceVertexIndices=std::move(mergedSourceIds);
                m.triangleCornerUVIndependent=true;
                m.rebuildUVVertexPool();
                m.updateUVsOnly(true,nullptr,true,false,true);
            }
            ++uvPickRevision;
            logInfo("UV","Selected-face Auto UV: unwrapped "+std::to_string(sourceFaces.size())+" of "+std::to_string(m.faces.size())+" faces; unselected UVs preserved");
            setStatus("Auto UV: selected faces unwrapped");
            return;
        }
    }
    if(m.uniqueEdges.empty()||m.edgeFace0.size()!=m.uniqueEdges.size())m.rebuildTriangulation();

    // Try a topology-aware organic sphere path before generic chart growth. It is
    // deliberately limited to closed, near-spherical genus-zero meshes; all other
    // geometry (and all explicit-seam unwraps) remains on the xatlas path.
    if(!seamsOnly&&m.uvSeams.empty()){
        std::vector<std::pair<float,float>> organicUV;
        std::string organicReason;
        uint32_t organicCutVertices=0;
        if(kuroBuildOrganicSphereUV(m,organicUV,organicReason,organicCutVertices)){
            size_t expectedCorners=0;for(const auto& f:m.faces)expectedCorners+=f.size();
            bool valid=organicUV.size()==expectedCorners;
            for(const auto& uv:organicUV)if(!std::isfinite(uv.first)||!std::isfinite(uv.second)||uv.first<0.0f||uv.first>1.0f||uv.second<0.0f||uv.second>1.0f){valid=false;break;}
            if(valid){
                if(!multiObjectUnwrapPass&&!selectedFaceUnwrapPass)pushUndoState();
                m.faceCornerUV=std::move(organicUV);
                m.rebuildTriangulation();
                ++uvPickRevision;
                std::ostringstream organicLog;
                organicLog<<"organic sphere unwrap: faces="<<m.faces.size()<<" cut_path_vertices="<<organicCutVertices<<" atlas=single-island method="<<organicReason;
                logInfo("UV",organicLog.str());
                setStatus("Auto UV: organic sphere unwrap ready for Paint");
                return;
            }
            logWarning("UV","Organic sphere unwrap rejected: invalid output coordinates; using xatlas fallback");
        }
    }

    // Keep the user's seam cuts (and Auto UV's sharp-fold cuts) as real
    // disconnected chart boundaries before handing topology to xatlas.
    const int nf=(int)m.faces.size();
    std::vector<int> component((size_t)nf,-1);
    std::unordered_set<uint64_t> seamKeys;
    seamKeys.reserve(m.uvSeams.size()*2+1);
    for(auto e:m.uvSeams){
        const uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);
        seamKeys.insert((uint64_t(a)<<32)|b);
    }
    // Walk the existing CSR directly. Building vector<vector<int>> adjacency here
    // duplicated the Mesh topology and allocated one vector per face on every unwrap.
    // A face can reach every incident face through its faceEdges -> edgeFaces ranges,
    // including non-manifold edges with more than two incident faces.
    const bool hasFullAdjacency=m.faceEdgeOffsets.size()==m.faces.size()+1u &&
        m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u &&
        m.vertexEdgeOffsets.size()==m.vertices.size()+1u &&
        (m.edgeFaceOffsets.empty()||m.edgeFaceOffsets.back()<=m.edgeFaces.size()) &&
        (m.faceEdgeOffsets.empty()||m.faceEdgeOffsets.back()<=m.faceEdges.size()) &&
        (m.vertexEdgeOffsets.empty()||m.vertexEdgeOffsets.back()<=m.vertexEdges.size());
    if(!hasFullAdjacency){
        // Older or partially-built meshes still get a safe, one-time topology rebuild.
        m.rebuildTriangulation();
    }
    std::vector<uint8_t> edgeBlocked(m.uniqueEdges.size(),0);
    for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
        const auto e=m.uniqueEdges[ei];
        const uint32_t lo=std::min(e.first,e.second),hi=std::max(e.first,e.second);
        edgeBlocked[ei]=seamKeys.find((uint64_t(lo)<<32)|hi)!=seamKeys.end()?1u:0u;
    }
    // Select a chart-growth profile and count Smart UV Project crease edges in
    // one pass over each edge's incident face pairs. Both measurements use the
    // same normalized face-normal dot product, so computing it twice was wasted
    // work on every unwrap (especially on high-valence non-manifold edge fans).
    // Match Blender Smart UV Project's familiar default: split adjacent faces
    // when their dihedral angle exceeds 66 degrees, regardless of mesh profile.
    constexpr float automaticCreaseCos=0.40673664f; // cos(66 degrees)
    double normalDotSum=0.0;
    size_t normalPairCount=0;
    size_t strongCreasePairs=0;
    std::vector<uint8_t> coherentAutoCrease(m.uniqueEdges.size(),1u);
    uint32_t autoCreaseCandidates=0,autoCreaseAccepted=0,autoCreaseFiltered=0;
    if(m.faceNormals.size()==m.faces.size() &&
       m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u &&
       m.edgeFaceOffsets.back()<=m.edgeFaces.size()){
        for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
            const uint32_t eb=m.edgeFaceOffsets[ei],ee=m.edgeFaceOffsets[ei+1u];
            bool sharp=false;
            for(uint32_t a=eb;a<ee;++a)for(uint32_t b=a+1u;b<ee;++b){
                const int fa=m.edgeFaces[a],fb=m.edgeFaces[b];
                if(fa<0||fb<0||fa>=nf||fb>=nf)continue;
                const float nd=std::clamp(dot(normalize(m.faceNormals[(size_t)fa]),
                                              normalize(m.faceNormals[(size_t)fb])),-1.0f,1.0f);
                normalDotSum+=nd;++normalPairCount;
                if(nd<0.50f)++strongCreasePairs;
                if(nd<automaticCreaseCos)sharp=true;
            }
            if(sharp){++autoCreaseCandidates;++autoCreaseAccepted;}
        }
    }
    const double meanNormalDot=normalPairCount?normalDotSum/double(normalPairCount):0.0;
    const double creaseRatio=normalPairCount?double(strongCreasePairs)/double(normalPairCount):1.0;
    const bool organicChartProfile=(nf>=80 && m.vertices.size()>=48 && meanNormalDot>0.68 && creaseRatio<0.22);
    int componentCount=0;
    std::vector<int> q;
    q.reserve((size_t)nf);
    for(int start=0;start<nf;++start){
        if(component[(size_t)start]>=0||m.faces[(size_t)start].size()<3)continue;
        q.clear();q.push_back(start);component[(size_t)start]=componentCount;
        for(size_t qi=0;qi<q.size();++qi){
            const int f=q[qi];
            const uint32_t eb=m.faceEdgeOffsets[(size_t)f],ee=m.faceEdgeOffsets[(size_t)f+1u];
            for(uint32_t k=eb;k<ee;++k){
                const uint32_t ei=m.faceEdges[k];
                if(ei>=edgeBlocked.size()||edgeBlocked[ei])continue;
                const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                const Vec3 nf0=(!seamsOnly&&f<(int)m.faceNormals.size())?m.faceNormals[(size_t)f]:Vec3{};
                for(uint32_t j=fb;j<fe;++j){
                    const int other=m.edgeFaces[j];
                    if(other<0||other>=nf||other==f||component[(size_t)other]>=0||m.faces[(size_t)other].size()<3)continue;
                    if(!seamsOnly){
                        const Vec3 na=(f<(int)m.faceNormals.size())?nf0:faceNormal(m,f);
                        const Vec3 nb=(other<(int)m.faceNormals.size())?m.faceNormals[(size_t)other]:faceNormal(m,other);
                        // Test each pair in the edge fan independently. This preserves
                        // smooth connections on non-manifold edges without forcing every
                        // incident face into one chart when only one pair is sharp.
                        if(ei<coherentAutoCrease.size()&&coherentAutoCrease[ei]&&
                           dot(na,nb)<automaticCreaseCos)continue;
                    }
                    component[(size_t)other]=componentCount;q.push_back(other);
                }
            }
        }
        ++componentCount;
    }

    kuroSetCrashContext("Auto UV: begin polygon triangulation");kuroWriteUVTraceAt("phase: polygon triangulation begin");
    // Build per-polygon-corner xatlas vertices, but reuse the render mesh's
    // existing triangle stream below. Triangulating these polygons a second
    // time can choose a different diagonal and misattach independent UV corners.
    struct Position3 { float x,y,z; };
    std::vector<Position3> positions;
    // Supply one stable polygon normal per source corner. xatlas otherwise
    // derives normals from the generated triangles, which can make the two
    // triangles of a warped quad/ngon disagree across their internal diagonal
    // and split a single source polygon into separate charts. Kuro3D stores UVs
    // per original polygon corner, so those internal diagonal seams cannot be
    // represented without stretching one of the resulting triangles.
    std::vector<Position3> sourceCornerNormals;
    std::vector<uint32_t> indices;
    std::vector<uint32_t> faceMaterials;
    std::vector<uint32_t> sourceFaceForTriangle;
    std::vector<uint32_t> sourceFaceForCorner;
    // Keep one input vertex per original face corner. xatlas may reorder its
    // output triangles, so mapping UVs by triangle-array position is unsafe.
    // Vertex::xref gives an exact route back to this corner even after reorder.
    std::vector<size_t> originalCornerForInput;
    std::vector<uint32_t> inputMeshVertex;
    std::vector<uint32_t> faceLocalCornerByVertex(m.vertices.size(),UINT32_MAX);
    std::vector<uint8_t> faceLocalCornerAmbiguous(m.vertices.size(),0u);
    size_t allCorners=0;
    for(auto const& f:m.faces)allCorners+=f.size();
    indices.reserve(allCorners*3/2);
    faceMaterials.reserve(allCorners/3+1);
    sourceFaceForTriangle.reserve(allCorners/3+1);
    sourceFaceForCorner.assign(allCorners, UINT32_MAX);
    originalCornerForInput.reserve(allCorners);
    inputMeshVertex.reserve(allCorners);
    positions.reserve(allCorners);
    sourceCornerNormals.reserve(allCorners);
    size_t originalCorner=0;
    // The render mesh owns the authoritative triangulation. Auto UV must feed
    // these exact triangles to xatlas instead of independently ear-clipping the
    // same polygons with a different diagonal/ear order.
    if(m.indices.size()!=m.triangleFaces.size()*3u ||
       m.faceTriangleOffsets.size()!=m.faces.size()+1u ||
       m.faceTriangleOffsets.empty() || m.faceTriangleOffsets.back()!=m.triangleFaces.size()){
        setStatus("Auto UV: mesh triangle topology is incomplete; rebuild the mesh before unwrapping");
        logWarning("UV","Auto UV cancelled: mesh triangle stream/face offsets are inconsistent");
        return;
    }
    uint32_t meshTriangleMappingFailures=0u;
    uint32_t ignoredFaces=0;
    uint32_t nonFiniteFaces=0u,firstNonFiniteFace=UINT32_MAX;
    uint32_t invalidNgonFaces=0u,firstInvalidNgonFace=UINT32_MAX;
    uint32_t oversizedNgonFaces=0u,firstOversizedNgonFace=UINT32_MAX;
    for(int fi=0;fi<nf;++fi){
        auto const& f=m.faces[(size_t)fi];
        const size_t faceBase=originalCorner;
        originalCorner+=f.size();
        if(f.size()<3){++ignoredFaces;continue;}
        bool valid=true,finiteFace=true;
        for(uint32_t vi:f){
            if(vi>=m.vertices.size()){valid=false;break;}
            const Vec3 p=m.vertices[vi];
            if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))finiteFace=false;
        }
        if(!valid){++ignoredFaces;continue;}
        // Never let NaN/Inf coordinates reach Newell projection, tolerance
        // calculations, or xatlas. Reject the complete source face so its
        // corner mapping remains internally consistent.
        if(!finiteFace){
            ++ignoredFaces;++nonFiniteFaces;
            if(firstNonFiniteFace==UINT32_MAX)firstNonFiniteFace=(uint32_t)fi;
            continue;
        }
        // Keep a defensive ceiling for malformed/pathological imported contours.
        if(f.size()>4096u){
            ++oversizedNgonFaces;
            if(firstOversizedNgonFace==UINT32_MAX)firstOversizedNgonFace=(uint32_t)fi;
            continue;
        }
        uint32_t comp=(component[(size_t)fi]>=0)?(uint32_t)component[(size_t)fi]:(uint32_t)(componentCount+(uint32_t)fi);
        // Newell's normal is stable for convex/concave polygons and averages
        // non-planarity across the original face instead of introducing a
        // synthetic normal discontinuity along its ear-clipping diagonals.
        double fnx=0.0,fny=0.0,fnz=0.0;
        for(size_t k=0;k<f.size();++k){
            const Vec3 a=m.vertices[f[k]],b=m.vertices[f[(k+1u)%f.size()]];
            fnx+=(double(a.y)-b.y)*(double(a.z)+b.z);
            fny+=(double(a.z)-b.z)*(double(a.x)+b.x);
            fnz+=(double(a.x)-b.x)*(double(a.y)+b.y);
        }
        double faceMin[3]={std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity()};
        double faceMax[3]={-std::numeric_limits<double>::infinity(),-std::numeric_limits<double>::infinity(),-std::numeric_limits<double>::infinity()};
        for(uint32_t vi:f){const Vec3 p=m.vertices[vi];const double q[3]={p.x,p.y,p.z};for(int axis=0;axis<3;++axis){faceMin[axis]=std::min(faceMin[axis],q[axis]);faceMax[axis]=std::max(faceMax[axis],q[axis]);}}
        const double faceExtent=std::max({faceMax[0]-faceMin[0],faceMax[1]-faceMin[1],faceMax[2]-faceMin[2]});
        const double faceAreaTolerance=kuro::uvpacking::relativeAreaEpsilon(faceExtent);
        const double faceNormalLength=std::sqrt(fnx*fnx+fny*fny+fnz*fnz);
        if(std::isfinite(faceNormalLength)&&faceNormalLength>faceAreaTolerance){fnx/=faceNormalLength;fny/=faceNormalLength;fnz/=faceNormalLength;}
        else {fnx=0.0;fny=0.0;fnz=1.0;}
        std::vector<uint32_t> faceInput;
        faceInput.reserve(f.size());
        for(size_t k=0;k<f.size();++k){
            const uint32_t vi=f[k];
            const Vec3 p=m.vertices[vi];
            const uint32_t inputIndex=(uint32_t)positions.size();
            positions.push_back({p.x,p.y,p.z});
            sourceCornerNormals.push_back({(float)fnx,(float)fny,(float)fnz});
            originalCornerForInput.push_back(faceBase+k);
            inputMeshVertex.push_back(vi);
            sourceFaceForCorner[faceBase+k]=(uint32_t)fi;
            if(faceLocalCornerByVertex[vi]!=UINT32_MAX)faceLocalCornerAmbiguous[vi]=1u;
            else faceLocalCornerByVertex[vi]=(uint32_t)k;
            faceInput.push_back(inputIndex);
        }
        const size_t faceIndexStart=indices.size();
        const size_t faceMaterialStart=faceMaterials.size();
        const uint32_t triBegin=m.faceTriangleOffsets[(size_t)fi];
        const uint32_t triEnd=m.faceTriangleOffsets[(size_t)fi+1u];
        bool faceTriangleMapValid=triEnd>=triBegin && triEnd<=m.triangleFaces.size();
        for(uint32_t tri=triBegin;tri<triEnd&&faceTriangleMapValid;++tri){
            if(m.triangleFaces[tri]!=fi){faceTriangleMapValid=false;break;}
            const size_t meshAt=(size_t)tri*3u;
            for(size_t k=0;k<3u;++k){
                const uint32_t meshVertex=m.indices[meshAt+k];
                if(meshVertex>=m.vertices.size()){faceTriangleMapValid=false;break;}
                const uint32_t localCorner=faceLocalCornerByVertex[meshVertex];
                if(localCorner>=faceInput.size()||faceLocalCornerAmbiguous[meshVertex]){faceTriangleMapValid=false;break;}
                indices.push_back(faceInput[localCorner]);
            }
            if(faceTriangleMapValid){
                faceMaterials.push_back(comp);
                sourceFaceForTriangle.push_back((uint32_t)fi);
            }
        }
        if(!faceTriangleMapValid || indices.size()==faceIndexStart){
            indices.resize(faceIndexStart);
            faceMaterials.resize(faceMaterialStart);
            sourceFaceForTriangle.resize(faceMaterialStart);
            ++meshTriangleMappingFailures;
            ++invalidNgonFaces;
            if(firstInvalidNgonFace==UINT32_MAX)firstInvalidNgonFace=(uint32_t)fi;
        }
        for(uint32_t vi:f)if(vi<faceLocalCornerByVertex.size()){faceLocalCornerByVertex[vi]=UINT32_MAX;faceLocalCornerAmbiguous[vi]=0u;}
    }
    {std::ostringstream trace;trace<<"phase: polygon triangulation complete; positions="<<positions.size()<<" meshTriangles="<<indices.size()/3u<<" meshTriangleMappingFailures="<<meshTriangleMappingFailures<<" oversizedNgons="<<oversizedNgonFaces;kuroWriteUVTraceAt(trace.str().c_str());}
    if(invalidNgonFaces||oversizedNgonFaces){
        setStatus("Auto UV: unsupported polygon geometry (see log)");
        std::ostringstream invalidNgonLog;
        invalidNgonLog<<"Auto UV aborted: current mesh triangulation could not be mapped to polygon corners"
            <<"; triangle_mapping_failures="<<meshTriangleMappingFailures<<" invalid_faces="<<invalidNgonFaces<<" first_failed_face="<<firstInvalidNgonFace
            <<"; oversized_ngons="<<oversizedNgonFaces<<" first_oversized_face="<<firstOversizedNgonFace
            <<"; maximum_supported_ngon_corners=4096. No unsafe triangle-fan fallback was used.";
        logWarning("UV",invalidNgonLog.str());
        return;
    }
    if(nonFiniteFaces){
        std::ostringstream nonFiniteLog;
        nonFiniteLog<<"Auto UV skipped non-finite source faces="<<nonFiniteFaces
            <<" first_face="<<firstNonFiniteFace<<"; NaN/Inf coordinates were excluded before xatlas.";
        logWarning("UV",nonFiniteLog.str());
    }
    if(indices.size()<3){
        setStatus("Auto UV: no valid polygon faces");
        return;
    }

    kuroSetCrashContext("Auto UV: begin tree-cotree cut graph");kuroWriteUVTraceAt("phase: tree-cotree cut graph begin");
    // Closed orientable components with arbitrary genus need a real cut graph
    // before chart parameterization. Use the tree-cotree decomposition. The
    // weighted objective below is geometry-scale invariant and favors coherent
    // high-dihedral folds; it is a camera-independent visibility proxy, not a
    // claim of view-dependent seam hiding:
    // a weighted primal spanning tree plus the leftover 2g generators, while
    // a dual spanning tree remains uncut. This produces a disk-topology cut
    // surface without assuming that every organic model is sphere-like.
    std::vector<uint8_t> cutGraphEdge(m.uniqueEdges.size(),0u);
    uint32_t cutGraphComponents=0,cutGraphSkipped=0,cutGraphGenusSum=0;
    uint64_t cutGraphEdgeCount=0;
    double cutGraphLength=0.0;
    double cutGraphObjective=0.0;
    uint64_t cutGraphSharpEdgeCount=0;
    uint64_t cutGraphSwapCount=0;
    struct TreeCotreeExchangeCandidate { uint32_t removeEdge, addEdge; double rank; };
    std::vector<TreeCotreeExchangeCandidate> distortionGuidedExchanges;
    distortionGuidedExchanges.reserve(8u);
    // The seam-exchange ranking is quadratic in the sizes of the primal and
    // dual trees. A four-million-pair budget was excessive for ordinary
    // 2k-5k polygon assets and could monopolize the UI before xatlas started.
    // Keep more search for small meshes and bound it aggressively as density grows.
    const uint64_t topologyExchangePairBudgetLimit=m.faces.size()>5000u?180000ull:
        (m.faces.size()>1500u?300000ull:(m.faces.size()>500u?260000ull:600000ull));
    uint64_t topologyExchangePairBudget=topologyExchangePairBudgetLimit;
    const bool topologyCsrValid=m.faceEdgeOffsets.size()==m.faces.size()+1u &&
        m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u &&
        m.vertexEdgeOffsets.size()==m.vertices.size()+1u &&
        m.faceEdgeOffsets.back()<=m.faceEdges.size() &&
        m.edgeFaceOffsets.back()<=m.edgeFaces.size() &&
        m.vertexEdgeOffsets.back()<=m.vertexEdges.size();
    if(topologyCsrValid && m.vertices.size()<=1000000u && m.faces.size()<=1000000u){
        std::vector<int32_t> topoComponent(m.faces.size(),-1);
        std::vector<uint32_t> faceQueue;
        faceQueue.reserve(m.faces.size());
        std::vector<std::vector<uint32_t>> topoFaces;
        for(uint32_t seed=0;seed<m.faces.size();++seed){
            if(topoComponent[seed]>=0 || m.faces[seed].size()<3) continue;
            const int32_t cid=(int32_t)topoFaces.size();
            topoFaces.emplace_back();
            faceQueue.clear(); faceQueue.push_back(seed); topoComponent[seed]=cid;
            for(size_t qi=0;qi<faceQueue.size();++qi){
                const uint32_t f=faceQueue[qi]; topoFaces.back().push_back(f);
                const uint32_t eb=m.faceEdgeOffsets[f],ee=m.faceEdgeOffsets[f+1u];
                for(uint32_t k=eb;k<ee;++k){
                    const uint32_t ei=m.faceEdges[k];
                    if(ei>=m.uniqueEdges.size()) continue;
                    const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                    for(uint32_t j=fb;j<fe;++j){
                        const int other=m.edgeFaces[j];
                        if(other>=0 && (size_t)other<m.faces.size() && topoComponent[(size_t)other]<0){
                            topoComponent[(size_t)other]=cid; faceQueue.push_back((uint32_t)other);
                        }
                    }
                }
            }
        }
        std::vector<uint32_t> vertexStamp(m.vertices.size(),0u),edgeStamp(m.uniqueEdges.size(),0u);
        std::vector<uint32_t> visitedVertexStamp(m.vertices.size(),0u),visitedFaceStamp(m.faces.size(),0u);
        std::vector<uint32_t> primalTreeStamp(m.uniqueEdges.size(),0u),dualTreeStamp(m.uniqueEdges.size(),0u);
        std::vector<uint32_t> linkDegree(m.faces.size(),0u),linkFaceStamp(m.faces.size(),0u),linkSeenStamp(m.faces.size(),0u);
        uint32_t stamp=0,linkGeneration=0;
        for(const auto& facesInComponent:topoFaces){
            if(facesInComponent.empty()) continue;
            ++stamp; if(stamp==0){std::fill(vertexStamp.begin(),vertexStamp.end(),0u);std::fill(edgeStamp.begin(),edgeStamp.end(),0u);stamp=1;}
            std::vector<uint32_t> compVertices,compEdges;
            compVertices.reserve(facesInComponent.size()*2u); compEdges.reserve(facesInComponent.size()*2u);
            bool manifoldClosed=true;
            for(uint32_t f:facesInComponent){
                for(uint32_t v:m.faces[f]) if(v<m.vertices.size() && vertexStamp[v]!=stamp){vertexStamp[v]=stamp;compVertices.push_back(v);}
                const uint32_t eb=m.faceEdgeOffsets[f],ee=m.faceEdgeOffsets[f+1u];
                for(uint32_t k=eb;k<ee;++k){
                    const uint32_t ei=m.faceEdges[k]; if(ei>=m.uniqueEdges.size()) {manifoldClosed=false;continue;}
                    if(edgeStamp[ei]!=stamp){edgeStamp[ei]=stamp;compEdges.push_back(ei);}
                    if(m.edgeFaceOffsets[ei+1u]-m.edgeFaceOffsets[ei]!=2u) manifoldClosed=false;
                }
            }
            if(!manifoldClosed || compVertices.empty() || compEdges.empty()) {++cutGraphSkipped;continue;}
            // Edge-manifold alone is insufficient: reject pinched vertices whose
            // one-ring is multiple cycles or a chain instead of one closed loop.
            bool vertexLinksValid=true;
            std::vector<uint32_t> linkFaces,linkQueue;
            for(uint32_t v:compVertices){
                ++linkGeneration; if(linkGeneration==0){std::fill(linkFaceStamp.begin(),linkFaceStamp.end(),0u);std::fill(linkSeenStamp.begin(),linkSeenStamp.end(),0u);linkGeneration=1;}
                linkFaces.clear();linkQueue.clear();
                const uint32_t vb=m.vertexEdgeOffsets[v],ve=m.vertexEdgeOffsets[v+1u];
                for(uint32_t k=vb;k<ve;++k){
                    const uint32_t ei=m.vertexEdges[k];if(ei>=m.uniqueEdges.size()||edgeStamp[ei]!=stamp)continue;
                    const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                    if(fe-fb!=2u){vertexLinksValid=false;break;}
                    const int f0=m.edgeFaces[fb],f1=m.edgeFaces[fb+1u];
                    if(f0<0||f1<0||(size_t)f0>=m.faces.size()||(size_t)f1>=m.faces.size()){vertexLinksValid=false;break;}
                    ++linkDegree[(size_t)f0];++linkDegree[(size_t)f1];
                    if(linkFaceStamp[(size_t)f0]!=linkGeneration){linkFaceStamp[(size_t)f0]=linkGeneration;linkFaces.push_back((uint32_t)f0);}
                    if(linkFaceStamp[(size_t)f1]!=linkGeneration){linkFaceStamp[(size_t)f1]=linkGeneration;linkFaces.push_back((uint32_t)f1);}
                }
                if(!vertexLinksValid)break;
                for(uint32_t f:linkFaces){if(linkDegree[f]!=2u)vertexLinksValid=false;linkDegree[f]=0u;}
                if(!vertexLinksValid||linkFaces.empty()){vertexLinksValid=false;break;}
                linkQueue.push_back(linkFaces.front());linkSeenStamp[linkFaces.front()]=linkGeneration;
                for(size_t qi=0;qi<linkQueue.size();++qi){
                    const uint32_t f=linkQueue[qi];const uint32_t eb=m.faceEdgeOffsets[f],ee=m.faceEdgeOffsets[f+1u];
                    for(uint32_t k=eb;k<ee;++k){const uint32_t ei=m.faceEdges[k];if(ei>=m.uniqueEdges.size()||edgeStamp[ei]!=stamp)continue;
                        const auto e=m.uniqueEdges[ei];if(e.first!=v&&e.second!=v)continue;
                        const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                        for(uint32_t j=fb;j<fe;++j){const int other=m.edgeFaces[j];if(other>=0&&(size_t)other<m.faces.size()&&linkFaceStamp[(size_t)other]==linkGeneration&&linkSeenStamp[(size_t)other]!=linkGeneration){linkSeenStamp[(size_t)other]=linkGeneration;linkQueue.push_back((uint32_t)other);}}
                    }
                }
                if(linkQueue.size()!=linkFaces.size()){vertexLinksValid=false;break;}
            }
            if(!vertexLinksValid){++cutGraphSkipped;continue;}
            const int64_t chi=(int64_t)compVertices.size()-(int64_t)compEdges.size()+(int64_t)facesInComponent.size();
            if(chi>2 || ((2-chi)&1)!=0){++cutGraphSkipped;continue;}
            const uint32_t genus=(uint32_t)((2-chi)/2);
            if(genus>64u){++cutGraphSkipped;continue;}
            struct EdgeCandidate { double weight; uint32_t edge; uint32_t from; uint32_t to; };
            struct MinEdge { bool operator()(const EdgeCandidate&a,const EdgeCandidate&b)const{return a.weight==b.weight?a.edge>b.edge:a.weight>b.weight;} };
            struct MaxEdge { bool operator()(const EdgeCandidate&a,const EdgeCandidate&b)const{return a.weight==b.weight?a.edge>b.edge:a.weight<b.weight;} };
            // Normalize edge lengths per connected component. This keeps the
            // seam objective stable across differently scaled assets and avoids
            // letting one unusually long edge dominate the spanning trees.
            std::vector<double> componentEdgeLengths;
            componentEdgeLengths.reserve(compEdges.size());
            for(uint32_t ei:compEdges){
                const auto e=m.uniqueEdges[ei];
                if(e.first>=m.vertices.size()||e.second>=m.vertices.size())continue;
                const Vec3 d=m.vertices[e.second]-m.vertices[e.first];
                const double len=std::sqrt(std::max(0.0,double(dot(d,d))));
                if(std::isfinite(len)&&len>1.0e-12)componentEdgeLengths.push_back(len);
            }
            if(componentEdgeLengths.empty()){++cutGraphSkipped;continue;}
            const size_t medianIndex=componentEdgeLengths.size()/2u;
            std::nth_element(componentEdgeLengths.begin(),componentEdgeLengths.begin()+static_cast<std::ptrdiff_t>(medianIndex),componentEdgeLengths.end());
            const double medianEdgeLength=componentEdgeLengths[medianIndex];
            auto edgeCost=[&](uint32_t ei)->double{
                const auto e=m.uniqueEdges[ei]; if(e.first>=m.vertices.size()||e.second>=m.vertices.size())return 1.0e30;
                const Vec3 d=m.vertices[e.second]-m.vertices[e.first];
                const double len=std::sqrt(std::max(0.0,double(dot(d,d))));
                double nd=1.0;
                const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                if(fe-fb==2u && m.faceNormals.size()==m.faces.size()){
                    const int fa=m.edgeFaces[fb],fb2=m.edgeFaces[fb+1u];
                    if(fa>=0&&fb2>=0&&(size_t)fa<m.faceNormals.size()&&(size_t)fb2<m.faceNormals.size())
                        nd=std::clamp(double(dot(normalize(m.faceNormals[(size_t)fa]),normalize(m.faceNormals[(size_t)fb2]))),-1.0,1.0);
                }
                // Short, sharp, feature-aligned edges are preferred seam
                // candidates. Length is normalized and softened so dense local
                // tessellation does not attract the entire cut graph.
                const double relativeLength=std::clamp(len/medianEdgeLength,0.25,4.0);
                const double lengthPenalty=0.70+0.30*std::sqrt(relativeLength);
                const double sharpness=0.5*(1.0-nd);
                const double foldPenalty=1.0-0.62*sharpness;
                return lengthPenalty*foldPenalty;
            };
            // Choose the primal root geometrically rather than by imported vertex
            // order. This makes equivalent re-indexed meshes much more stable.
            uint32_t root=compVertices.front();
            for(uint32_t v:compVertices){
                const Vec3 a=m.vertices[v],b=m.vertices[root];
                if(a.x<b.x || (a.x==b.x&&(a.y<b.y || (a.y==b.y&&a.z<b.z))))root=v;
            }
            // Minimum spanning tree of the primal vertex graph.
            std::priority_queue<EdgeCandidate,std::vector<EdgeCandidate>,MinEdge> primalQueue;
            visitedVertexStamp[root]=stamp;
            auto pushPrimal=[&](uint32_t v){
                const uint32_t vb=m.vertexEdgeOffsets[v],ve=m.vertexEdgeOffsets[v+1u];
                for(uint32_t k=vb;k<ve;++k){const uint32_t ei=m.vertexEdges[k];if(ei>=m.uniqueEdges.size()||edgeStamp[ei]!=stamp)continue;
                    const auto e=m.uniqueEdges[ei];const uint32_t to=e.first==v?e.second:e.first;
                    if(to<m.vertices.size()&&visitedVertexStamp[to]!=stamp)primalQueue.push({edgeCost(ei),ei,v,to});}
            };
            pushPrimal(root);
            uint32_t primalCount=0;
            while(!primalQueue.empty()&&primalCount+1u<compVertices.size()){
                const EdgeCandidate c=primalQueue.top();primalQueue.pop();
                if(visitedVertexStamp[c.to]==stamp)continue;
                visitedVertexStamp[c.to]=stamp;primalTreeStamp[c.edge]=stamp;++primalCount;pushPrimal(c.to);
            }
            if(primalCount+1u!=compVertices.size()){++cutGraphSkipped;continue;}
            // Root the dual traversal near the primal root in geometric space,
            // rather than at the first polygon in the import stream.
            uint32_t faceRoot=facesInComponent.front();
            const Vec3 rootPosition=m.vertices[root];
            double bestFaceRootDistance=std::numeric_limits<double>::infinity();
            for(uint32_t f:facesInComponent){
                Vec3 centroid{};size_t count=0;
                for(uint32_t v:m.faces[f])if(v<m.vertices.size()){centroid=centroid+m.vertices[v];++count;}
                if(!count)continue;
                centroid=centroid*(1.0f/float(count));
                const Vec3 delta=centroid-rootPosition;
                const double distance=double(dot(delta,delta));
                if(distance<bestFaceRootDistance){bestFaceRootDistance=distance;faceRoot=f;}
            }
            // Maximum spanning tree of the dual graph using only non-primal edges.
            std::priority_queue<EdgeCandidate,std::vector<EdgeCandidate>,MaxEdge> dualQueue;
            visitedFaceStamp[faceRoot]=stamp;
            auto pushDual=[&](uint32_t f){
                const uint32_t eb=m.faceEdgeOffsets[f],ee=m.faceEdgeOffsets[f+1u];
                for(uint32_t k=eb;k<ee;++k){const uint32_t ei=m.faceEdges[k];if(ei>=m.uniqueEdges.size()||edgeStamp[ei]!=stamp||primalTreeStamp[ei]==stamp)continue;
                    const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                    for(uint32_t j=fb;j<fe;++j){const int other=m.edgeFaces[j];if(other<0||(uint32_t)other==f||(size_t)other>=m.faces.size()||visitedFaceStamp[(size_t)other]==stamp)continue;
                        dualQueue.push({edgeCost(ei),ei,f,(uint32_t)other});}}
            };
            pushDual(faceRoot);uint32_t dualCount=0;
            while(!dualQueue.empty()&&dualCount+1u<facesInComponent.size()){
                const EdgeCandidate c=dualQueue.top();dualQueue.pop();if(visitedFaceStamp[c.to]==stamp)continue;
                visitedFaceStamp[c.to]=stamp;dualTreeStamp[c.edge]=stamp;++dualCount;pushDual(c.to);
            }
            if(dualCount+1u!=facesInComponent.size()){++cutGraphSkipped;continue;}

            // Locally improve the tree-cotree decomposition by exchanging one
            // primal-tree edge with one dual-tree edge. The exchange is valid
            // only when each replacement crosses the fundamental cut created
            // by removing the opposite edge. This preserves both spanning trees
            // and therefore preserves the 2g generator count exactly.
            uint32_t componentSwapCount=0;
            // This refinement compares primal/dual tree edges pairwise. It improves
            // seam placement on small closed meshes, but its quadratic cost is
            // not worthwhile on typical character assets with a few thousand
            // polygons; xatlas and the bounded chart-quality pass handle those.
            if(compVertices.size()<=1200u && facesInComponent.size()<=1200u){
                std::unordered_map<uint32_t,uint32_t> vertexLocal,faceLocal;
                vertexLocal.reserve(compVertices.size()*2u+1u);
                faceLocal.reserve(facesInComponent.size()*2u+1u);
                for(uint32_t i=0;i<compVertices.size();++i)vertexLocal.emplace(compVertices[i],i);
                for(uint32_t i=0;i<facesInComponent.size();++i)faceLocal.emplace(facesInComponent[i],i);
                using TreeAdj=std::vector<std::vector<std::pair<uint32_t,uint32_t>>>;
                TreeAdj primalAdj(compVertices.size()),dualAdj(facesInComponent.size());
                for(uint32_t ei:compEdges){
                    const auto e=m.uniqueEdges[ei];
                    if(primalTreeStamp[ei]==stamp){
                        const auto a=vertexLocal.find(e.first),b=vertexLocal.find(e.second);
                        if(a!=vertexLocal.end()&&b!=vertexLocal.end()){
                            primalAdj[a->second].push_back({b->second,ei});
                            primalAdj[b->second].push_back({a->second,ei});
                        }
                    }
                    if(dualTreeStamp[ei]==stamp){
                        const uint32_t fb=m.edgeFaceOffsets[ei];
                        const int fa=m.edgeFaces[fb],fb2=m.edgeFaces[fb+1u];
                        if(fa>=0&&fb2>=0){
                            const auto a=faceLocal.find((uint32_t)fa),b=faceLocal.find((uint32_t)fb2);
                            if(a!=faceLocal.end()&&b!=faceLocal.end()){
                                dualAdj[a->second].push_back({b->second,ei});
                                dualAdj[b->second].push_back({a->second,ei});
                            }
                        }
                    }
                }
                struct TreeIntervals { std::vector<uint32_t> tin,tout,parent; bool valid=false; };
                auto makeIntervals=[](const TreeAdj& adj,uint32_t rootIndex)->TreeIntervals{
                    TreeIntervals out;const size_t n=adj.size();
                    out.tin.assign(n,UINT32_MAX);out.tout.assign(n,UINT32_MAX);out.parent.assign(n,UINT32_MAX);
                    if(rootIndex>=n)return out;
                    struct Frame{uint32_t node,parent;size_t next;};
                    std::vector<Frame> stack;stack.reserve(n);
                    uint32_t timer=0;out.tin[rootIndex]=timer++;stack.push_back({rootIndex,UINT32_MAX,0});
                    while(!stack.empty()){
                        Frame& frame=stack.back();
                        if(frame.next<adj[frame.node].size()){
                            const uint32_t to=adj[frame.node][frame.next++].first;
                            if(to==frame.parent||to>=n||out.tin[to]!=UINT32_MAX)continue;
                            out.parent[to]=frame.node;out.tin[to]=timer++;stack.push_back({to,frame.node,0});
                        }else{out.tout[frame.node]=timer;stack.pop_back();}
                    }
                    out.valid=timer==n;return out;
                };
                std::vector<uint32_t> primalTreeEdges,dualTreeEdges;
                primalTreeEdges.reserve(compVertices.size());dualTreeEdges.reserve(facesInComponent.size());
                for(uint32_t ei:compEdges){if(primalTreeStamp[ei]==stamp)primalTreeEdges.push_back(ei);if(dualTreeStamp[ei]==stamp)dualTreeEdges.push_back(ei);}
                auto primalRootIt=vertexLocal.find(root);
                auto dualRootIt=faceLocal.find(faceRoot);
                for(uint32_t pass=0;pass<2u&&primalRootIt!=vertexLocal.end()&&dualRootIt!=faceLocal.end();++pass){
                    TreeIntervals pt=makeIntervals(primalAdj,primalRootIt->second);
                    TreeIntervals dt=makeIntervals(dualAdj,dualRootIt->second);
                    if(!pt.valid||!dt.valid)break;
                    double bestDelta=-1.0e-9;uint32_t bestPrimal=UINT32_MAX,bestDual=UINT32_MAX;
                    size_t bestPrimalSlot=SIZE_MAX,bestDualSlot=SIZE_MAX;
                    for(size_t psi=0;psi<primalTreeEdges.size();++psi){
                        const uint32_t pe=primalTreeEdges[psi];
                        const auto ep=m.uniqueEdges[pe];
                        const auto pu=vertexLocal.find(ep.first),pv=vertexLocal.find(ep.second);
                        if(pu==vertexLocal.end()||pv==vertexLocal.end())continue;
                        uint32_t child=UINT32_MAX;
                        if(pt.parent[pu->second]==pv->second)child=pu->second;
                        else if(pt.parent[pv->second]==pu->second)child=pv->second;
                        if(child==UINT32_MAX)continue;
                        const uint32_t t0=pt.tin[child],t1=pt.tout[child];
                        for(size_t dsi=0;dsi<dualTreeEdges.size();++dsi){
                            const uint32_t de=dualTreeEdges[dsi];
                            const auto replacement=m.uniqueEdges[de];
                            const auto ru=vertexLocal.find(replacement.first),rv=vertexLocal.find(replacement.second);
                            if(ru==vertexLocal.end()||rv==vertexLocal.end())continue;
                            const bool ruInside=pt.tin[ru->second]>=t0&&pt.tin[ru->second]<t1;
                            const bool rvInside=pt.tin[rv->second]>=t0&&pt.tin[rv->second]<t1;
                            if(ruInside==rvInside)continue;
                            const uint32_t pfb=m.edgeFaceOffsets[pe];
                            const int pfa=m.edgeFaces[pfb],pfb2=m.edgeFaces[pfb+1u];
                            const auto pfaIt=pfa>=0?faceLocal.find((uint32_t)pfa):faceLocal.end();
                            const auto pfbIt=pfb2>=0?faceLocal.find((uint32_t)pfb2):faceLocal.end();
                            if(pfaIt==faceLocal.end()||pfbIt==faceLocal.end())continue;
                            const int dfa=m.edgeFaces[m.edgeFaceOffsets[de]],dfb=m.edgeFaces[m.edgeFaceOffsets[de]+1u];
                            if(dfa<0||dfb<0)continue;
                            const auto dfaIt=faceLocal.find((uint32_t)dfa),dfbIt=faceLocal.find((uint32_t)dfb);
                            if(dfaIt==faceLocal.end()||dfbIt==faceLocal.end())continue;
                            uint32_t dualChild=UINT32_MAX;
                            if(dt.parent[dfaIt->second]==dfbIt->second)dualChild=dfaIt->second;
                            else if(dt.parent[dfbIt->second]==dfaIt->second)dualChild=dfbIt->second;
                            if(dualChild==UINT32_MAX)continue;
                            const uint32_t q0=dt.tin[dualChild],q1=dt.tout[dualChild];
                            const bool pfaInside=dt.tin[pfaIt->second]>=q0&&dt.tin[pfaIt->second]<q1;
                            const bool pfbInside=dt.tin[pfbIt->second]>=q0&&dt.tin[pfbIt->second]<q1;
                            if(pfaInside==pfbInside)continue;
                            const double delta=edgeCost(de)-edgeCost(pe);
                            if(delta<bestDelta){bestDelta=delta;bestPrimal=pe;bestDual=de;bestPrimalSlot=psi;bestDualSlot=dsi;}
                        }
                    }
                    if(bestPrimal==UINT32_MAX||bestDual==UINT32_MAX)break;
                    primalTreeStamp[bestPrimal]=0u;dualTreeStamp[bestPrimal]=stamp;
                    dualTreeStamp[bestDual]=0u;primalTreeStamp[bestDual]=stamp;
                    primalTreeEdges[bestPrimalSlot]=bestDual;dualTreeEdges[bestDualSlot]=bestPrimal;
                    for(auto& links:primalAdj)links.clear();
                    for(auto& links:dualAdj)links.clear();
                    for(uint32_t ei:compEdges){
                        const auto e=m.uniqueEdges[ei];
                        if(primalTreeStamp[ei]==stamp){const auto a=vertexLocal.find(e.first),b=vertexLocal.find(e.second);if(a!=vertexLocal.end()&&b!=vertexLocal.end()){primalAdj[a->second].push_back({b->second,ei});primalAdj[b->second].push_back({a->second,ei});}}
                        if(dualTreeStamp[ei]==stamp){const int fa=m.edgeFaces[m.edgeFaceOffsets[ei]],fb=m.edgeFaces[m.edgeFaceOffsets[ei]+1u];if(fa>=0&&fb>=0){const auto a=faceLocal.find((uint32_t)fa),b=faceLocal.find((uint32_t)fb);if(a!=faceLocal.end()&&b!=faceLocal.end()){dualAdj[a->second].push_back({b->second,ei});dualAdj[b->second].push_back({a->second,ei});}}}
                    }
                    ++componentSwapCount;
                }
                // Collect a tiny set of *topology-valid* alternatives from the
                // final tree-cotree state. Both fundamental-cut crossing tests
                // are required, so each recorded exchange keeps the primal and
                // dual graphs spanning and preserves the 2g generator count.
                // A global pair-check budget prevents pathological meshes with
                // many medium-sized components from causing quadratic blow-up.
                if(topologyExchangePairBudget>0u){
                    TreeIntervals pt=makeIntervals(primalAdj,primalRootIt->second);
                    TreeIntervals dt=makeIntervals(dualAdj,dualRootIt->second);
                    if(pt.valid&&dt.valid){
                        std::vector<TreeCotreeExchangeCandidate> localBest;
                        localBest.reserve(2u);
                        auto keepCandidate=[&](const TreeCotreeExchangeCandidate& candidate){
                            if(localBest.size()<2u){
                                localBest.push_back(candidate);
                                if(localBest.size()==2u&&localBest[1].rank<localBest[0].rank)
                                    std::swap(localBest[0],localBest[1]);
                            }else if(candidate.rank<localBest[1].rank){
                                localBest[1]=candidate;
                                if(localBest[1].rank<localBest[0].rank)
                                    std::swap(localBest[0],localBest[1]);
                            }
                        };
                        bool budgetExhausted=false;
                        for(uint32_t pe:primalTreeEdges){
                            if(edgeBlocked[pe])continue;
                            const auto ep=m.uniqueEdges[pe];
                            const auto pu=vertexLocal.find(ep.first),pv=vertexLocal.find(ep.second);
                            if(pu==vertexLocal.end()||pv==vertexLocal.end())continue;
                            uint32_t child=UINT32_MAX;
                            if(pt.parent[pu->second]==pv->second)child=pu->second;
                            else if(pt.parent[pv->second]==pu->second)child=pv->second;
                            if(child==UINT32_MAX)continue;
                            const uint32_t t0=pt.tin[child],t1=pt.tout[child];
                            const uint32_t pfb=m.edgeFaceOffsets[pe];
                            const int pfa=m.edgeFaces[pfb],pfb2=m.edgeFaces[pfb+1u];
                            if(pfa<0||pfb2<0)continue;
                            const auto pfaIt=faceLocal.find((uint32_t)pfa),pfbIt=faceLocal.find((uint32_t)pfb2);
                            if(pfaIt==faceLocal.end()||pfbIt==faceLocal.end())continue;
                            for(uint32_t de:dualTreeEdges){
                                if(topologyExchangePairBudget==0u){budgetExhausted=true;break;}
                                --topologyExchangePairBudget;
                                if(edgeBlocked[de])continue;
                                const auto replacement=m.uniqueEdges[de];
                                const auto ru=vertexLocal.find(replacement.first),rv=vertexLocal.find(replacement.second);
                                if(ru==vertexLocal.end()||rv==vertexLocal.end())continue;
                                const bool ruInside=pt.tin[ru->second]>=t0&&pt.tin[ru->second]<t1;
                                const bool rvInside=pt.tin[rv->second]>=t0&&pt.tin[rv->second]<t1;
                                if(ruInside==rvInside)continue;
                                const int dfa=m.edgeFaces[m.edgeFaceOffsets[de]],dfb=m.edgeFaces[m.edgeFaceOffsets[de]+1u];
                                if(dfa<0||dfb<0)continue;
                                const auto dfaIt=faceLocal.find((uint32_t)dfa),dfbIt=faceLocal.find((uint32_t)dfb);
                                if(dfaIt==faceLocal.end()||dfbIt==faceLocal.end())continue;
                                uint32_t dualChild=UINT32_MAX;
                                if(dt.parent[dfaIt->second]==dfbIt->second)dualChild=dfaIt->second;
                                else if(dt.parent[dfbIt->second]==dfaIt->second)dualChild=dfbIt->second;
                                if(dualChild==UINT32_MAX)continue;
                                const uint32_t q0=dt.tin[dualChild],q1=dt.tout[dualChild];
                                const bool pfaInside=dt.tin[pfaIt->second]>=q0&&dt.tin[pfaIt->second]<q1;
                                const bool pfbInside=dt.tin[pfbIt->second]>=q0&&dt.tin[pfbIt->second]<q1;
                                if(pfaInside==pfbInside)continue;
                                keepCandidate({pe,de,edgeCost(de)-edgeCost(pe)});
                            }
                            if(budgetExhausted)break;
                        }
                        for(const auto& candidate:localBest){
                            distortionGuidedExchanges.push_back(candidate);
                            std::stable_sort(distortionGuidedExchanges.begin(),distortionGuidedExchanges.end(),[](const auto&a,const auto&b){return a.rank<b.rank;});
                            if(distortionGuidedExchanges.size()>8u)distortionGuidedExchanges.pop_back();
                        }
                    }
                }
            }
            cutGraphSwapCount+=componentSwapCount;
            uint32_t leftoverGenerators=0;
            for(uint32_t ei:compEdges) if(primalTreeStamp[ei]!=stamp&&dualTreeStamp[ei]!=stamp) ++leftoverGenerators;
            if(leftoverGenerators!=(2u*genus)){
                // Guard against non-orientable or malformed topology; do not apply a partial graph.
                ++cutGraphSkipped;continue;
            }
            for(uint32_t ei:compEdges){
                if(primalTreeStamp[ei]==stamp||dualTreeStamp[ei]!=stamp){
                    cutGraphEdge[ei]=1u;++cutGraphEdgeCount;
                    const auto e=m.uniqueEdges[ei];const Vec3 d=m.vertices[e.second]-m.vertices[e.first];
                    cutGraphLength+=std::sqrt(std::max(0.0,double(dot(d,d))));
                    cutGraphObjective+=edgeCost(ei);
                    const uint32_t fb=m.edgeFaceOffsets[ei],fe=m.edgeFaceOffsets[ei+1u];
                    if(fe-fb==2u&&m.faceNormals.size()==m.faces.size()){
                        const int fa=m.edgeFaces[fb],fb2=m.edgeFaces[fb+1u];
                        if(fa>=0&&fb2>=0&&(size_t)fa<m.faceNormals.size()&&(size_t)fb2<m.faceNormals.size()&&
                           dot(normalize(m.faceNormals[(size_t)fa]),normalize(m.faceNormals[(size_t)fb2]))<0.5f)
                            ++cutGraphSharpEdgeCount;
                    }
                }
            }
            ++cutGraphComponents;cutGraphGenusSum+=genus;
        }
    }
    // Convert source-edge cut flags to per-triangle edge flags. Internal n-gon
    // diagonals are intentionally left connected; only original mesh edges cut.
    // Additional seams discovered after xatlas charting: when triangles from one
    // source n-gon are assigned to different charts, cut that n-gon's perimeter
    // while keeping its internal triangulation edges connected. This gives the
    // source polygon one coherent chart instead of forcing incompatible per-chart
    // UVs into the single-UV-per-source-corner mesh representation.
    // Recovery seams are source-edge properties, not one-sided triangle flags.
    // xatlas stores a seam bit per directed triangle edge, and its boundary
    // builder can still discover the opposite edge from an unmarked neighbor.
    // Therefore every incident triangle edge for a forced source edge must be
    // marked, including the face on the other side of the polygon perimeter.
    std::vector<uint8_t> forcedSplitFaceBoundarySourceEdges(m.uniqueEdges.size(),0u);
    std::unordered_map<uint64_t,uint32_t> sourceEdgeLookup;
    sourceEdgeLookup.reserve(m.uniqueEdges.size()*2u+1u);
    for(uint32_t ei=0;ei<m.uniqueEdges.size();++ei){const auto e=m.uniqueEdges[ei];const uint32_t a=std::min(e.first,e.second),b=std::max(e.first,e.second);sourceEdgeLookup[(uint64_t(a)<<32)|b]=ei;}
    auto buildXatlasEdgeSeams=[&](const std::vector<uint8_t>& graphFlags){
        std::unique_ptr<bool[]> seamFlags(new bool[indices.size()]{});
        for(size_t ti=0;ti+2<indices.size();ti+=3){
            for(uint32_t k=0;k<3;++k){const uint32_t ia=indices[ti+k],ib=indices[ti+(k+1u)%3u];
                if(ia>=inputMeshVertex.size()||ib>=inputMeshVertex.size())continue;
                const uint32_t a=inputMeshVertex[ia],b=inputMeshVertex[ib];
                const auto it=sourceEdgeLookup.find((uint64_t(std::min(a,b))<<32)|std::max(a,b));
                if(it!=sourceEdgeLookup.end() &&
                   (graphFlags[it->second] || edgeBlocked[it->second] ||
                    (it->second<forcedSplitFaceBoundarySourceEdges.size()&&forcedSplitFaceBoundarySourceEdges[it->second])))
                    seamFlags[ti+k]=true;
            }
        }
        return seamFlags;
    };
    {std::ostringstream trace;trace<<"phase: tree-cotree cut graph complete; components="<<cutGraphComponents<<" skipped="<<cutGraphSkipped<<" edges="<<cutGraphEdgeCount<<" candidateExchanges="<<distortionGuidedExchanges.size();kuroWriteUVTraceAt(trace.str().c_str());}
    std::vector<uint8_t> selectedCutGraph=cutGraphEdge;
    std::unique_ptr<bool[]> xatlasEdgeSeams=buildXatlasEdgeSeams(selectedCutGraph);

    // xatlas uses an absolute FLT_EPSILON area threshold when validating input
    // triangles. Imported assets can be geometrically valid but stored at very
    // small world scales (for example FBX avatars with unapplied object scale).
    // Feed xatlas a uniformly normalized copy so chart generation is invariant
    // to the source object's units/scale. Keep `positions` untouched: all source
    // geometry validation, distortion measurements and corner remapping must
    // continue to use the original coordinates.
    std::vector<Position3> xatlasPositions;
    xatlasPositions.resize(positions.size());
    double boundsMin[3]={std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity(),std::numeric_limits<double>::infinity()};
    double boundsMax[3]={-std::numeric_limits<double>::infinity(),-std::numeric_limits<double>::infinity(),-std::numeric_limits<double>::infinity()};
    for(const auto& p:positions){
        if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z))continue;
        boundsMin[0]=std::min(boundsMin[0],double(p.x));boundsMin[1]=std::min(boundsMin[1],double(p.y));boundsMin[2]=std::min(boundsMin[2],double(p.z));
        boundsMax[0]=std::max(boundsMax[0],double(p.x));boundsMax[1]=std::max(boundsMax[1],double(p.y));boundsMax[2]=std::max(boundsMax[2],double(p.z));
    }
    const double xatlasExtent=std::max({boundsMax[0]-boundsMin[0],boundsMax[1]-boundsMin[1],boundsMax[2]-boundsMin[2]});
    const double xatlasPositionScale=(std::isfinite(xatlasExtent)&&xatlasExtent>1.0e-30)?(1.0/xatlasExtent):1.0;
    const double xatlasCenter[3]={
        std::isfinite(boundsMin[0])?(boundsMin[0]+boundsMax[0])*0.5:0.0,
        std::isfinite(boundsMin[1])?(boundsMin[1]+boundsMax[1])*0.5:0.0,
        std::isfinite(boundsMin[2])?(boundsMin[2]+boundsMax[2])*0.5:0.0
    };
    for(size_t i=0;i<positions.size();++i){
        const auto& p=positions[i];
        xatlasPositions[i]={
            (float)((double(p.x)-xatlasCenter[0])*xatlasPositionScale),
            (float)((double(p.y)-xatlasCenter[1])*xatlasPositionScale),
            (float)((double(p.z)-xatlasCenter[2])*xatlasPositionScale)
        };
    }
    kuroSetCrashContext("Auto UV: create xatlas atlas");kuroWriteUVTraceAt("phase: xatlas create begin");
    xatlas::Atlas* atlas=xatlas::Create();
    if(!atlas){setStatus("Auto UV: xatlas allocation failed");return;}
    xatlas::MeshDecl decl;
    decl.vertexPositionData=xatlasPositions.data();
    decl.vertexPositionStride=sizeof(Position3);
    decl.vertexNormalData=sourceCornerNormals.data();
    decl.vertexNormalStride=sizeof(Position3);
    decl.vertexCount=(uint32_t)positions.size();
    decl.indexData=indices.data();
    decl.indexCount=(uint32_t)indices.size();
    decl.indexFormat=xatlas::IndexFormat::UInt32;
    decl.faceMaterialData=faceMaterials.data();
    decl.faceEdgeSeamData=xatlasEdgeSeams.get();
    decl.faceCount=(uint32_t)(indices.size()/3);
    auto rebuildAtlasWithSeams=[&](std::unique_ptr<bool[]>& seamFlags)->bool{
        if(atlas){xatlas::Destroy(atlas);atlas=nullptr;}
        atlas=xatlas::Create();
        if(!atlas)return false;
        decl.faceEdgeSeamData=seamFlags.get();
        return xatlas::AddMesh(atlas,decl)==xatlas::AddMeshError::Success;
    };
    kuroSetCrashContext("Auto UV: xatlas AddMesh");kuroWriteUVTraceAt("phase: xatlas AddMesh begin");
    const xatlas::AddMeshError addResult=xatlas::AddMesh(atlas,decl);
    kuroWriteUVTraceAt("phase: xatlas AddMesh complete");
    if(addResult!=xatlas::AddMeshError::Success){
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas rejected mesh topology");
        logWarning("UV","xatlas AddMesh failed");
        return;
    }
    auto runXatlasGenerate=[&](const char* label,const xatlas::ChartOptions& co,const xatlas::PackOptions& po){
        kuroSetCrashContext(label);kuroWriteUVTraceAt(label);xatlas::Generate(atlas,co,po);kuroWriteUVTraceAt("xatlas Generate returned");
    };
    auto runXatlasPack=[&](const char* label,const xatlas::PackOptions& po){
        kuroSetCrashContext(label);kuroWriteUVTraceAt(label);xatlas::PackCharts(atlas,po);kuroWriteUVTraceAt("xatlas PackCharts returned");
    };
    // Failure-only input diagnostics for imported/skinned meshes. Keep this out
    // of the normal success path: it is intended to distinguish invalid source
    // geometry from an xatlas chart/parameterization failure without dumping
    // per-face data into the user's log.
    auto buildXatlasInputDiagnostic=[&]()->std::string{
        size_t nonFinitePositions=0u,invalidIndices=0u,repeatedIndexTriangles=0u,degenerateTriangles=0u,xatlasAreaRejectedTriangles=0u;
        double minX=std::numeric_limits<double>::infinity(),minY=minX,minZ=minX;
        double maxX=-minX,maxY=-minX,maxZ=-minX;
        for(const auto& p:positions){
            if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z)){++nonFinitePositions;continue;}
            minX=std::min(minX,double(p.x));minY=std::min(minY,double(p.y));minZ=std::min(minZ,double(p.z));
            maxX=std::max(maxX,double(p.x));maxY=std::max(maxY,double(p.y));maxZ=std::max(maxZ,double(p.z));
        }
        const double dx=std::isfinite(minX)?maxX-minX:0.0,dy=std::isfinite(minY)?maxY-minY:0.0,dz=std::isfinite(minZ)?maxZ-minZ:0.0;
        const double diagonal=std::sqrt(dx*dx+dy*dy+dz*dz);
        const double area2Epsilon=std::max(1.0e-30,diagonal*diagonal*1.0e-12);
        for(size_t ti=0;ti+2u<indices.size();ti+=3u){
            const uint32_t ia=indices[ti],ib=indices[ti+1u],ic=indices[ti+2u];
            if(ia>=positions.size()||ib>=positions.size()||ic>=positions.size()){++invalidIndices;continue;}
            if(ia==ib||ib==ic||ic==ia){++repeatedIndexTriangles;continue;}
            const auto& a=positions[ia];const auto& b=positions[ib];const auto& c=positions[ic];
            const double abx=double(b.x)-a.x,aby=double(b.y)-a.y,abz=double(b.z)-a.z;
            const double acx=double(c.x)-a.x,acy=double(c.y)-a.y,acz=double(c.z)-a.z;
            const double cx=aby*acz-abz*acy,cy=abz*acx-abx*acz,cz=abx*acy-aby*acx;
            const double area2=std::sqrt(cx*cx+cy*cy+cz*cz);
            if(!std::isfinite(area2)||area2<=area2Epsilon)++degenerateTriangles;
            if(ia<xatlasPositions.size()&&ib<xatlasPositions.size()&&ic<xatlasPositions.size()){
                const auto& xa=xatlasPositions[ia];const auto& xb=xatlasPositions[ib];const auto& xc=xatlasPositions[ic];
                const double xabx=double(xb.x)-xa.x,xaby=double(xb.y)-xa.y,xabz=double(xb.z)-xa.z;
                const double xacx=double(xc.x)-xa.x,xacy=double(xc.y)-xa.y,xacz=double(xc.z)-xa.z;
                const double xcx=xaby*xacz-xabz*xacy,xcy=xabz*xacx-xabx*xacz,xcz=xabx*xacy-xaby*xacx;
                const double xatlasArea=0.5*std::sqrt(xcx*xcx+xcy*xcy+xcz*xcz);
                if(!std::isfinite(xatlasArea)||xatlasArea<=double(std::numeric_limits<float>::min()))++xatlasAreaRejectedTriangles;
            }
        }
        size_t uniqueFaceMaterials=0u;{std::vector<uint32_t> ids=faceMaterials;std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());uniqueFaceMaterials=ids.size();}
        std::ostringstream out;out<<"xatlas input diagnostic: vertices="<<positions.size()<<" triangles="<<(indices.size()/3u)
            <<" faces="<<nf<<" face_material_groups="<<uniqueFaceMaterials
            <<" non_finite_positions="<<nonFinitePositions<<" invalid_indices="<<invalidIndices
            <<" repeated_index_triangles="<<repeatedIndexTriangles<<" near_zero_area_triangles="<<degenerateTriangles
            <<" xatlas_area_underflow_triangles="<<xatlasAreaRejectedTriangles
            <<" bounds_diagonal="<<diagonal<<" xatlas_normalized_extent=1 xatlas_position_scale="<<xatlasPositionScale;
        return out.str();
    };
    const std::string xatlasInputDiagnostic=buildXatlasInputDiagnostic();
    xatlas::ChartOptions chartOptions;
    // Give chart growth enough iterations to reconsider early seeds. The old
    // two-iteration / maxCost=2 combination was overly conservative and tended
    // to leave many small charts on curved, moderately tessellated surfaces.
    // Keep the work bounded on very dense meshes where chart generation is
    // already expensive.
    const size_t inputTriangleCount=indices.size()/3u;
    chartOptions.maxIterations=inputTriangleCount>250000u?3u:
        (inputTriangleCount>6000u?3u:(organicChartProfile?5u:4u));
    chartOptions.maxCost=inputTriangleCount>250000u?3.0f:(organicChartProfile?7.0f:6.0f);
    chartOptions.normalDeviationWeight=organicChartProfile?1.35f:2.0f;
    chartOptions.normalSeamWeight=organicChartProfile?2.25f:3.0f;
    // xatlas' LSCM chart parameterizer is used for curved charts. Enforce
    // consistent UV winding before packing; post-validation below still rejects
    // any collapsed or flipped source triangles.
    chartOptions.fixWinding=true;
    xatlas::PackOptions packOptions;
    packOptions.resolution=1024;
    packOptions.padding=4;
    packOptions.bilinear=true;
    packOptions.rotateCharts=true;
    packOptions.rotateChartsToAxis=true;
    struct UVDistortionMetrics {
        double symmetricDirichlet=std::numeric_limits<double>::infinity();
        double p95Stretch=std::numeric_limits<double>::infinity();
        double meanLogArea=std::numeric_limits<double>::infinity();
        uint32_t validTriangles=0;
    };
    auto measureAtlasDistortion=[&]()->UVDistortionMetrics{
        UVDistortionMetrics metrics;
        if(atlas->meshCount==0||!atlas->meshes||atlas->width==0||atlas->height==0)return metrics;
        const xatlas::Mesh& candidate=atlas->meshes[0];
        if(!candidate.vertexArray||!candidate.indexArray||candidate.indexCount!=indices.size())return metrics;
        struct Sample { double area,sigmaMax,sigmaMin,logArea; };
        std::vector<Sample> samples;
        samples.reserve(candidate.indexCount/3u);
        double totalArea=0.0,weightedLogScale=0.0;
        for(size_t ti=0;ti+2u<candidate.indexCount;ti+=3u){
            const uint32_t ia=candidate.indexArray[ti],ib=candidate.indexArray[ti+1u],ic=candidate.indexArray[ti+2u];
            if(ia>=candidate.vertexCount||ib>=candidate.vertexCount||ic>=candidate.vertexCount)continue;
            const uint32_t sa=indices[ti],sb=indices[ti+1u],sc=indices[ti+2u];
            if(sa>=positions.size()||sb>=positions.size()||sc>=positions.size())continue;
            const Position3 pa=positions[sa],pb=positions[sb],pc=positions[sc];
            const double e1x=double(pb.x)-pa.x,e1y=double(pb.y)-pa.y,e1z=double(pb.z)-pa.z;
            const double e2x=double(pc.x)-pa.x,e2y=double(pc.y)-pa.y,e2z=double(pc.z)-pa.z;
            const double lx=std::sqrt(e1x*e1x+e1y*e1y+e1z*e1z);
            if(lx<1.0e-12)continue;
            const double ex=e1x/lx,ey=e1y/lx,ez=e1z/lx;
            const double proj=e2x*ex+e2y*ey+e2z*ez;
            const double h2=e2x*e2x+e2y*e2y+e2z*e2z-proj*proj;
            if(h2<1.0e-20)continue;
            const double h=std::sqrt(h2),area3=0.5*lx*h;
            const auto& ua=candidate.vertexArray[ia];
            const auto& ub=candidate.vertexArray[ib];
            const auto& uc=candidate.vertexArray[ic];
            const double u0=double(ua.uv[0])/atlas->width,v0=double(ua.uv[1])/atlas->height;
            const double du1=(double(ub.uv[0])/atlas->width)-u0;
            const double dv1=(double(ub.uv[1])/atlas->height)-v0;
            const double du2=(double(uc.uv[0])/atlas->width)-u0;
            const double dv2=(double(uc.uv[1])/atlas->height)-v0;
            const double j00=du1/lx,j10=dv1/lx;
            const double j01=(du2-j00*proj)/h,j11=(dv2-j10*proj)/h;
            const double det=j00*j11-j01*j10;
            if(!std::isfinite(det)||std::fabs(det)<1.0e-18)continue;
            const double c00=j00*j00+j10*j10,c01=j00*j01+j10*j11,c11=j01*j01+j11*j11;
            const double disc=std::sqrt(std::max(0.0,(c00-c11)*(c00-c11)+4.0*c01*c01));
            const double lmax=std::max(0.0,0.5*(c00+c11+disc));
            const double lmin=std::max(1.0e-30,0.5*(c00+c11-disc));
            const double sigmaMax=std::sqrt(lmax),sigmaMin=std::sqrt(lmin);
            if(!std::isfinite(sigmaMax)||!std::isfinite(sigmaMin)||sigmaMin<1.0e-15)continue;
            const double logScale=0.5*std::log(std::fabs(det));
            samples.push_back({area3,sigmaMax,sigmaMin,logScale});
            weightedLogScale+=area3*logScale;totalArea+=area3;
        }
        if(samples.empty()||totalArea<=0.0)return metrics;
        const double globalScale=std::exp(weightedLogScale/totalArea);
        double energySum=0.0,logAreaSum=0.0;
        std::vector<std::pair<double,double>> stretchByArea;stretchByArea.reserve(samples.size());
        for(const auto& sample:samples){
            // Remove the atlas-wide uniform scale so this measures shape distortion,
            // not how much total texture area the packer happened to allocate.
            const double normalizedMax=sample.sigmaMax/globalScale;
            const double normalizedMin=sample.sigmaMin/globalScale;
            const double safeMax=std::max(1.0e-12,normalizedMax),safeMin=std::max(1.0e-12,normalizedMin);
            const double energy=0.25*(safeMax*safeMax+safeMin*safeMin+1.0/(safeMax*safeMax)+1.0/(safeMin*safeMin));
            const double logArea=std::fabs(std::log(safeMax*safeMin));
            energySum+=sample.area*energy;logAreaSum+=sample.area*logArea;
            stretchByArea.push_back({std::max(safeMax,1.0/safeMin),sample.area});
        }
        std::sort(stretchByArea.begin(),stretchByArea.end(),[](const auto&a,const auto&b){return a.first<b.first;});
        double accumulated=0.0;const double target=totalArea*0.95;double p95=stretchByArea.back().first;
        for(const auto& item:stretchByArea){accumulated+=item.second;if(accumulated>=target){p95=item.first;break;}}
        metrics.symmetricDirichlet=energySum/totalArea;
        metrics.meanLogArea=logAreaSum/totalArea;
        metrics.p95Stretch=p95;
        metrics.validTriangles=(uint32_t)samples.size();
        return metrics;
    };
    struct UVChartFragmentation {
        uint32_t singleFaceCharts=0;
        uint32_t splitSourceFaces=0;
        uint32_t charts=0;
    };
    auto measureChartFragmentation=[&]()->UVChartFragmentation{
        UVChartFragmentation resultStats;
        if(!atlas||atlas->meshCount==0||!atlas->meshes)return resultStats;
        const xatlas::Mesh& output=atlas->meshes[0];
        if(!output.indexArray||!output.vertexArray)return resultStats;
        resultStats.charts=output.chartCount;
        if(output.chartArray){
            for(uint32_t ci=0;ci<output.chartCount;++ci)
                if(output.chartArray[ci].faceCount==1u)++resultStats.singleFaceCharts;
        }
        std::vector<int32_t> firstChart((size_t)nf,-1);
        std::vector<uint8_t> split((size_t)nf,0u);
        for(size_t ti=0;ti<sourceFaceForTriangle.size()&&ti*3u<output.indexCount;++ti){
            const uint32_t fi=sourceFaceForTriangle[ti];
            const uint32_t outIndex=output.indexArray[ti*3u];
            if(fi>=(uint32_t)nf||outIndex>=output.vertexCount)continue;
            const int32_t chart=output.vertexArray[outIndex].chartIndex;
            if(chart<0)continue;
            if(firstChart[fi]<0)firstChart[fi]=chart;
            else if(firstChart[fi]!=chart)split[fi]=1u;
        }
        for(uint8_t value:split)if(value)++resultStats.splitSourceFaces;
        return resultStats;
    };
    runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
    auto measureSplitSourceFaceMask=[&]()->std::vector<uint8_t>{
        std::vector<int32_t> firstChart((size_t)nf,-1);
        std::vector<uint8_t> split((size_t)nf,0u);
        if(!atlas||atlas->meshCount==0||!atlas->meshes||!atlas->meshes[0].indexArray||!atlas->meshes[0].vertexArray)return split;
        const xatlas::Mesh& output=atlas->meshes[0];
        for(size_t ti=0;ti<sourceFaceForTriangle.size()&&ti*3u<output.indexCount;++ti){
            const uint32_t fi=sourceFaceForTriangle[ti],outIndex=output.indexArray[ti*3u];
            if(fi>=(uint32_t)nf||outIndex>=output.vertexCount)continue;
            const int32_t chart=output.vertexArray[outIndex].chartIndex;
            if(chart<0)continue;
            if(firstChart[fi]<0)firstChart[fi]=chart;
            else if(firstChart[fi]!=chart)split[fi]=1u;
        }
        return split;
    };
    uint32_t splitFaceBoundarySeamFaces=0u,splitFaceBoundarySeamEdges=0u;
    bool splitFaceBoundarySeamRecoveryAccepted=false;
    uint32_t splitFaceBoundaryCandidateSplits=0u;
    float splitFaceBoundarySelectedMaxCost=0.0f;
    uint32_t splitFaceBoundaryRejectReason=0u; // 0=no rejection, 1=chart split remained, 2=quality gate, 3=atlas rebuild failed, 4=size limit
    double splitFaceBoundaryBaselineDirichlet=0.0,splitFaceBoundaryCandidateDirichlet=0.0;
    double splitFaceBoundaryBaselineP95=0.0,splitFaceBoundaryCandidateP95=0.0;
    // xatlas grows charts greedily from competing seeds. A pair of triangles
    // belonging to one original n-gon can therefore be claimed by two charts
    // from opposite sides even though their shared diagonal is not a seam.
    // Isolate only those split source faces at their real polygon perimeter;
    // their internal triangulation edges remain uncut. Accept this fallback only
    // if it removes split faces without materially degrading measured UV quality.
    // Count split source polygons for every organic mesh, even when the atlas
    // rebuild is skipped, so diagnostics distinguish "none found" from "not tried".
    const std::vector<uint8_t> splitFaces=measureSplitSourceFaceMask();
    for(uint8_t split:splitFaces)if(split)++splitFaceBoundarySeamFaces;
    // The old 6k-triangle cutoff disabled recovery for ordinary 5k-face assets
    // (10k+ triangulated quads), including the user's 10,102-triangle model.
    // Keep a bounded ceiling but cover typical medium-sized production meshes.
    if(organicChartProfile&&inputTriangleCount<=20000u){
        bool addedBoundarySeams=false;
        for(uint32_t fi=0;fi<(uint32_t)nf&&fi<m.faces.size();++fi){
            if(!splitFaces[fi])continue;
            const auto& sourceFace=m.faces[fi];
            for(size_t e=0;e<sourceFace.size();++e){
                const uint32_t a=sourceFace[e],b=sourceFace[(e+1u)%sourceFace.size()];
                const auto edgeIt=sourceEdgeLookup.find((uint64_t(std::min(a,b))<<32)|std::max(a,b));
                if(edgeIt==sourceEdgeLookup.end()||edgeIt->second>=forcedSplitFaceBoundarySourceEdges.size())continue;
                const uint32_t edgeIndex=edgeIt->second;
                if(!forcedSplitFaceBoundarySourceEdges[edgeIndex]){
                    forcedSplitFaceBoundarySourceEdges[edgeIndex]=1u;
                    addedBoundarySeams=true;
                    ++splitFaceBoundarySeamEdges;
                }
            }
        }
        if(addedBoundarySeams){
            const UVDistortionMetrics baseline=measureAtlasDistortion();
            const UVChartFragmentation baselineFrag=measureChartFragmentation();
            auto candidateSeams=buildXatlasEdgeSeams(selectedCutGraph);
            if(rebuildAtlasWithSeams(candidateSeams)){
                // Isolating a split polygon at its perimeter is not always enough:
                // xatlas can still divide the two triangles across their internal
                // diagonal when the chart-growth threshold is too conservative.
                // Retry only this bounded recovery pass with one higher maxCost
                // value. The perimeter seams keep the experiment local; the
                // normal distortion gate prevents a broad quality regression.
                UVDistortionMetrics bestCandidate{};
                UVChartFragmentation bestCandidateFrag{};
                xatlas::ChartOptions bestCandidateOptions=chartOptions;
                bool haveCandidate=false;
                // The baseline has already been evaluated above. One bounded
                // higher-cost probe is enough here: a second full xatlas Generate
                // pass was frequently rejected by the same distortion gate and
                // added substantial latency on medium organic meshes.
                const float recoveryCost=std::max(chartOptions.maxCost,8.0f);
                {
                    xatlas::ChartOptions trialOptions=chartOptions;trialOptions.maxCost=recoveryCost;
                    runXatlasGenerate("xatlas Generate: recovery trial",trialOptions,packOptions);
                    const UVDistortionMetrics trial=measureAtlasDistortion();
                    const UVChartFragmentation trialFrag=measureChartFragmentation();
                    if(!haveCandidate||trialFrag.splitSourceFaces<bestCandidateFrag.splitSourceFaces||
                       (trialFrag.splitSourceFaces==bestCandidateFrag.splitSourceFaces&&
                        (trial.symmetricDirichlet<bestCandidate.symmetricDirichlet-1.0e-8||
                         (std::fabs(trial.symmetricDirichlet-bestCandidate.symmetricDirichlet)<=1.0e-8&&trial.p95Stretch<bestCandidate.p95Stretch)))){
                        haveCandidate=true;bestCandidate=trial;bestCandidateFrag=trialFrag;bestCandidateOptions=trialOptions;
                    }
                }
                splitFaceBoundaryCandidateSplits=haveCandidate?bestCandidateFrag.splitSourceFaces:baselineFrag.splitSourceFaces;
                splitFaceBoundaryBaselineDirichlet=baseline.symmetricDirichlet;
                splitFaceBoundaryCandidateDirichlet=haveCandidate?bestCandidate.symmetricDirichlet:baseline.symmetricDirichlet;
                splitFaceBoundaryBaselineP95=baseline.p95Stretch;
                splitFaceBoundaryCandidateP95=haveCandidate?bestCandidate.p95Stretch:baseline.p95Stretch;
                const bool qualityPreserved=haveCandidate&&bestCandidate.validTriangles==baseline.validTriangles&&
                    bestCandidate.symmetricDirichlet<=baseline.symmetricDirichlet*1.02+1.0e-6&&
                    bestCandidate.p95Stretch<=baseline.p95Stretch*1.03+1.0e-6&&
                    bestCandidate.meanLogArea<=baseline.meanLogArea+0.015;
                if(qualityPreserved&&bestCandidateFrag.splitSourceFaces<baselineFrag.splitSourceFaces){
                    xatlasEdgeSeams=std::move(candidateSeams);
                    chartOptions=bestCandidateOptions;
                    splitFaceBoundarySelectedMaxCost=bestCandidateOptions.maxCost;
                    runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions); // restore the selected recovery trial
                    splitFaceBoundarySeamRecoveryAccepted=true;
                }else{
                    splitFaceBoundaryRejectReason=!qualityPreserved?2u:1u;
                    std::fill(forcedSplitFaceBoundarySourceEdges.begin(),forcedSplitFaceBoundarySourceEdges.end(),0u);
                    xatlasEdgeSeams=buildXatlasEdgeSeams(selectedCutGraph);
                    if(!rebuildAtlasWithSeams(xatlasEdgeSeams)){
                        xatlas::Destroy(atlas);atlas=nullptr;
                        setStatus("Auto UV: unable to restore baseline charts after split-face recovery");
                        logWarning("UV","failed to restore xatlas baseline after split-face boundary-seam trial");
                        return;
                    }
                    runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
                }
            }else{
                std::fill(forcedSplitFaceBoundarySourceEdges.begin(),forcedSplitFaceBoundarySourceEdges.end(),0u);
                xatlasEdgeSeams=buildXatlasEdgeSeams(selectedCutGraph);
                if(!rebuildAtlasWithSeams(xatlasEdgeSeams)){
                    xatlas::Destroy(atlas);atlas=nullptr;
                    setStatus("Auto UV: unable to restore baseline charts after split-face recovery");
                    logWarning("UV","failed to rebuild baseline xatlas after split-face boundary-seam trial");
                    return;
                }
                runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
            }
        }
    }else if(organicChartProfile&&inputTriangleCount>20000u){
        splitFaceBoundaryRejectReason=4u; // bounded recovery skipped for very large meshes
    }
    UVDistortionMetrics selectedDistortion=measureAtlasDistortion();
    UVChartFragmentation selectedFragmentation=measureChartFragmentation();
    float selectedMaxCost=chartOptions.maxCost;
    uint32_t selectedChartCount=atlas->chartCount;
    const uint32_t baselineChartCount=std::max(1u,selectedChartCount);
    uint32_t distortionTrialCount=1u;
    auto distortionObjective=[&](const UVDistortionMetrics& metrics,uint32_t charts,uint32_t referenceCharts)->double{
        if(!metrics.validTriangles||!std::isfinite(metrics.symmetricDirichlet)||
           !std::isfinite(metrics.p95Stretch)||metrics.symmetricDirichlet<1.0||metrics.p95Stretch<1.0)
            return std::numeric_limits<double>::infinity();
        // Symmetric-Dirichlet is the primary quality term. The p95 stretch term
        // discourages a small number of badly distorted triangles, while a mild
        // logarithmic chart-count penalty avoids winning only by fragmenting the
        // mesh into many tiny islands. Uniform atlas scale is already normalized
        // out of both distortion measurements above.
        const double chartRatio=double(std::max(1u,charts))/double(std::max(1u,referenceCharts));
        return std::log(metrics.symmetricDirichlet)+0.20*std::log(metrics.p95Stretch)+0.035*std::log(chartRatio);
    };
    double selectedObjective=distortionObjective(selectedDistortion,selectedChartCount,selectedChartCount);
    // On moderate organic meshes, evaluate a small deterministic range of chart
    // growth thresholds. Each candidate is actually parameterized and packed by
    // xatlas; select using measured UV distortion, not chart count alone. Keep
    // this bounded because every Generate recomputes the charting/LSCM solution.
    // Do not pay for several full xatlas generations when the first atlas is
    // already close to isometric. The quality search is reserved for genuinely
    // distorted results; this avoids the old 4-6x cost on small organic meshes.
    const bool atlasQualityNeedsSearch=selectedDistortion.symmetricDirichlet>1.035 || selectedDistortion.p95Stretch>1.25;
    if(organicChartProfile&&inputTriangleCount<=6000u&&selectedDistortion.validTriangles>0u&&atlasQualityNeedsSearch){
        const float trials[2]={4.0f,3.2f};
        for(float trialCost:trials){
            xatlas::ChartOptions trialOptions=chartOptions;
            trialOptions.maxCost=trialCost;
            runXatlasGenerate("xatlas Generate: recovery trial",trialOptions,packOptions);
            ++distortionTrialCount;
            const UVDistortionMetrics trial=measureAtlasDistortion();
            const uint32_t trialCharts=atlas->chartCount;
            const double trialObjective=distortionObjective(trial,trialCharts,baselineChartCount);
            if(trial.validTriangles==selectedDistortion.validTriangles&&
               trialObjective+1.0e-8<selectedObjective){
                selectedDistortion=trial;
                selectedObjective=trialObjective;
                selectedMaxCost=trialCost;
                selectedChartCount=trialCharts;
            }
        }
        // Always regenerate the winning settings. This also restores the baseline
        // when no candidate improved the objective, because Generate mutates Atlas.
        chartOptions.maxCost=selectedMaxCost;
        runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
        selectedDistortion=measureAtlasDistortion();
        selectedChartCount=atlas->chartCount;
        selectedObjective=distortionObjective(selectedDistortion,selectedChartCount,baselineChartCount);
        selectedFragmentation=measureChartFragmentation();
    }

    // Evaluate only topology-preserving primal/dual tree exchanges. Unlike a
    // free one-edge relocation, each candidate was proven to keep both trees
    // spanning; therefore the cut graph retains exactly 2g generators. The
    // candidate set is globally capped and evaluated only on modest meshes.
    uint32_t seamGraphTrialCount=0u,selectedSeamGraphTrial=0u;
    const bool seamLayoutNeedsSearch=selectedDistortion.symmetricDirichlet>1.05 || selectedDistortion.p95Stretch>1.35;
    if(!distortionGuidedExchanges.empty()&&inputTriangleCount<=3000u&&selectedDistortion.validTriangles>0u&&seamLayoutNeedsSearch){
        const std::vector<uint8_t> baseCutGraph=selectedCutGraph;
        const size_t candidateCount=std::min<size_t>(2u,distortionGuidedExchanges.size());
        for(size_t candidateIndex=0;candidateIndex<candidateCount;++candidateIndex){
            const auto& exchange=distortionGuidedExchanges[candidateIndex];
            if(exchange.removeEdge>=baseCutGraph.size()||exchange.addEdge>=baseCutGraph.size()||
               !baseCutGraph[exchange.removeEdge]||baseCutGraph[exchange.addEdge]||
               edgeBlocked[exchange.removeEdge]||edgeBlocked[exchange.addEdge])continue;
            std::vector<uint8_t> candidateGraph=baseCutGraph;
            candidateGraph[exchange.removeEdge]=0u;
            candidateGraph[exchange.addEdge]=1u;
            auto candidateSeams=buildXatlasEdgeSeams(candidateGraph);
            if(!rebuildAtlasWithSeams(candidateSeams))continue;
            runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
            ++seamGraphTrialCount;
            const UVDistortionMetrics trial=measureAtlasDistortion();
            const uint32_t trialCharts=atlas->chartCount;
            const double trialObjective=distortionObjective(trial,trialCharts,baselineChartCount);
            if(trial.validTriangles==selectedDistortion.validTriangles&&trialObjective+1.0e-8<selectedObjective){
                selectedDistortion=trial;
                selectedObjective=trialObjective;
                selectedCutGraph.swap(candidateGraph);
                selectedSeamGraphTrial=seamGraphTrialCount;
            }
        }
        // Each Generate mutates the atlas. Restore the best candidate (or the
        // original graph if none improved) before extracting the final UVs.
        xatlasEdgeSeams=buildXatlasEdgeSeams(selectedCutGraph);
        if(!rebuildAtlasWithSeams(xatlasEdgeSeams)){
            xatlas::Destroy(atlas);atlas=nullptr;
            setStatus("Auto UV: unable to restore selected seam graph");
            logWarning("UV","failed to rebuild xatlas with selected seam graph");
            return;
        }
        runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
        selectedDistortion=measureAtlasDistortion();
        selectedChartCount=atlas->chartCount;
        selectedObjective=distortionObjective(selectedDistortion,selectedChartCount,baselineChartCount);
        selectedFragmentation=measureChartFragmentation();
    }

    // Capture whether this chart set benefits from a quality-oriented final
    // placement. The old code ran brute-force here, then immediately discarded
    // that layout during the fixed-resolution density search below.
    float atlasUtilizationBeforeRefine=0.0f;
    if(atlas->utilization&&atlas->atlasCount>0u){
        double sum=0.0;
        for(uint32_t i=0;i<atlas->atlasCount;++i)sum+=atlas->utilization[i];
        atlasUtilizationBeforeRefine=float(sum/double(atlas->atlasCount));
    }
    const bool atlasNeedsQualityPlacement=atlas->chartCount>0u&&atlas->chartCount<=96u&&
        atlasUtilizationBeforeRefine>0.0f&&atlasUtilizationBeforeRefine<0.72f;
    bool atlasPackRefined=false;

    // Repack to a real 1024x1024 atlas so xatlas' 4-pixel chart padding
    // has an unambiguous texel meaning. With texelsPerUnit=0 xatlas only uses
    // 1024 as a density estimate and may return a larger/smaller atlas; that
    // makes the effective padding vary when the UVs are rasterized. Find the
    // largest scale that still fits one fixed-size atlas. The search is
    // bounded, and the original adaptive layout is restored if it cannot fit.
    bool atlasFixedResolutionPacked=false;
    const float adaptiveTexelsPerUnit=atlas->texelsPerUnit;
    if(std::isfinite(adaptiveTexelsPerUnit)&&adaptiveTexelsPerUnit>0.0f&&
       atlas->width>0u&&atlas->height>0u&&atlas->meshCount>0u){
        const float maxExtent=float(std::max(atlas->width,atlas->height));
        float low=0.0f,high=adaptiveTexelsPerUnit;
        float candidate=adaptiveTexelsPerUnit*std::min(1.0f,1024.0f/maxExtent);
        float bestFit=0.0f;
        xatlas::PackOptions fixedOptions=packOptions;
        fixedOptions.resolution=1024u;
        fixedOptions.computeUtilization=false;
        fixedOptions.bruteForce=false;
        fixedOptions.texelsPerUnit=candidate;
        for(uint32_t attempt=0;attempt<7u;++attempt){
            fixedOptions.texelsPerUnit=candidate;
            runXatlasPack("xatlas PackCharts: fixed-resolution repack",fixedOptions);
            const bool fits=atlas->atlasCount==1u&&atlas->width==1024u&&atlas->height==1024u&&
                atlas->meshCount>0u&&atlas->meshes&&atlas->meshes[0].vertexArray&&atlas->meshes[0].indexArray&&
                atlas->meshes[0].indexCount==indices.size();
            if(fits){bestFit=candidate;low=candidate;}
            else high=candidate;
            if(high-low<=std::max(1.0e-7f,high*1.0e-4f))break;
            candidate=(low+high)*0.5f;
            if(!(candidate>0.0f)||!std::isfinite(candidate))break;
        }
        if(bestFit>0.0f){
            // Do the expensive utilization scan only for the accepted layout.
            // For small, under-filled chart sets, spend the optional brute-force
            // search on this final layout instead of an adaptive layout that the
            // density search would immediately overwrite.
            fixedOptions.texelsPerUnit=bestFit;
            fixedOptions.computeUtilization=true;
            fixedOptions.bruteForce=atlasNeedsQualityPlacement;
            runXatlasPack("xatlas PackCharts: fixed-resolution repack",fixedOptions);
            atlasFixedResolutionPacked=atlas->atlasCount==1u&&atlas->width==1024u&&atlas->height==1024u&&
                atlas->meshCount>0u&&atlas->meshes&&atlas->meshes[0].vertexArray&&atlas->meshes[0].indexArray&&
                atlas->meshes[0].indexCount==indices.size();
            atlasPackRefined=atlasFixedResolutionPacked&&atlasNeedsQualityPlacement;
            // Brute-force placement should not be less capable than the random
            // search, but retain a deterministic safe fallback if a future packer
            // change violates that assumption.
            if(!atlasFixedResolutionPacked&&atlasNeedsQualityPlacement){
                fixedOptions.bruteForce=false;
                runXatlasPack("xatlas PackCharts: fixed-resolution repack",fixedOptions);
                atlasFixedResolutionPacked=atlas->atlasCount==1u&&atlas->width==1024u&&atlas->height==1024u&&
                    atlas->meshCount>0u&&atlas->meshes&&atlas->meshes[0].vertexArray&&atlas->meshes[0].indexArray&&
                    atlas->meshes[0].indexCount==indices.size();
                atlasPackRefined=false;
            }
        }
        if(!atlasFixedResolutionPacked){
            runXatlasGenerate("xatlas Generate: baseline or restore",chartOptions,packOptions);
            selectedDistortion=measureAtlasDistortion();
            selectedChartCount=atlas->chartCount;
            selectedObjective=distortionObjective(selectedDistortion,selectedChartCount,baselineChartCount);
            selectedFragmentation=measureChartFragmentation();
            logWarning("UV","fixed 1024 atlas packing did not fit one atlas; restored adaptive packing, so target-resolution pixel padding is approximate");
        }else{
            selectedDistortion=measureAtlasDistortion();
            selectedChartCount=atlas->chartCount;
            selectedObjective=distortionObjective(selectedDistortion,selectedChartCount,baselineChartCount);
            selectedFragmentation=measureChartFragmentation();
        }
    }


    kuroSetCrashContext("Auto UV: post-pack atlas validation");kuroWriteUVTraceAt("phase: packing and chart quality evaluation complete");
    // Bounded post-parameterization symmetric-Dirichlet relaxation.
    // This is a lightweight SLIM-inspired local optimizer, not a full SLIM
    // implementation: chart borders stay fixed, so the packed charts cannot
    // expand into neighboring islands. Large meshes keep the fast xatlas path.
    uint32_t slimRelaxIterations=0u;
    uint32_t localGlobalIterations=0u;
    double slimRelaxBefore=selectedDistortion.symmetricDirichlet;
    double slimRelaxAfter=selectedDistortion.symmetricDirichlet;
    if(organicChartProfile && inputTriangleCount<=20000u && atlas->meshCount>0u &&
       atlas->width>0u && atlas->height>0u && atlas->meshes && atlas->meshes[0].vertexArray && atlas->meshes[0].indexArray &&
       atlas->meshes[0].indexCount==indices.size()){
        xatlas::Mesh& relaxMesh=atlas->meshes[0];
        struct RelaxTri { uint32_t a,b,c; double lx,proj,h,area; double sign; };
        std::vector<RelaxTri> relaxTris;
        relaxTris.reserve(relaxMesh.indexCount/3u);
        std::unordered_map<uint64_t,uint32_t> edgeCounts;
        edgeCounts.reserve(relaxMesh.indexCount);
        for(uint32_t ti=0;ti+2u<relaxMesh.indexCount;ti+=3u){
            const uint32_t a=relaxMesh.indexArray[ti],b=relaxMesh.indexArray[ti+1u],c=relaxMesh.indexArray[ti+2u];
            if(a>=relaxMesh.vertexCount||b>=relaxMesh.vertexCount||c>=relaxMesh.vertexCount)continue;
            // xatlas duplicates output vertices at chart boundaries. A valid
            // relaxation triangle must therefore reference one chart only;
            // never build a relaxation constraint across chart identities.
            const int chart=relaxMesh.vertexArray[a].chartIndex;
            if(chart<0||relaxMesh.vertexArray[b].chartIndex!=chart||relaxMesh.vertexArray[c].chartIndex!=chart)continue;
            if(indices[ti]>=positions.size()||indices[ti+1u]>=positions.size()||indices[ti+2u]>=positions.size())continue;
            const Position3 pa=positions[indices[ti]],pb=positions[indices[ti+1u]],pc=positions[indices[ti+2u]];
            const double e1x=double(pb.x)-pa.x,e1y=double(pb.y)-pa.y,e1z=double(pb.z)-pa.z;
            const double e2x=double(pc.x)-pa.x,e2y=double(pc.y)-pa.y,e2z=double(pc.z)-pa.z;
            const double lx=std::sqrt(e1x*e1x+e1y*e1y+e1z*e1z);if(lx<1.0e-12)continue;
            const double ex=e1x/lx,ey=e1y/lx,ez=e1z/lx;
            const double proj=e2x*ex+e2y*ey+e2z*ez;
            const double h2=e2x*e2x+e2y*e2y+e2z*e2z-proj*proj;if(h2<1.0e-20)continue;
            const double h=std::sqrt(h2),area=0.5*lx*h;
            const auto& ua=relaxMesh.vertexArray[a];const auto& ub=relaxMesh.vertexArray[b];const auto& uc=relaxMesh.vertexArray[c];
            const double u0=ua.uv[0],v0=ua.uv[1];
            const double du1=double(ub.uv[0])-u0,dv1=double(ub.uv[1])-v0;
            const double du2=double(uc.uv[0])-u0,dv2=double(uc.uv[1])-v0;
            const double det=(du1/lx)*((dv2-dv1*proj/lx)/h)-((du2-du1*proj/lx)/h)*(dv1/lx);
            if(!std::isfinite(det)||std::fabs(det)<1.0e-16)continue;
            relaxTris.push_back({a,b,c,lx,proj,h,area,det>0.0?1.0:-1.0});
            // Count only triangles that actually participate in relaxation.
            // Counting rejected/degenerate triangles here can hide a real chart
            // boundary and leave an invalid UV vertex free to drift.
            const uint32_t ids[3]={a,b,c};
            for(uint32_t k=0;k<3u;++k){const uint32_t x=ids[k],y=ids[(k+1u)%3u];const uint32_t lo=std::min(x,y),hi=std::max(x,y);++edgeCounts[(uint64_t(lo)<<32)|hi];}
        }
        std::vector<uint8_t> boundary(relaxMesh.vertexCount,0u);
        for(const auto& tri:relaxTris){const uint32_t ids[3]={tri.a,tri.b,tri.c};for(uint32_t k=0;k<3u;++k){const uint32_t x=ids[k],y=ids[(k+1u)%3u];const uint32_t lo=std::min(x,y),hi=std::max(x,y);const auto it=edgeCounts.find((uint64_t(lo)<<32)|hi);if(it==edgeCounts.end()||it->second!=2u){boundary[x]=1u;boundary[y]=1u;}}}
        double totalSourceArea=0.0,weightedLogScale=0.0;
        for(const auto& t:relaxTris){const auto& a=relaxMesh.vertexArray[t.a];const auto& b=relaxMesh.vertexArray[t.b];const auto& c=relaxMesh.vertexArray[t.c];const double du1=double(b.uv[0])-a.uv[0],dv1=double(b.uv[1])-a.uv[1],du2=double(c.uv[0])-a.uv[0],dv2=double(c.uv[1])-a.uv[1];const double j00=du1/t.lx,j10=dv1/t.lx,j01=(du2-j00*t.proj)/t.h,j11=(dv2-j10*t.proj)/t.h;const double det=j00*j11-j01*j10;if(std::fabs(det)>1.0e-18){weightedLogScale+=t.area*0.5*std::log(std::fabs(det));totalSourceArea+=t.area;}}
        const double relaxScale=(totalSourceArea>0.0)?std::exp(weightedLogScale/totalSourceArea):1.0;
        std::vector<double> gx(relaxMesh.vertexCount),gy(relaxMesh.vertexCount);
        std::vector<float> originalUv(size_t(relaxMesh.vertexCount)*2u),iterUv(size_t(relaxMesh.vertexCount)*2u);
        for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){originalUv[size_t(vi)*2u]=iterUv[size_t(vi)*2u]=relaxMesh.vertexArray[vi].uv[0];originalUv[size_t(vi)*2u+1u]=iterUv[size_t(vi)*2u+1u]=relaxMesh.vertexArray[vi].uv[1];}
        auto evaluateRelax=[&](bool withGradient)->double{
            if(withGradient){std::fill(gx.begin(),gx.end(),0.0);std::fill(gy.begin(),gy.end(),0.0);}
            double energySum=0.0,areaSum=0.0;
            for(const auto& t:relaxTris){const auto& a=relaxMesh.vertexArray[t.a];const auto& b=relaxMesh.vertexArray[t.b];const auto& c=relaxMesh.vertexArray[t.c];
                const double du1=double(b.uv[0])-a.uv[0],dv1=double(b.uv[1])-a.uv[1],du2=double(c.uv[0])-a.uv[0],dv2=double(c.uv[1])-a.uv[1];
                const double j00=du1/t.lx/relaxScale,j10=dv1/t.lx/relaxScale,j01=(du2-du1*t.proj/t.lx)/t.h/relaxScale,j11=(dv2-dv1*t.proj/t.lx)/t.h/relaxScale;
                const double det=j00*j11-j01*j10;if(!std::isfinite(det)||std::fabs(det)<1.0e-12||((det>0.0)?1.0:-1.0)!=t.sign) return std::numeric_limits<double>::infinity();
                const double ss=j00*j00+j01*j01+j10*j10+j11*j11,invDet2=1.0/(det*det),invDet3=invDet2/det;
                const double energy=0.25*(ss+ss*invDet2);if(!std::isfinite(energy))return std::numeric_limits<double>::infinity();energySum+=t.area*energy;areaSum+=t.area;
                if(withGradient){
                    // d/dJ [0.25 (||J||^2 + ||J^-1||^2)]
                    const double g00=0.5*j00+0.5*j00*invDet2-0.5*ss*j11*invDet3;
                    const double g01=0.5*j01+0.5*j01*invDet2+0.5*ss*j10*invDet3;
                    const double g10=0.5*j10+0.5*j10*invDet2+0.5*ss*j01*invDet3;
                    const double g11=0.5*j11+0.5*j11*invDet2-0.5*ss*j00*invDet3;
                    const double w=t.area/totalSourceArea;
                    const double q1u=(g00-g01*t.proj/t.h)/(t.lx*relaxScale),q2u=g01/(t.h*relaxScale);
                    const double q1v=(g10-g11*t.proj/t.h)/(t.lx*relaxScale),q2v=g11/(t.h*relaxScale);
                    gx[t.b]+=w*q1u;gy[t.b]+=w*q1v;gx[t.c]+=w*q2u;gy[t.c]+=w*q2v;gx[t.a]-=w*(q1u+q2u);gy[t.a]-=w*(q1v+q2v);
                }
            }
            return areaSum>0.0?energySum/areaSum:std::numeric_limits<double>::infinity();
        };
        // Bounded local/global ARAP-style stage. The local step computes one
        // best-fit proper 2D rotation per triangle; the global step solves the
        // resulting edge least-squares system with matrix-free conjugate gradients.
        // This is deliberately a lightweight ARAP proxy, not libigl's full SLIM.
        // A symmetric-Dirichlet line search remains the acceptance criterion.
        if(relaxTris.size()>=2u && relaxTris.size()<=20000u && totalSourceArea>0.0 && relaxScale>1.0e-20){
            struct RelaxConstraint { uint32_t a,b,tri; double px,py,weight; };
            std::vector<RelaxConstraint> constraints; constraints.reserve(relaxTris.size()*3u);
            std::vector<uint32_t> degree(relaxMesh.vertexCount,0u);
            for(uint32_t ti=0;ti<relaxTris.size();++ti){const auto& t=relaxTris[ti];
                const uint32_t ids[3]={t.a,t.b,t.c};
                const double px[3]={0.0,t.lx,t.proj},py[3]={0.0,0.0,t.h};
                for(uint32_t e=0;e<3u;++e){const uint32_t n=(e+1u)%3u;const double areaWeight=std::clamp(t.area*double(relaxTris.size())/std::max(totalSourceArea,1.0e-20),1.0e-4,1.0e4);constraints.push_back({ids[e],ids[n],ti,px[n]-px[e],py[n]-py[e],areaWeight});++degree[ids[e]];++degree[ids[n]];}
            }
            for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)if(degree[vi]==0u)boundary[vi]=1u;
            std::vector<double> rhsU(relaxMesh.vertexCount),rhsV(relaxMesh.vertexCount);
            std::vector<double> candidateU(relaxMesh.vertexCount),candidateV(relaxMesh.vertexCount);
            std::vector<double> r(relaxMesh.vertexCount),d(relaxMesh.vertexCount),ad(relaxMesh.vertexCount);
            auto solveCoordinate=[&](const std::vector<double>& rhs,std::vector<double>& x)->bool{
                auto apply=[&](const std::vector<double>& in,std::vector<double>& out){
                    std::fill(out.begin(),out.end(),0.0);
                    for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)if(boundary[vi])out[vi]=in[vi];
                    for(const auto& e:constraints){if(!boundary[e.a])out[e.a]+=e.weight*(in[e.a]-(boundary[e.b]?0.0:in[e.b]));if(!boundary[e.b])out[e.b]+=e.weight*(in[e.b]-(boundary[e.a]?0.0:in[e.a]));}
                };
                for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)x[vi]=boundary[vi]?rhs[vi]:double(relaxMesh.vertexArray[vi].uv[0]);
                apply(x,ad);double rr=0.0,bb=0.0;
                for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){r[vi]=rhs[vi]-ad[vi];if(boundary[vi])r[vi]=0.0;d[vi]=r[vi];rr+=r[vi]*r[vi];bb+=rhs[vi]*rhs[vi];}
                const double target=std::max(1.0e-24,bb*1.0e-16);
                for(uint32_t it=0;it<64u && rr>target;++it){apply(d,ad);double denom=0.0;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)denom+=d[vi]*ad[vi];if(!(denom>1.0e-30)||!std::isfinite(denom))break;const double alpha=rr/denom;double next=0.0;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){x[vi]+=alpha*d[vi];r[vi]-=alpha*ad[vi];next+=r[vi]*r[vi];}if(!std::isfinite(next))return false;const double beta=next/std::max(rr,1.0e-30);for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)d[vi]=r[vi]+beta*d[vi];rr=next;}
                return std::isfinite(rr) && (rr<=std::max(target,bb*1.0e-10));
            };
            for(uint32_t iteration=0;iteration<5u;++iteration){
                std::fill(rhsU.begin(),rhsU.end(),0.0);std::fill(rhsV.begin(),rhsV.end(),0.0);
                std::vector<double> rotC(relaxTris.size(),0.0),rotS(relaxTris.size(),0.0);
                for(uint32_t ti=0;ti<relaxTris.size();++ti){const auto& t=relaxTris[ti];const auto& a=relaxMesh.vertexArray[t.a];const auto& b=relaxMesh.vertexArray[t.b];const auto& c=relaxMesh.vertexArray[t.c];
                    const double qx[3]={a.uv[0],b.uv[0],c.uv[0]},qy[3]={a.uv[1],b.uv[1],c.uv[1]};const double px[3]={0.0,t.lx,t.proj},py[3]={0.0,0.0,t.h};
                    for(uint32_t e=0;e<3u;++e){const uint32_t n=(e+1u)%3u;const double dx=px[n]-px[e],dy=py[n]-py[e],ux=qx[n]-qx[e],uy=qy[n]-qy[e];rotC[ti]+=dx*ux+dy*uy;rotS[ti]+=dx*uy-dy*ux;}
                }
                for(const auto& e:constraints){const double norm=std::sqrt(rotC[e.tri]*rotC[e.tri]+rotS[e.tri]*rotS[e.tri]);if(!(norm>1.0e-20))continue;const double co=rotC[e.tri]/norm,si=rotS[e.tri]/norm;const double tx=relaxScale*(co*e.px-si*e.py),ty=relaxScale*(si*e.px+co*e.py);
                    rhsU[e.a]-=e.weight*tx;rhsU[e.b]+=e.weight*tx;rhsV[e.a]-=e.weight*ty;rhsV[e.b]+=e.weight*ty;
                    if(boundary[e.a]&&!boundary[e.b]){rhsU[e.b]+=e.weight*relaxMesh.vertexArray[e.a].uv[0];rhsV[e.b]+=e.weight*relaxMesh.vertexArray[e.a].uv[1];}
                    if(boundary[e.b]&&!boundary[e.a]){rhsU[e.a]+=e.weight*relaxMesh.vertexArray[e.b].uv[0];rhsV[e.a]+=e.weight*relaxMesh.vertexArray[e.b].uv[1];}
                }
                for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)if(boundary[vi]){rhsU[vi]=relaxMesh.vertexArray[vi].uv[0];rhsV[vi]=relaxMesh.vertexArray[vi].uv[1];}
                if(!solveCoordinate(rhsU,candidateU))break;
                // solveCoordinate uses current U as its initial guess; switch the
                // initial coordinate explicitly for the V solve.
                auto solveV=[&]()->bool{
                    auto apply=[&](const std::vector<double>& in,std::vector<double>& out){std::fill(out.begin(),out.end(),0.0);for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)if(boundary[vi])out[vi]=in[vi];for(const auto& e:constraints){if(!boundary[e.a])out[e.a]+=e.weight*(in[e.a]-(boundary[e.b]?0.0:in[e.b]));if(!boundary[e.b])out[e.b]+=e.weight*(in[e.b]-(boundary[e.a]?0.0:in[e.a]));}};
                    for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)candidateV[vi]=boundary[vi]?rhsV[vi]:double(relaxMesh.vertexArray[vi].uv[1]);
                    apply(candidateV,ad);double rr=0.0,bb=0.0;
                    for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){r[vi]=rhsV[vi]-ad[vi];if(boundary[vi])r[vi]=0.0;d[vi]=r[vi];rr+=r[vi]*r[vi];bb+=rhsV[vi]*rhsV[vi];}
                    const double target=std::max(1.0e-24,bb*1.0e-16);
                    for(uint32_t it=0;it<64u&&rr>target;++it){apply(d,ad);double denom=0.0;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)denom+=d[vi]*ad[vi];if(!(denom>1.0e-30))break;const double alpha=rr/denom;double next=0.0;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){candidateV[vi]+=alpha*d[vi];r[vi]-=alpha*ad[vi];next+=r[vi]*r[vi];}if(!std::isfinite(next))return false;const double beta=next/std::max(rr,1.0e-30);for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)d[vi]=r[vi]+beta*d[vi];rr=next;}return std::isfinite(rr)&&(rr<=std::max(target,bb*1.0e-10));};
                if(!solveV())break;
                for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){iterUv[size_t(vi)*2u]=relaxMesh.vertexArray[vi].uv[0];iterUv[size_t(vi)*2u+1u]=relaxMesh.vertexArray[vi].uv[1];}
                const double before=evaluateRelax(false);bool accepted=false;
                for(uint32_t ls=0;ls<9u;++ls){const double alpha=std::ldexp(1.0,-int(ls));for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){relaxMesh.vertexArray[vi].uv[0]=float(iterUv[size_t(vi)*2u]+alpha*(candidateU[vi]-iterUv[size_t(vi)*2u]));relaxMesh.vertexArray[vi].uv[1]=float(iterUv[size_t(vi)*2u+1u]+alpha*(candidateV[vi]-iterUv[size_t(vi)*2u+1u]));}const double trial=evaluateRelax(false);if(std::isfinite(trial)&&trial+1.0e-10<before){accepted=true;++localGlobalIterations;break;}}
                if(!accepted){for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){relaxMesh.vertexArray[vi].uv[0]=float(iterUv[size_t(vi)*2u]);relaxMesh.vertexArray[vi].uv[1]=float(iterUv[size_t(vi)*2u+1u]);}break;}
                for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){iterUv[size_t(vi)*2u]=relaxMesh.vertexArray[vi].uv[0];iterUv[size_t(vi)*2u+1u]=relaxMesh.vertexArray[vi].uv[1];}
            }
        }
        // Use a fixed area normalization in the gradient (rather than per-loop
        // partial sums) to make the descent step independent of triangle order.
        if(relaxTris.size()>=2u && relaxTris.size()<=20000u && totalSourceArea>0.0 && relaxScale>1.0e-20){
            // The evaluator's gradient is accumulated with area weights; normalize
            // it once after each pass. Keep only interior vertices movable.
            double currentEnergy=evaluateRelax(true);
            for(uint32_t iteration=0;iteration<12u && std::isfinite(currentEnergy);++iteration){
                double maxGradient=0.0;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){if(boundary[vi]){gx[vi]=gy[vi]=0.0;continue;}maxGradient=std::max(maxGradient,std::sqrt(gx[vi]*gx[vi]+gy[vi]*gy[vi]));}
                if(maxGradient<1.0e-10)break;
                const double baseStep=std::min(0.015*double(std::min(atlas->width,atlas->height))/maxGradient,1.0e6);bool accepted=false;
                for(uint32_t line=0;line<7u;++line){const double step=baseStep*std::ldexp(1.0,-int(line));// Restore the current iterate from a compact snapshot, then take
                    // one simultaneous gradient step.
                    for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi)if(!boundary[vi]){relaxMesh.vertexArray[vi].uv[0]=float(iterUv[size_t(vi)*2u]);relaxMesh.vertexArray[vi].uv[1]=float(iterUv[size_t(vi)*2u+1u]);relaxMesh.vertexArray[vi].uv[0]-=float(step*gx[vi]);relaxMesh.vertexArray[vi].uv[1]-=float(step*gy[vi]);}
                    const double trialEnergy=evaluateRelax(false);if(std::isfinite(trialEnergy)&&trialEnergy+1.0e-10<currentEnergy){currentEnergy=trialEnergy;for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){iterUv[size_t(vi)*2u]=relaxMesh.vertexArray[vi].uv[0];iterUv[size_t(vi)*2u+1u]=relaxMesh.vertexArray[vi].uv[1];}accepted=true;++slimRelaxIterations;break;}}
                if(!accepted)break;
                evaluateRelax(true);
            }
            if(slimRelaxIterations||localGlobalIterations){const auto relaxed=measureAtlasDistortion();const double relaxedObjective=distortionObjective(relaxed,relaxMesh.chartCount,baselineChartCount);if(relaxed.validTriangles==selectedDistortion.validTriangles&&relaxedObjective+1.0e-8<selectedObjective){selectedDistortion=relaxed;selectedObjective=relaxedObjective;slimRelaxAfter=relaxed.symmetricDirichlet;}else{for(uint32_t vi=0;vi<relaxMesh.vertexCount;++vi){relaxMesh.vertexArray[vi].uv[0]=originalUv[size_t(vi)*2u];relaxMesh.vertexArray[vi].uv[1]=originalUv[size_t(vi)*2u+1u];}slimRelaxIterations=0u;localGlobalIterations=0u;}}
        }
    }


    kuroSetCrashContext("Auto UV: validate final xatlas output");kuroWriteUVTraceAt("phase: final xatlas output validation begin");
    if(atlas->meshCount==0||!atlas->meshes||atlas->width==0||atlas->height==0){
        const uint32_t emptyMeshCount=atlas->meshCount,emptyChartCount=atlas->chartCount;
        const uint32_t emptyWidth=atlas->width,emptyHeight=atlas->height;
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas produced no atlas");
        std::ostringstream emptyAtlasLog;
        emptyAtlasLog<<"xatlas returned an empty atlas; mesh_count="<<emptyMeshCount
            <<" chart_count="<<emptyChartCount<<" size="<<emptyWidth<<"x"<<emptyHeight
            <<"; "<<xatlasInputDiagnostic;
        logWarning("UV",emptyAtlasLog.str());
        return;
    }
    const xatlas::Mesh& result=atlas->meshes[0];
    size_t xatlasValidOutputVertices=0u,xatlasInvalidChartVertices=0u,xatlasNonFiniteOutputUV=0u;
    if(result.vertexArray)for(uint32_t vi=0;vi<result.vertexCount;++vi){
        const auto& vertex=result.vertexArray[vi];
        if(vertex.atlasIndex>=0&&vertex.chartIndex>=0)++xatlasValidOutputVertices;
        else ++xatlasInvalidChartVertices;
        if(!std::isfinite(vertex.uv[0])||!std::isfinite(vertex.uv[1]))++xatlasNonFiniteOutputUV;
    }
    if(!result.vertexArray||!result.indexArray||result.indexCount!=indices.size()){
        xatlas::Destroy(atlas);
        setStatus("Auto UV: xatlas output was incomplete");
        logWarning("UV","xatlas output index/vertex array mismatch");
        return;
    }
    kuroSetCrashContext("Auto UV: begin xatlas UV remapping");kuroWriteUVTraceAt("phase: xatlas UV remapping begin");
    // xatlas preserves source triangle index slots. Keep its UV per output
    // triangle corner as the authoritative result: unlike faceCornerUV, this
    // representation can express a chart seam along an n-gon's internal
    // triangulation diagonal. faceCornerUV below remains a compatibility view
    // for polygon-corner tools and is not used to validate triangle orientation.
    std::vector<std::pair<float,float>> xatlasTriangleUV(indices.size(),{0.0f,0.0f});
    bool xatlasTriangleUVValid=true;
    for(size_t slot=0;slot<indices.size();++slot){
        const uint32_t oi=result.indexArray[slot];
        if(oi>=result.vertexCount){xatlasTriangleUVValid=false;break;}
        const auto& v=result.vertexArray[oi];
        const float u=v.uv[0]/float(std::max(1u,atlas->width));
        const float vv=v.uv[1]/float(std::max(1u,atlas->height));
        if(!std::isfinite(u)||!std::isfinite(vv)){xatlasTriangleUVValid=false;break;}
        xatlasTriangleUV[slot]={u,vv};
    }
    // First determine the dominant chart for each original polygon, then choose
    // a best-effort polygon-corner compatibility view for legacy UV editing.
    struct UVCandidate { int chart; float u,v; bool fromVertexPool=false; };
    // Flat, sortable face/chart votes avoid one unordered_map and unordered_set
    // allocation per source face. This matters for dense meshes with many triangles.
    std::vector<std::pair<uint64_t,uint32_t>> faceChartVotePairs;
    faceChartVotePairs.reserve(sourceFaceForTriangle.size());
    for(size_t ti=0;ti<sourceFaceForTriangle.size();++ti){
        const size_t slot=ti*3;
        if(slot+2>=result.indexCount)continue;
        const uint32_t outIndex=result.indexArray[slot];
        if(outIndex>=result.vertexCount)continue;
        const uint32_t fi=sourceFaceForTriangle[ti];
        const int chart=result.vertexArray[outIndex].chartIndex;
        if(chart<0)continue;
        faceChartVotePairs.push_back({(uint64_t(fi)<<32)|uint32_t(chart),1u});
    }
    std::sort(faceChartVotePairs.begin(),faceChartVotePairs.end(),[](const auto&a,const auto&b){return a.first<b.first;});
    std::vector<std::pair<uint64_t,uint32_t>> faceChartVotes;
    faceChartVotes.reserve(faceChartVotePairs.size());
    for(const auto& vote:faceChartVotePairs){
        if(!faceChartVotes.empty()&&faceChartVotes.back().first==vote.first)++faceChartVotes.back().second;
        else faceChartVotes.push_back(vote);
    }
    std::vector<int> dominantChart((size_t)nf,-1);
    size_t faceChartSplits=0;
    std::vector<uint32_t> faceChartKinds((size_t)nf,0u);
    for(const auto& entry:faceChartVotes){
        const uint32_t fi=(uint32_t)(entry.first>>32);
        const int chart=(int)(uint32_t)entry.first;
        if(fi>=(uint32_t)nf)continue;
        ++faceChartKinds[fi];
        if(dominantChart[fi]<0){dominantChart[fi]=chart;continue;}
        const uint64_t key=(uint64_t(fi)<<32)|uint32_t(dominantChart[fi]);
        auto it=std::lower_bound(faceChartVotes.begin(),faceChartVotes.end(),key,[](const auto&v,uint64_t k){return v.first<k;});
        if(it!=faceChartVotes.end()&&it->first==key&&entry.second>it->second)dominantChart[fi]=chart;
    }
    for(uint32_t count:faceChartKinds)if(count>1u)++faceChartSplits;
    auto faceChartVoteCount=[&](uint32_t fi,int chart)->uint32_t{
        if(fi>=(uint32_t)nf||chart<0)return 0u;
        const uint64_t key=(uint64_t(fi)<<32)|uint32_t(chart);
        auto it=std::lower_bound(faceChartVotes.begin(),faceChartVotes.end(),key,[](const auto&v,uint64_t k){return v.first<k;});
        return (it!=faceChartVotes.end()&&it->first==key)?it->second:0u;
    };
    std::vector<std::vector<UVCandidate>> candidates(allCorners);
    size_t rawUVWriteConflicts=0;
    size_t invalidXrefCount=0;
    size_t xrefSlotMismatches=0;
    for(size_t i=0;i<result.indexCount;++i){
        const uint32_t outIndex=result.indexArray[i];
        if(outIndex>=result.vertexCount)continue;
        const xatlas::Vertex& v=result.vertexArray[outIndex];
        // xatlas preserves the source triangle/index slot in indexArray: its
        // output writer stores each triangle at mapFaceToSourceFace(f) * 3.
        // Vertex::xref is NOT a reliable corner identity here: xatlas can merge
        // colocal input vertices and xref then points at the representative input
        // vertex, which may belong to a different polygon corner / UV island.
        // Resolve this output corner through the original input index slot instead.
        const uint32_t inputIndex=indices[i];
        if(inputIndex>=originalCornerForInput.size()){++invalidXrefCount;continue;}
        if(v.xref!=inputIndex)++xrefSlotMismatches;
        const size_t corner=originalCornerForInput[inputIndex];
        if(corner>=allCorners)continue;
        if(v.atlasIndex<0||v.chartIndex<0||!std::isfinite(v.uv[0])||!std::isfinite(v.uv[1]))continue;
        float u=0.0f,vv=0.0f;
        if(!kuro::uvpacking::normalizeAtlasCoordinate(v.uv[0],v.uv[1],
                (float)atlas->width,(float)atlas->height,u,vv))continue;
        auto& list=candidates[corner];
        bool duplicate=false;
        for(const auto& c:list){
            if(c.chart==v.chartIndex){
                if(std::fabs(c.u-u)>1e-4f||std::fabs(c.v-vv)>1e-4f)++rawUVWriteConflicts;
                duplicate=true;break;
            }
        }
        if(!duplicate)list.push_back({v.chartIndex,u,vv,false});
    }
    // A source vertex can have a chart-local UV on a neighboring face corner
    // even when xatlas did not emit that chart candidate for this exact corner
    // copy. Borrow only when a real uncut source edge supports that chart at
    // both endpoints; vertex-fan adjacency alone must never weld UV islands.
    struct VertexChartCandidate { uint32_t vertex; int chart; uint32_t face; float u,v; };
    std::vector<VertexChartCandidate> vertexChartPool;
    vertexChartPool.reserve(inputMeshVertex.size());
    for(size_t input=0;input<inputMeshVertex.size()&&input<originalCornerForInput.size();++input){
        const uint32_t vertex=inputMeshVertex[input];
        const size_t corner=originalCornerForInput[input];
        if(corner>=candidates.size()||corner>=sourceFaceForCorner.size())continue;
        const uint32_t face=sourceFaceForCorner[corner];
        if(face>=(uint32_t)nf)continue;
        for(const auto& candidate:candidates[corner])
            vertexChartPool.push_back({vertex,candidate.chart,face,candidate.u,candidate.v});
    }
    std::sort(vertexChartPool.begin(),vertexChartPool.end(),[](const auto&a,const auto&b){
        if(a.vertex!=b.vertex)return a.vertex<b.vertex;
        if(a.chart!=b.chart)return a.chart<b.chart;
        return a.face<b.face;
    });
    struct VertexFaceEdgePair { uint32_t vertex,lo,hi,otherVertex; };
    std::vector<VertexFaceEdgePair> vertexFaceEdgePairs;
    if(m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u&&m.edgeFaceOffsets.back()<=m.edgeFaces.size()){
        for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
            if(ei<edgeBlocked.size()&&(edgeBlocked[ei]||
               (ei<selectedCutGraph.size()&&selectedCutGraph[ei])))continue;
            const auto edge=m.uniqueEdges[ei];
            const uint32_t begin=m.edgeFaceOffsets[ei],end=m.edgeFaceOffsets[ei+1u];
            if(end>m.edgeFaces.size()||end-begin<2u)continue;
            for(uint32_t ai=begin;ai<end;++ai)for(uint32_t bi=ai+1u;bi<end;++bi){
                const int fa=m.edgeFaces[ai],fb=m.edgeFaces[bi];
                if(fa<0||fb<0||fa==fb||(uint32_t)fa>=(uint32_t)nf||(uint32_t)fb>=(uint32_t)nf)continue;
                const uint32_t lo=(uint32_t)std::min(fa,fb),hi=(uint32_t)std::max(fa,fb);
                vertexFaceEdgePairs.push_back({edge.first,lo,hi,edge.second});
                vertexFaceEdgePairs.push_back({edge.second,lo,hi,edge.first});
            }
        }
        std::sort(vertexFaceEdgePairs.begin(),vertexFaceEdgePairs.end(),[](const auto&a,const auto&b){
            if(a.vertex!=b.vertex)return a.vertex<b.vertex;
            if(a.lo!=b.lo)return a.lo<b.lo;
            if(a.hi!=b.hi)return a.hi<b.hi;
            return a.otherVertex<b.otherVertex;
        });
        vertexFaceEdgePairs.erase(std::unique(vertexFaceEdgePairs.begin(),vertexFaceEdgePairs.end(),[](const auto&a,const auto&b){
            return a.vertex==b.vertex&&a.lo==b.lo&&a.hi==b.hi&&a.otherVertex==b.otherVertex;
        }),vertexFaceEdgePairs.end());
    }
    std::vector<uint32_t> vertexPoolFaceCornerBase((size_t)nf+1u,0u);
    for(int fi=0;fi<nf;++fi)
        vertexPoolFaceCornerBase[(size_t)fi+1u]=vertexPoolFaceCornerBase[(size_t)fi]+(uint32_t)m.faces[(size_t)fi].size();
    auto findVertexPoolFaceCorner=[&](uint32_t fi,uint32_t vertex)->size_t{
        if(fi>=(uint32_t)nf)return SIZE_MAX;
        const auto& face=m.faces[fi];
        for(size_t k=0;k<face.size();++k)if(face[k]==vertex)
            return (size_t)vertexPoolFaceCornerBase[fi]+k;
        return SIZE_MAX;
    };
    auto facesShareFullEdgeForChart=[&](uint32_t vertex,uint32_t a,uint32_t b,int chart){
        if(a==b||chart<0)return false;
        const uint32_t lo=std::min(a,b),hi=std::max(a,b);
        const auto first=std::lower_bound(vertexFaceEdgePairs.begin(),vertexFaceEdgePairs.end(),vertex,
            [](const VertexFaceEdgePair& x,uint32_t v){return x.vertex<v;});
        for(auto it=first;it!=vertexFaceEdgePairs.end()&&it->vertex==vertex;++it){
            if(it->lo!=lo||it->hi!=hi)continue;
            // Borrowing a chart UV at one endpoint is safe only if that same
            // chart is already present and agrees at the other endpoint of the
            // very same uncut source edge. A mere vertex fan connection can
            // otherwise pull one corner onto a neighboring island.
            const size_t targetOther=findVertexPoolFaceCorner(a,it->otherVertex);
            const size_t sourceOther=findVertexPoolFaceCorner(b,it->otherVertex);
            if(targetOther==SIZE_MAX||sourceOther==SIZE_MAX)continue;
            const auto findChartUV=[&](size_t corner,float& u,float& v){
                if(corner>=candidates.size())return false;
                for(const auto& candidate:candidates[corner])if(candidate.chart==chart){u=candidate.u;v=candidate.v;return true;}
                return false;
            };
            float targetU=0.0f,targetV=0.0f,sourceU=0.0f,sourceV=0.0f;
            if(!findChartUV(targetOther,targetU,targetV)||!findChartUV(sourceOther,sourceU,sourceV))continue;
            if(std::fabs(targetU-sourceU)<=1.0e-4f&&std::fabs(targetV-sourceV)<=1.0e-4f)return true;
        }
        return false;
    };
    size_t vertexChartPoolBorrowed=0u,vertexChartPoolAmbiguous=0u;
    struct BorrowedChart { int chart; float u,v; bool ambiguous; };
    std::vector<BorrowedChart> borrowedChartScratch;
    borrowedChartScratch.reserve(8u);
    if(!vertexFaceEdgePairs.empty()){
        for(size_t input=0;input<inputMeshVertex.size()&&input<originalCornerForInput.size();++input){
            const uint32_t vertex=inputMeshVertex[input];
            const size_t corner=originalCornerForInput[input];
            if(corner>=candidates.size()||corner>=sourceFaceForCorner.size())continue;
            const uint32_t targetFace=sourceFaceForCorner[corner];
            if(targetFace>=(uint32_t)nf||faceChartKinds[targetFace]<=1u)continue;
            auto it=std::lower_bound(vertexChartPool.begin(),vertexChartPool.end(),vertex,
                [](const VertexChartCandidate& a,uint32_t v){return a.vertex<v;});
            auto& borrowed=borrowedChartScratch;
            borrowed.clear();
            for(;it!=vertexChartPool.end()&&it->vertex==vertex;++it){
                if(it->face==targetFace||!facesShareFullEdgeForChart(vertex,targetFace,it->face,it->chart))continue;
                auto local=std::find_if(candidates[corner].begin(),candidates[corner].end(),
                    [&](const UVCandidate& c){return c.chart==it->chart;});
                if(local!=candidates[corner].end())continue;
                auto existing=std::find_if(borrowed.begin(),borrowed.end(),
                    [&](const BorrowedChart& c){return c.chart==it->chart;});
                if(existing==borrowed.end())borrowed.push_back({it->chart,it->u,it->v,false});
                else if(std::fabs(existing->u-it->u)>1.0e-4f||std::fabs(existing->v-it->v)>1.0e-4f)
                    existing->ambiguous=true;
            }
            for(const auto& candidate:borrowed){
                if(candidate.ambiguous){++vertexChartPoolAmbiguous;continue;}
                candidates[corner].push_back({candidate.chart,candidate.u,candidate.v,true});
                ++vertexChartPoolBorrowed;
            }
        }
    }
    std::vector<std::pair<float,float>> newUV(allCorners,{0.0f,0.0f});
    // Keep the chosen xatlas chart for every source corner. UV coordinates alone
    // are not a sufficient topology key: two separately packed charts can
    // occasionally land on numerically coincident boundary coordinates.
    std::vector<int32_t> cornerChart(allCorners,-1);
    size_t unresolvedCornerConflicts=0;
    size_t missingCornerUV=0;
    for(size_t corner=0;corner<allCorners;++corner){
        // Invalid/skipped source polygons intentionally have no generated UVs.
        if(sourceFaceForCorner[corner]==UINT32_MAX)continue;
        const auto& list=candidates[corner];
        if(list.empty()){++missingCornerUV;continue;}
        const uint32_t fi=sourceFaceForCorner[corner];
        const int preferred=(fi<(uint32_t)nf)?dominantChart[fi]:-1;
        const UVCandidate* chosen=nullptr;
        for(const auto& c:list)if(c.chart==preferred){chosen=&c;break;}
        if(!chosen){
            // Rare fallback: prefer the chart with the most triangles on this face.
            uint32_t bestVotes=0;
            for(const auto& c:list){
                const uint32_t votes=faceChartVoteCount(fi,c.chart);
                if(!chosen||votes>bestVotes){chosen=&c;bestVotes=votes;}
            }
        }
        if(chosen){newUV[corner]={chosen->u,chosen->v};cornerChart[corner]=chosen->chart;if(list.size()>1)++unresolvedCornerConflicts;}
    }
    // A source quad/ngon may have its triangulation split across xatlas charts.
    // A single UV per original polygon corner cannot represent an internal seam
    // along the triangulation diagonal. When both sides offer a candidate for a
    // shared corner, choose the assignment that best preserves each triangle's
    // own xatlas edge vectors. This avoids arbitrarily pulling a corner toward
    // the other packed chart; winding and degeneracy remain hard priorities.
    size_t repairedFaceChartFlips=0;
    size_t chartAssignmentTrials=0;
    size_t splitFaceInternalSeamUnrepresentable=0;
    std::vector<std::vector<size_t>> faceCornerIndices((size_t)nf);
    for(size_t corner=0;corner<allCorners;++corner){const uint32_t fi=sourceFaceForCorner[corner];if(fi<(uint32_t)nf)faceCornerIndices[fi].push_back(corner);}
    std::vector<std::vector<size_t>> faceTriangleSlots((size_t)nf);
    for(size_t slot=0;slot+2u<indices.size();slot+=3u){
        const uint32_t ia=indices[slot];if(ia>=originalCornerForInput.size())continue;
        const size_t ca=originalCornerForInput[ia];if(ca>=sourceFaceForCorner.size())continue;
        const uint32_t fi=sourceFaceForCorner[ca];if(fi<(uint32_t)nf)faceTriangleSlots[fi].push_back(slot);
    }
    // Reuse full-mesh scratch buffers across split faces. The scorer only reads
    // the current face's corners, so copying every UV/chart entry for every
    // split polygon was unnecessary O(splitFaces * allCorners) memory traffic.
    std::vector<std::pair<float,float>> trialUV=newUV;
    std::vector<int32_t> trialCharts=cornerChart;
    for(uint32_t fi=0;fi<(uint32_t)nf;++fi){
        if(faceChartKinds[fi]<=1u||faceTriangleSlots[fi].empty())continue;
        const auto& faceCorners=faceCornerIndices[fi];
        if(faceCorners.size()<3u)continue;
        auto scoreAssignment=[&](const std::vector<std::pair<float,float>>& uv,const std::vector<int32_t>& charts){
            uint32_t flipped=0u,collapsed=0u,mixed=0u;
            double mappingError=0.0;
            for(size_t slot:faceTriangleSlots[fi]){
                const uint32_t ia=indices[slot],ib=indices[slot+1u],ic=indices[slot+2u];
                if(ia>=originalCornerForInput.size()||ib>=originalCornerForInput.size()||ic>=originalCornerForInput.size())continue;
                const size_t ca=originalCornerForInput[ia],cb=originalCornerForInput[ib],cc=originalCornerForInput[ic];
                if(ca>=uv.size()||cb>=uv.size()||cc>=uv.size())continue;
                if(sourceFaceForCorner[ca]!=fi||sourceFaceForCorner[cb]!=fi||sourceFaceForCorner[cc]!=fi)continue;
                const double area=(double(uv[cb].first)-uv[ca].first)*(double(uv[cc].second)-uv[ca].second)-(double(uv[cb].second)-uv[ca].second)*(double(uv[cc].first)-uv[ca].first);
                const uint32_t oa=result.indexArray[slot],ob=result.indexArray[slot+1u],oc=result.indexArray[slot+2u];
                if(oa>=result.vertexCount||ob>=result.vertexCount||oc>=result.vertexCount)continue;
                const auto& xa=result.vertexArray[oa];const auto& xb=result.vertexArray[ob];const auto& xc=result.vertexArray[oc];
                const double atlasArea=(double(xb.uv[0])-xa.uv[0])*(double(xc.uv[1])-xa.uv[1])-(double(xb.uv[1])-xa.uv[1])*(double(xc.uv[0])-xa.uv[0]);
                if(!std::isfinite(area)||std::fabs(area)<1.0e-10){++collapsed;continue;}
                if(std::isfinite(atlasArea)&&std::fabs(atlasArea)>1.0e-10&&((atlasArea<0.0)!=(area<0.0)))++flipped;
                const double rawAx=double(xa.uv[0])/std::max(1u,atlas->width),rawAy=double(xa.uv[1])/std::max(1u,atlas->height);
                const double rawBx=double(xb.uv[0])/std::max(1u,atlas->width),rawBy=double(xb.uv[1])/std::max(1u,atlas->height);
                const double rawCx=double(xc.uv[0])/std::max(1u,atlas->width),rawCy=double(xc.uv[1])/std::max(1u,atlas->height);
                auto edgeMappingError=[&](size_t a,size_t b,double ax,double ay,double bx,double by){
                    const double sx=double(uv[b].first)-uv[a].first,sy=double(uv[b].second)-uv[a].second;
                    const double rx=bx-ax,ry=by-ay,denom=rx*rx+ry*ry;
                    if(!std::isfinite(sx)||!std::isfinite(sy)||!std::isfinite(denom)||denom<=1.0e-16)return 0.0;
                    const double dx=sx-rx,dy=sy-ry;return (dx*dx+dy*dy)/denom;
                };
                mappingError+=edgeMappingError(ca,cb,rawAx,rawAy,rawBx,rawBy)+
                              edgeMappingError(cb,cc,rawBx,rawBy,rawCx,rawCy)+
                              edgeMappingError(cc,ca,rawCx,rawCy,rawAx,rawAy);
                if(charts[ca]!=charts[cb]||charts[ca]!=charts[cc])++mixed;
            }
            // A source polygon is indivisible in Mesh::faceCornerUV. First reject
            // collapsed/flipped assignments, then minimize the UV displacement
            // from each triangle's own xatlas chart mapping. Mixed-chart count is
            // only a tie-breaker: forcing a single chart label must not stretch a
            // valid triangle across the atlas. The final safety gate remains active.
            return std::array<double,4>{double(collapsed),double(flipped),mappingError,double(mixed)};
        };
        const auto currentScore=scoreAssignment(newUV,cornerChart);
        auto bestScore=currentScore;
        std::vector<std::pair<float,float>> bestFaceUV(faceCorners.size());
        std::vector<int32_t> bestFaceCharts(faceCorners.size(),-1);
        bool haveBestFaceAssignment=false;
        // A chart-wide choice is insufficient when xatlas split the two
        // triangles of one source quad: no single chart necessarily contains
        // all four original corners. Search the actual candidate combinations
        // per polygon corner (bounded to keep large ngons predictable), and
        // score the complete source-face triangulation. This preserves the
        // original polygon-corner data model while avoiding arbitrary mixing.
        std::vector<std::vector<const UVCandidate*>> options(faceCorners.size());
        size_t combinationCount=1u;
        for(size_t k=0;k<faceCorners.size();++k){
            const size_t corner=faceCorners[k];
            for(const auto& candidate:candidates[corner])options[k].push_back(&candidate);
            if(options[k].empty())options[k].push_back(nullptr);
            if(combinationCount<=4096u)combinationCount*=options[k].size();
        }
        const size_t maxTrials=4096u;
        size_t trials=0u;
        // Iterative mixed-radix enumeration avoids recursion depth proportional
        // to polygon corner count. The trial budget remains deterministic and
        // bounds CPU work even when xatlas emits many candidates per corner.
        std::vector<size_t> choice(faceCorners.size(),0u);
        bool moreAssignments=!faceCorners.empty();
        while(moreAssignments&&trials<maxTrials){
            for(size_t depth=0;depth<faceCorners.size();++depth){
                const size_t corner=faceCorners[depth];
                const UVCandidate* candidate=options[depth][choice[depth]];
                if(candidate){trialUV[corner]={candidate->u,candidate->v};trialCharts[corner]=candidate->chart;}
                else {trialUV[corner]=newUV[corner];trialCharts[corner]=cornerChart[corner];}
            }
            ++trials;
            const auto score=scoreAssignment(trialUV,trialCharts);
            if(score<bestScore){
                bestScore=score;haveBestFaceAssignment=true;
                for(size_t k=0;k<faceCorners.size();++k){
                    const size_t corner=faceCorners[k];
                    bestFaceUV[k]=trialUV[corner];bestFaceCharts[k]=trialCharts[corner];
                }
            }
            moreAssignments=false;
            for(size_t depth=choice.size();depth>0u;--depth){
                const size_t i=depth-1u;
                if(++choice[i]<options[i].size()){moreAssignments=true;break;}
                choice[i]=0u;
            }
        }
        (void)combinationCount;
        chartAssignmentTrials+=trials;
        // If every per-face corner assignment still flips at least one of its
        // xatlas triangles, the source polygon data model cannot encode the
        // internal chart seam: one original corner would need two UV values.
        // Keep the final safety gate strict and expose this separately in logs.
        if(bestScore[0]<=0.0&&bestScore[1]>0.0)++splitFaceInternalSeamUnrepresentable;
        if(haveBestFaceAssignment){
            if(currentScore[1]>bestScore[1])repairedFaceChartFlips+=(size_t)(currentScore[1]-bestScore[1]);
            for(size_t k=0;k<faceCorners.size();++k){
                const size_t corner=faceCorners[k];
                newUV[corner]=bestFaceUV[k];cornerChart[corner]=bestFaceCharts[k];
            }
        }
    }
    // Detailed trace for the rare case where xatlas assigns triangles from one
    // original polygon to multiple charts. Kuro3D stores UVs per original polygon
    // corner, so this trace exposes exactly which source corners need reconciliation.
    if(settings.detailedDiagnostics){
        std::ostringstream splitFaceTrace;
        size_t tracedFaces=0;
        for(uint32_t fi=0;fi<(uint32_t)nf&&tracedFaces<16u;++fi){
            if(faceChartKinds[fi]<=1u||faceTriangleSlots[fi].empty())continue;
            ++tracedFaces;
            splitFaceTrace<<"xatlas split-face trace face="<<fi<<" source_vertices=[";
            const auto& face=m.faces[fi];
            for(size_t k=0;k<face.size();++k){
                if(k)splitFaceTrace<<';';
                const uint32_t vi=face[k];
                splitFaceTrace<<vi;
                if(vi<m.vertices.size()){
                    const Vec3& p=m.vertices[vi];
                    splitFaceTrace<<'@'<<p.x<<','<<p.y<<','<<p.z;
                }
            }
            splitFaceTrace<<"] chart_votes=[";
            bool firstVote=true;
            for(const auto& vote:faceChartVotes){
                if((uint32_t)(vote.first>>32)!=fi)continue;
                if(!firstVote)splitFaceTrace<<';';
                firstVote=false;
                splitFaceTrace<<(uint32_t)vote.first<<':'<<vote.second;
            }
            splitFaceTrace<<"] triangles=[";
            for(size_t ti=0;ti<faceTriangleSlots[fi].size();++ti){
                if(ti)splitFaceTrace<<';';
                const size_t slot=faceTriangleSlots[fi][ti];
                splitFaceTrace<<"tri"<<(slot/3u)<<'(';
                for(size_t k=0;k<3u;++k){
                    if(k)splitFaceTrace<<',';
                    const uint32_t input=indices[slot+k];
                    const uint32_t out=result.indexArray[slot+k];
                    splitFaceTrace<<"in"<<input;
                    if(input<originalCornerForInput.size()){
                        const size_t corner=originalCornerForInput[input];
                        if(corner<sourceFaceForCorner.size()&&corner<newUV.size())
                            splitFaceTrace<<"/v"<<inputMeshVertex[input]<<"/c"<<cornerChart[corner]
                                <<"/uv"<<newUV[corner].first<<','<<newUV[corner].second;
                    }
                    if(out<result.vertexCount){
                        const auto& xv=result.vertexArray[out];
                        splitFaceTrace<<"/out"<<out<<"/chart"<<xv.chartIndex
                            <<"/xref"<<xv.xref<<"/raw"<<xv.uv[0]/(float)atlas->width
                            <<','<<xv.uv[1]/(float)atlas->height;
                    }
                }
                splitFaceTrace<<')';
            }
            splitFaceTrace<<"] corner_candidates=[";
            for(size_t k=0;k<faceCornerIndices[fi].size();++k){
                if(k)splitFaceTrace<<';';
                const size_t corner=faceCornerIndices[fi][k];
                splitFaceTrace<<"corner"<<corner<<"/v"<<face[k]<<"/selected"<<cornerChart[corner]
                    <<"/uv"<<newUV[corner].first<<','<<newUV[corner].second<<"/candidates{";
                for(size_t ci=0;ci<candidates[corner].size();++ci){
                    if(ci)splitFaceTrace<<';';
                    const auto& candidate=candidates[corner][ci];
                    splitFaceTrace<<candidate.chart<<':'<<candidate.u<<','<<candidate.v
                        <<(candidate.fromVertexPool?"/vertex-pool":"");
                }
                splitFaceTrace<<'}';
            }
            splitFaceTrace<<']';
            logInfo("UV",splitFaceTrace.str());
            splitFaceTrace.str(std::string());
            splitFaceTrace.clear();
        }
    }

    // Build the actual UV face components from complete matching edges, then
    // detect coordinates shared by distinct components. Do not compare every
    // pair of faces in a vertex fan: faces two or more steps apart are expected
    // not to share an edge even though they belong to the same island. Also do
    // not key this test by source vertex ID; reconciliation can accidentally
    // place corners from unrelated source vertices at the same atlas position.
    size_t pointOnlyUVContacts=0;
    size_t pointOnlySameChartContacts=0;
    size_t pointOnlyCrossChartContacts=0;
    size_t pointOnlyDistinctSourceVertexContacts=0;
    size_t pointOnlyContactCoordinates=0;
    struct UVPointContactRecord { uint32_t faceA,faceB; size_t cornerA,cornerB; int32_t chartA,chartB; };
    std::vector<UVPointContactRecord> pointOnlyContactTrace;
    pointOnlyContactTrace.reserve(32u);
    if(m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u &&
       m.edgeFaceOffsets.back()<=m.edgeFaces.size()){
        std::vector<uint32_t> faceCornerBase((size_t)nf+1u,0u);
        std::vector<uint32_t> sourceVertexForCorner(allCorners,UINT32_MAX);
        for(int fi=0;fi<nf;++fi){
            faceCornerBase[(size_t)fi+1u]=faceCornerBase[(size_t)fi]+(uint32_t)m.faces[(size_t)fi].size();
            for(size_t k=0;k<m.faces[(size_t)fi].size();++k){
                const size_t corner=(size_t)faceCornerBase[(size_t)fi]+k;
                if(corner<sourceVertexForCorner.size())sourceVertexForCorner[corner]=m.faces[(size_t)fi][k];
            }
        }
        auto findFaceCorner=[&](int fi,uint32_t vertex)->size_t{
            if(fi<0||fi>=nf)return SIZE_MAX;
            const auto& face=m.faces[(size_t)fi];
            for(size_t k=0;k<face.size();++k)if(face[k]==vertex)
                return (size_t)faceCornerBase[(size_t)fi]+k;
            return SIZE_MAX;
        };
        auto sameUV=[&](size_t a,size_t b){return a<newUV.size()&&b<newUV.size()&&
            std::fabs(newUV[a].first-newUV[b].first)<=1.0e-6f&&
            std::fabs(newUV[a].second-newUV[b].second)<=1.0e-6f;};
        std::vector<uint32_t> parent((size_t)nf),rank((size_t)nf,0u);
        for(uint32_t fi=0;fi<(uint32_t)nf;++fi)parent[fi]=fi;
        auto findRoot=[&](uint32_t x){
            uint32_t root=x;
            while(parent[root]!=root)root=parent[root];
            while(parent[x]!=x){const uint32_t next=parent[x];parent[x]=root;x=next;}
            return root;
        };
        auto unite=[&](uint32_t a,uint32_t b){
            a=findRoot(a);b=findRoot(b);if(a==b)return;
            if(rank[a]<rank[b])std::swap(a,b);
            parent[b]=a;if(rank[a]==rank[b])++rank[a];
        };
        // A face pair belongs to one UV island only when the complete source
        // edge maps to the same two UV endpoints on both faces.
        for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
            const auto edge=m.uniqueEdges[ei];
            const uint32_t begin=m.edgeFaceOffsets[ei],end=m.edgeFaceOffsets[ei+1u];
            if(end>m.edgeFaces.size()||end-begin<2u)continue;
            for(uint32_t ai=begin;ai<end;++ai)for(uint32_t bi=ai+1u;bi<end;++bi){
                const int fa=m.edgeFaces[ai],fb=m.edgeFaces[bi];
                if(fa<0||fb<0||fa==fb||(uint32_t)fa>=(uint32_t)nf||(uint32_t)fb>=(uint32_t)nf)continue;
                const size_t a0=findFaceCorner(fa,edge.first),a1=findFaceCorner(fa,edge.second);
                const size_t b0=findFaceCorner(fb,edge.first),b1=findFaceCorner(fb,edge.second);
                if(a0==SIZE_MAX||a1==SIZE_MAX||b0==SIZE_MAX||b1==SIZE_MAX)continue;
                if(sameUV(a0,b0)&&sameUV(a1,b1))unite((uint32_t)fa,(uint32_t)fb);
            }
        }
        struct UVPointOccurrence { uint32_t component,face,sourceVertex; size_t corner; int32_t chart; };
        std::map<std::pair<int64_t,int64_t>,std::vector<UVPointOccurrence>> pointOccurrences;
        pointOccurrences.clear();
        for(size_t corner=0;corner<allCorners;++corner){
            const uint32_t fi=sourceFaceForCorner[corner];
            if(fi>=(uint32_t)nf||corner>=newUV.size()||corner>=cornerChart.size()||cornerChart[corner]<0)continue;
            const double u=newUV[corner].first,v=newUV[corner].second;
            if(!std::isfinite(u)||!std::isfinite(v))continue;
            const auto key=std::make_pair((int64_t)std::llround(u*1000000.0),(int64_t)std::llround(v*1000000.0));
            pointOccurrences[key].push_back({findRoot(fi),fi,sourceVertexForCorner[corner],corner,cornerChart[corner]});
        }
        for(auto& entry:pointOccurrences){
            auto& occurrences=entry.second;
            if(occurrences.size()<2u)continue;
            std::sort(occurrences.begin(),occurrences.end(),[](const auto&a,const auto&b){
                if(a.component!=b.component)return a.component<b.component;
                if(a.face!=b.face)return a.face<b.face;
                return a.corner<b.corner;
            });
            size_t distinctComponents=0u;
            for(size_t i=0;i<occurrences.size();){
                ++distinctComponents;
                size_t j=i+1u;while(j<occurrences.size()&&occurrences[j].component==occurrences[i].component)++j;
                i=j;
            }
            if(distinctComponents<2u)continue;
            ++pointOnlyContactCoordinates;
            // Count each unordered component pair once at this coordinate.
            for(size_t i=0;i<occurrences.size();){
                size_t iEnd=i+1u;while(iEnd<occurrences.size()&&occurrences[iEnd].component==occurrences[i].component)++iEnd;
                for(size_t j=iEnd;j<occurrences.size();){
                    size_t jEnd=j+1u;while(jEnd<occurrences.size()&&occurrences[jEnd].component==occurrences[j].component)++jEnd;
                    ++pointOnlyUVContacts;
                    if(occurrences[i].chart==occurrences[j].chart)++pointOnlySameChartContacts;
                    else ++pointOnlyCrossChartContacts;
                    if(occurrences[i].sourceVertex!=occurrences[j].sourceVertex)++pointOnlyDistinctSourceVertexContacts;
                    if(pointOnlyContactTrace.size()<32u){
                        pointOnlyContactTrace.push_back({occurrences[i].face,occurrences[j].face,
                            occurrences[i].corner,occurrences[j].corner,occurrences[i].chart,occurrences[j].chart});
                    }
                    j=jEnd;
                }
                i=iEnd;
            }
        }
    }

    // Only triangles whose reconciled polygon-corner UVs still disagree with
    // xatlas orientation are rejected below. Keep a compact per-triangle trace
    // for failures so the exact source face/corners can be diagnosed without
    // asking the user to reconstruct the earlier split-face log.
    size_t collapsedFaceTriangles=0,flippedFaceTriangles=0;
    std::ostringstream reconciliationFailureTrace;
    size_t reconciliationFailureTraceCount=0;
    for(size_t i=0;i+2u<indices.size();i+=3u){
        const uint32_t ia=indices[i],ib=indices[i+1u],ic=indices[i+2u];
        if(ia>=originalCornerForInput.size()||ib>=originalCornerForInput.size()||ic>=originalCornerForInput.size())continue;
        const size_t ca=originalCornerForInput[ia],cb=originalCornerForInput[ib],cc=originalCornerForInput[ic];
        if(ca>=newUV.size()||cb>=newUV.size()||cc>=newUV.size())continue;
        if(sourceFaceForCorner[ca]==UINT32_MAX||sourceFaceForCorner[ca]!=sourceFaceForCorner[cb]||sourceFaceForCorner[ca]!=sourceFaceForCorner[cc])continue;
        if(i+2u>=xatlasTriangleUV.size())continue;
        const auto& a=xatlasTriangleUV[i];const auto& b=xatlasTriangleUV[i+1u];const auto& c=xatlasTriangleUV[i+2u];
        const double finalArea=(double(b.first)-a.first)*(double(c.second)-a.second)-(double(b.second)-a.second)*(double(c.first)-a.first);
        const uint32_t oa=result.indexArray[i],ob=result.indexArray[i+1u],oc=result.indexArray[i+2u];
        if(oa>=result.vertexCount||ob>=result.vertexCount||oc>=result.vertexCount)continue;
        const auto& xa=result.vertexArray[oa];const auto& xb=result.vertexArray[ob];const auto& xc=result.vertexArray[oc];
        const double atlasArea=(double(xb.uv[0])-xa.uv[0])*(double(xc.uv[1])-xa.uv[1])-(double(xb.uv[1])-xa.uv[1])*(double(xc.uv[0])-xa.uv[0]);
        const bool collapsed=!std::isfinite(finalArea)||std::fabs(finalArea)<1.0e-10;
        const bool flipped=!collapsed&&std::isfinite(atlasArea)&&std::fabs(atlasArea)>1.0e-10&&((atlasArea<0.0)!=(finalArea<0.0));
        if(collapsed)++collapsedFaceTriangles;
        if(flipped)++flippedFaceTriangles;
        if((collapsed||flipped)&&reconciliationFailureTraceCount<32u){
            if(reconciliationFailureTraceCount++)reconciliationFailureTrace<<"; ";
            reconciliationFailureTrace<<"face="<<sourceFaceForCorner[ca]<<" tri="<<(i/3u)
                <<" corners="<<ca<<','<<cb<<','<<cc
                <<" charts="<<cornerChart[ca]<<','<<cornerChart[cb]<<','<<cornerChart[cc]
                <<" final_uv="<<a.first<<','<<a.second<<'|'<<b.first<<','<<b.second<<'|'<<c.first<<','<<c.second
                <<" atlas_uv="<<xa.uv[0]/(float)atlas->width<<','<<xa.uv[1]/(float)atlas->height
                <<'|'<<xb.uv[0]/(float)atlas->width<<','<<xb.uv[1]/(float)atlas->height
                <<'|'<<xc.uv[0]/(float)atlas->width<<','<<xc.uv[1]/(float)atlas->height
                <<" signed_area="<<finalArea<<" atlas_area="<<atlasArea
                <<" reason="<<(collapsed?"collapsed":"flipped");
        }
    }
    const uint32_t outputCharts=result.chartCount;
    const uint32_t atlasWidth=atlas->width,atlasHeight=atlas->height;
    const float finalAtlasTexelsPerUnit=atlas->texelsPerUnit;
    const uint32_t xatlasOutputMeshCount=atlas->meshCount,xatlasOutputChartCount=atlas->chartCount;
    const uint32_t xatlasOutputAtlasCount=atlas->atlasCount;
    const uint32_t xatlasOutputVertexCount=result.vertexCount,xatlasOutputIndexCount=result.indexCount;
    // The xatlas Mesh arrays are owned by Atlas and become invalid in
    // xatlas::Destroy(). Keep the source-vertex identity stream needed by the
    // later mesh commit before releasing the atlas; result is a reference into it.
    std::vector<uint32_t> xatlasOutputSourceIndices;
    if(result.indexArray&&result.indexCount)
        xatlasOutputSourceIndices.assign(result.indexArray,result.indexArray+result.indexCount);
    double atlasUtilizationFinal=0.0,atlasUtilizationWithOuterMargin=0.0;
    if(atlas->utilization&&atlas->atlasCount>0u){
        for(uint32_t i=0;i<atlas->atlasCount;++i){
            atlasUtilizationFinal+=atlas->utilization[i];
            atlasUtilizationWithOuterMargin+=kuro::uvpacking::utilizationAfterOuterMargin(atlas->utilization[i]);
        }
        atlasUtilizationFinal/=double(atlas->atlasCount);
        atlasUtilizationWithOuterMargin/=double(atlas->atlasCount);
    }
    xatlas::Destroy(atlas);

    // Validate the actual UV edge graph before committing. A chart boundary
    // must be a discontinuity across the complete shared edge, while two faces
    // in the same chart must agree at both edge endpoints. This catches the
    // subtle failure where two islands become accidentally welded by matching
    // coordinates, as well as partial endpoint matches that create T-junction-
    // like UV connectivity. Use the full CSR fan, not the legacy two-face pair.
    size_t collapsedChartSeams=0;
    size_t brokenIntraChartEdges=0;
    if(m.edgeFaceOffsets.size()==m.uniqueEdges.size()+1u &&
       m.edgeFaceOffsets.back()<=m.edgeFaces.size()){
        std::vector<uint32_t> faceCornerBase((size_t)nf+1u,0u);
        for(int fi=0;fi<nf;++fi)
            faceCornerBase[(size_t)fi+1u]=faceCornerBase[(size_t)fi]+(uint32_t)m.faces[(size_t)fi].size();
        auto findCorner=[&](int fi,uint32_t vertex)->size_t{
            if(fi<0||fi>=nf)return SIZE_MAX;
            const auto& face=m.faces[(size_t)fi];
            for(size_t k=0;k<face.size();++k)
                if(face[k]==vertex)return (size_t)faceCornerBase[(size_t)fi]+k;
            return SIZE_MAX;
        };
        auto uvEqual=[&](size_t a,size_t b){
            return a<newUV.size()&&b<newUV.size()&&
                std::fabs(newUV[a].first-newUV[b].first)<=1.0e-6f&&
                std::fabs(newUV[a].second-newUV[b].second)<=1.0e-6f;
        };
        for(size_t ei=0;ei<m.uniqueEdges.size();++ei){
            const auto edge=m.uniqueEdges[ei];
            const uint32_t begin=m.edgeFaceOffsets[ei],end=m.edgeFaceOffsets[ei+1u];
            if(end>m.edgeFaces.size()||end-begin<2u)continue;
            for(uint32_t ai=begin;ai<end;++ai){
                const int fa=m.edgeFaces[ai];
                const size_t a0=findCorner(fa,edge.first),a1=findCorner(fa,edge.second);
                if(a0==SIZE_MAX||a1==SIZE_MAX)continue;
                for(uint32_t bi=ai+1u;bi<end;++bi){
                    const int fb=m.edgeFaces[bi];
                    // A polygon split across xatlas charts can have two different UV
                    // values for the same original corner (one per triangle side).
                    // faceCornerUV is only a compatibility projection and cannot encode
                    // that internal seam. Do not use this lossy corner view to reject
                    // the atlas at a shared edge touching such a polygon: the exact
                    // triangle-corner UV stream is authoritative and retains the
                    // independent xatlas vertex identity for both sides.
                    if(fb<0||fb>=nf||(faceChartKinds[(size_t)fa]>1u||faceChartKinds[(size_t)fb]>1u))continue;
                    const size_t b0=findCorner(fb,edge.first),b1=findCorner(fb,edge.second);
                    if(b0==SIZE_MAX||b1==SIZE_MAX)continue;
                    // Missing xatlas chart assignments have default (0,0) UVs;
                    // they are not evidence of two islands being accidentally welded.
                    if(cornerChart[a0]<0||cornerChart[a1]<0||cornerChart[b0]<0||cornerChart[b1]<0)continue;
                    const bool sameChart=cornerChart[a0]==cornerChart[a1]&&
                        cornerChart[a0]==cornerChart[b0]&&cornerChart[a0]==cornerChart[b1];
                    const bool bothEndpointsMatch=uvEqual(a0,b0)&&uvEqual(a1,b1);
                    if(sameChart&&!bothEndpointsMatch)++brokenIntraChartEdges;
                    else if(!sameChart&&bothEndpointsMatch)++collapsedChartSeams;
                }
            }
        }
    }

    // Never commit a partially-written atlas. Chart splits are reconciled above
    // when the original polygon-corner representation remains valid; missing
    // corners or collapsed/flipped triangles still reject the operation instead
    // of silently leaving stale UVs or collapsing geometry onto the atlas origin.
    // Point-only contacts are retained as diagnostics, not a global failure gate:
    // disconnected source face fans may legitimately share a source vertex, and
    // the raw pair count alone does not prove that the packed UV result is invalid.
    size_t invalidPackedUV=0;
    for(size_t corner=0;corner<allCorners;++corner){
        if(sourceFaceForCorner[corner]==UINT32_MAX)continue;
        const float u=newUV[corner].first,v=newUV[corner].second;
        if(!std::isfinite(u)||!std::isfinite(v)||u<0.0f||u>1.0f||v<0.0f||v>1.0f)
            ++invalidPackedUV;
    }
    if(!xatlasTriangleUVValid||xatlasTriangleUV.size()!=indices.size())++invalidPackedUV;
    for(const auto& uv:xatlasTriangleUV)
        if(!std::isfinite(uv.first)||!std::isfinite(uv.second)||uv.first<0.0f||uv.first>1.0f||uv.second<0.0f||uv.second>1.0f)++invalidPackedUV;
    // Point-only UV contacts are reported with same-chart / cross-chart
    // breakdown so a genuine bad corner assignment can be isolated. Do not
    // cancel the entire unwrap from this aggregate metric alone; it also counts
    // valid vertex-only source topology and can be large on imported meshes.
    if(missingCornerUV||invalidPackedUV||collapsedFaceTriangles||flippedFaceTriangles||collapsedChartSeams||brokenIntraChartEdges){
        std::ostringstream msg;
        msg<<"Auto UV: cancelled; missing corners="<<missingCornerUV
           <<", invalid packed coordinates="<<invalidPackedUV
           <<", degenerate reconciled triangles="<<collapsedFaceTriangles
           <<", flipped reconciled triangles="<<flippedFaceTriangles
           <<", polygons crossing xatlas charts="<<faceChartSplits
           <<", reconciled multi-chart corners="<<unresolvedCornerConflicts
           <<", chart seams accidentally linked="<<collapsedChartSeams
           <<", broken edges inside charts="<<brokenIntraChartEdges
           <<", point-only UV island contacts="<<pointOnlyUVContacts
           <<" (same-chart="<<pointOnlySameChartContacts<<", cross-chart="<<pointOnlyCrossChartContacts<<")"
           <<", chart_flip_repairs="<<repairedFaceChartFlips
           <<", chart_assignment_trials="<<chartAssignmentTrials
           <<", split_face_internal_seam_unrepresentable="<<splitFaceInternalSeamUnrepresentable
           <<", reconciliation_failures={"<<reconciliationFailureTrace.str()<<"}"
           <<", xatlas_output={meshes:"<<xatlasOutputMeshCount<<",charts:"<<xatlasOutputChartCount
           <<",atlases:"<<xatlasOutputAtlasCount<<",size:"<<atlasWidth<<"x"<<atlasHeight<<",fixed_1024_padding:"<<(atlasFixedResolutionPacked?"yes":"no")
           <<",vertices:"<<xatlasOutputVertexCount<<",indices:"<<xatlasOutputIndexCount
           <<",valid_chart_vertices:"<<xatlasValidOutputVertices<<",invalid_chart_vertices:"<<xatlasInvalidChartVertices
           <<",non_finite_uv:"<<xatlasNonFiniteOutputUV<<"}; "<<xatlasInputDiagnostic;
        setStatus(msg.str());
        logWarning("UV",msg.str());
        return;
    }

    // xatlas may preserve the same polygon triangulation but enumerate its
    // triangles/corners in a different order. Match by source face + unordered
    // source vertex triple, then restore each corner by source vertex identity.
    // This is safe for reordering/winding changes; a different diagonal remains
    // unmatched and is rejected rather than guessed.
    bool triangleTopologyMatches=xatlasTriangleUVValid &&
        xatlasTriangleUV.size()==indices.size() &&
        indices.size()==m.indices.size() &&
        sourceFaceForTriangle.size()==m.triangleFaces.size() &&
        xatlasOutputSourceIndices.size()==indices.size();
    std::string triangleTopologyMismatchReason;
    if(!triangleTopologyMatches)triangleTopologyMismatchReason="triangle stream sizes or xatlas UV validity differ";
    std::vector<std::pair<float,float>> meshOrderedTriangleUV;
    std::vector<uint32_t> meshOrderedSourceIndices;
    if(triangleTopologyMatches){
        using TriangleKey=std::tuple<int,uint32_t,uint32_t,uint32_t>;
        std::map<TriangleKey,size_t> currentTriangles;
        currentTriangles.clear();
        for(size_t ti=0;ti<m.triangleFaces.size();++ti){
            const size_t at=ti*3u;
            uint32_t a=m.indices[at],b=m.indices[at+1u],c=m.indices[at+2u];
            if(a>=m.vertices.size()||b>=m.vertices.size()||c>=m.vertices.size()||a==b||b==c||c==a){triangleTopologyMatches=false;triangleTopologyMismatchReason="current mesh contains an invalid or degenerate triangle";break;}
            if(b<a)std::swap(a,b);if(c<b)std::swap(b,c);if(b<a)std::swap(a,b);
            const TriangleKey key{m.triangleFaces[ti],a,b,c};
            if(!currentTriangles.emplace(key,ti).second){triangleTopologyMatches=false;triangleTopologyMismatchReason="duplicate source triangle key in current mesh";break;}
        }
        if(triangleTopologyMatches){
            meshOrderedTriangleUV.assign(m.indices.size(),{0.0f,0.0f});
            meshOrderedSourceIndices.assign(m.indices.size(),0u);
            std::vector<uint8_t> assigned(m.triangleFaces.size(),0u);
            for(size_t ti=0;ti<sourceFaceForTriangle.size()&&triangleTopologyMatches;++ti){
                const size_t inAt=ti*3u;
                uint32_t src[3];
                for(size_t k=0;k<3u;++k){const uint32_t input=indices[inAt+k];if(input>=inputMeshVertex.size()){triangleTopologyMatches=false;triangleTopologyMismatchReason="xatlas input corner references an invalid source vertex";break;}src[k]=inputMeshVertex[input];}
                if(!triangleTopologyMatches)break;
                if(src[0]==src[1]||src[1]==src[2]||src[2]==src[0]){triangleTopologyMatches=false;triangleTopologyMismatchReason="xatlas input contains a degenerate source triangle";break;}
                uint32_t a=src[0],b=src[1],c=src[2];
                if(b<a)std::swap(a,b);if(c<b)std::swap(b,c);if(b<a)std::swap(a,b);
                const auto found=currentTriangles.find(TriangleKey{(int)sourceFaceForTriangle[ti],a,b,c});
                if(found==currentTriangles.end()){triangleTopologyMatches=false;std::ostringstream why;why<<"no current mesh triangle for source face "<<sourceFaceForTriangle[ti]<<" vertices "<<src[0]<<","<<src[1]<<","<<src[2]<<" (triangulation differs)";triangleTopologyMismatchReason=why.str();break;}
                if(assigned[found->second]){triangleTopologyMatches=false;triangleTopologyMismatchReason="multiple xatlas triangles map to one current mesh triangle";break;}
                const size_t meshAt=found->second*3u;assigned[found->second]=1u;
                for(size_t k=0;k<3u;++k){
                    size_t dst=3u;
                    for(size_t q=0;q<3u;++q)if(m.indices[meshAt+q]==src[k]){dst=q;break;}
                    if(dst==3u){triangleTopologyMatches=false;triangleTopologyMismatchReason="matched triangle does not share the same source corner identity";break;}
                    meshOrderedTriangleUV[meshAt+dst]=xatlasTriangleUV[inAt+k];
                    meshOrderedSourceIndices[meshAt+dst]=xatlasOutputSourceIndices[inAt+k];
                }
            }
            if(triangleTopologyMatches)for(uint8_t used:assigned)if(!used){triangleTopologyMatches=false;triangleTopologyMismatchReason="current mesh contains a triangle not present in xatlas input";break;}
        }
    }
    if(!triangleTopologyMatches && faceChartSplits>0u){
        setStatus("Auto UV: cancelled; xatlas triangles do not match mesh triangulation: "+triangleTopologyMismatchReason);
        logWarning("UV","Auto UV cancelled: independent triangle UV mapping could not be matched safely: "+triangleTopologyMismatchReason);
        return;
    }
    kuroSetCrashContext("Auto UV: commit UV streams to mesh");kuroWriteUVTraceAt("phase: commit UV streams begin");
    if(!multiObjectUnwrapPass&&!selectedFaceUnwrapPass){
        kuroWriteUVTraceAt("commit: undo snapshot begin");
        pushUndoState();
        kuroWriteUVTraceAt("commit: undo snapshot complete");
    }
    kuroWriteUVTraceAt("commit: assign polygon UV begin");
    m.faceCornerUV=std::move(newUV);
    kuroWriteUVTraceAt("commit: rebuild triangulation begin");
    m.rebuildTriangulation();
    kuroWriteUVTraceAt("commit: rebuild triangulation complete");
    if(triangleTopologyMatches){
        kuroWriteUVTraceAt("commit: assign independent triangle UV begin");
        m.triangleCornerUV=std::move(meshOrderedTriangleUV);
        // Preserve xatlas vertex identity, not just its UV coordinates. Two
        // disconnected chart vertices may occupy the exact same UV position.
        // Use the owned copy: result.indexArray belongs to the destroyed atlas.
        if(meshOrderedSourceIndices.size()!=xatlasOutputIndexCount){
            logError("UV","Auto UV commit aborted: saved xatlas source-index stream has an unexpected size");
            return;
        }
        m.triangleCornerUVSourceVertexIndices=std::move(meshOrderedSourceIndices);
        m.triangleCornerUVIndependent=true;
        kuroWriteUVTraceAt("commit: independent triangle UV assigned");
        // Rebuild the corner-to-UV-vertex map before any editor selection or
        // transform can consume it. updateUVsOnly intentionally does not rebuild
        // this pool for independent streams, because doing so during a drag
        // would renumber selected UV vertices.
        kuroWriteUVTraceAt("commit: rebuild independent UV vertex pool begin");
        m.rebuildUVVertexPool();
        if(m.triangleCornerUVVertexIndices.size()!=m.triangleCornerUV.size() || m.uvVertices.empty()){
            logError("UV","Auto UV commit aborted: independent UV vertex pool could not be rebuilt");
            return;
        }
        kuroWriteUVTraceAt("commit: rebuild independent UV vertex pool complete");
        // Refresh tangent frames; the independent triangle stream remains authoritative.
        kuroWriteUVTraceAt("commit: update UV data begin");
        m.updateUVsOnly(true,nullptr,true,false,true);
        kuroWriteUVTraceAt("commit: update UV data complete");
    }
    ++uvPickRevision;
    size_t uvOutside=0,uvNonFinite=0;
    for(auto const&q:m.faceCornerUV){
        if(!std::isfinite(q.first)||!std::isfinite(q.second))++uvNonFinite;
        if(q.first<0.0f||q.first>1.0f||q.second<0.0f||q.second>1.0f)++uvOutside;
    }
    std::ostringstream uvlog;
    uvlog<<"xatlas unwrap: faces="<<nf
         <<" input_triangles="<<(indices.size()/3)
         <<" triangulation_source=mesh"
         <<" mesh_triangle_mapping_failures="<<meshTriangleMappingFailures
         <<" skipped_faces="<<ignoredFaces
         <<" charts="<<outputCharts
         <<" profile="<<(organicChartProfile?"organic-lscm":"general-lscm")
         <<" cut_graph_components="<<cutGraphComponents<<" cut_graph_skipped="<<cutGraphSkipped<<" cut_graph_genus="<<cutGraphGenusSum<<" cut_graph_edges="<<cutGraphEdgeCount<<" cut_graph_length="<<cutGraphLength<<" cut_graph_objective="<<cutGraphObjective<<" cut_graph_sharp_edges="<<cutGraphSharpEdgeCount<<" cut_graph_local_swaps="<<cutGraphSwapCount<<" seam_graph_candidates="<<distortionGuidedExchanges.size()<<" seam_graph_pair_budget_left="<<topologyExchangePairBudget<<" seam_graph_trials="<<seamGraphTrialCount<<" seam_graph_selected_trial="<<selectedSeamGraphTrial<<" local_global_arap_iterations="<<localGlobalIterations<<" slim_relax_iterations="<<slimRelaxIterations<<" slim_relax_sd_before="<<slimRelaxBefore<<" slim_relax_sd_after="<<slimRelaxAfter
         <<" chart_max_cost="<<chartOptions.maxCost
         <<" distortion_trials="<<distortionTrialCount
         <<" distortion_charts="<<selectedChartCount
         <<" distortion_objective="<<selectedObjective
         <<" distortion_sd="<<selectedDistortion.symmetricDirichlet
         <<" distortion_p95_stretch="<<selectedDistortion.p95Stretch
         <<" distortion_mean_log_area="<<selectedDistortion.meanLogArea
         <<" distortion_triangles="<<selectedDistortion.validTriangles
         <<" mean_normal_dot="<<meanNormalDot
         <<" crease_ratio="<<creaseRatio
         <<" auto_crease_candidates="<<autoCreaseCandidates
         <<" auto_crease_kept="<<autoCreaseAccepted
         <<" auto_crease_filtered="<<autoCreaseFiltered
         <<" seams="<<m.uvSeams.size()
         <<" atlas="<<atlasWidth<<"x"<<atlasHeight
         <<" atlas_fixed_resolution_packed="<<(atlasFixedResolutionPacked?1:0)
         <<" atlas_texels_per_unit="<<finalAtlasTexelsPerUnit
         <<" atlas_utilization_before_refine="<<atlasUtilizationBeforeRefine
         <<" atlas_utilization_final="<<atlasUtilizationFinal
         <<" atlas_utilization_with_outer_margin="<<atlasUtilizationWithOuterMargin
         <<" atlas_pack_refined="<<(atlasPackRefined?1:0)
         <<" atlas_quality_placement_requested="<<(atlasNeedsQualityPlacement?1:0)
         <<" corners="<<m.faceCornerUV.size()
         <<" uv_write_conflicts="<<unresolvedCornerConflicts
         <<" missing_corner_uv="<<missingCornerUV
         <<" uv_raw_conflicts="<<rawUVWriteConflicts
         <<" face_chart_splits="<<faceChartSplits
         <<" chart_flip_repairs="<<repairedFaceChartFlips
         <<" chart_assignment_trials="<<chartAssignmentTrials
         <<" split_face_internal_seam_unrepresentable="<<splitFaceInternalSeamUnrepresentable
         <<" vertex_chart_pool_borrowed="<<vertexChartPoolBorrowed
         <<" vertex_chart_pool_ambiguous="<<vertexChartPoolAmbiguous
         <<" split_face_boundary_seam_faces="<<splitFaceBoundarySeamFaces
         <<" split_face_boundary_seam_edges="<<splitFaceBoundarySeamEdges
         <<" split_face_boundary_seam_recovery="<<(splitFaceBoundarySeamRecoveryAccepted?1:0)
         <<" split_face_boundary_candidate_splits="<<splitFaceBoundaryCandidateSplits
         <<" split_face_boundary_max_cost="<<splitFaceBoundarySelectedMaxCost
         <<" split_face_boundary_reject_reason="<<splitFaceBoundaryRejectReason
         <<" split_face_boundary_dirichlet="<<splitFaceBoundaryBaselineDirichlet<<"->"<<splitFaceBoundaryCandidateDirichlet
         <<" split_face_boundary_p95="<<splitFaceBoundaryBaselineP95<<"->"<<splitFaceBoundaryCandidateP95
         <<" single_face_charts="<<selectedFragmentation.singleFaceCharts
         <<" point_only_uv_contacts="<<pointOnlyUVContacts
         <<" point_only_same_chart="<<pointOnlySameChartContacts
         <<" point_only_cross_chart="<<pointOnlyCrossChartContacts
         <<" point_only_contact_coordinates="<<pointOnlyContactCoordinates
         <<" point_only_distinct_source_vertex="<<pointOnlyDistinctSourceVertexContacts
         <<" reconciled_multi_chart_corners="<<unresolvedCornerConflicts
         <<" point_only_contact_trace="<<pointOnlyContactTrace.size();
    for(const auto& contact:pointOnlyContactTrace){
        uvlog<<" [f"<<contact.faceA<<"/c"<<contact.cornerA<<"/chart"<<contact.chartA
             <<"-f"<<contact.faceB<<"/c"<<contact.cornerB<<"/chart"<<contact.chartB<<"]";
    }
    uvlog
         <<" collapsed_face_triangles="<<collapsedFaceTriangles
         <<" flipped_face_triangles="<<flippedFaceTriangles
         <<" collapsed_chart_seams="<<collapsedChartSeams
         <<" broken_intra_chart_edges="<<brokenIntraChartEdges
         <<" invalid_xref="<<invalidXrefCount
         <<" xref_slot_mismatches="<<xrefSlotMismatches
         <<" outside_0_1="<<uvOutside
         <<" non_finite="<<uvNonFinite;
    const bool highUVStretch=std::isfinite(selectedDistortion.symmetricDirichlet)&&
        (selectedDistortion.symmetricDirichlet>2.5||selectedDistortion.p95Stretch>4.0);
    if(uvOutside||uvNonFinite||ignoredFaces||highUVStretch)logWarning("UV",uvlog.str());
    else logInfo("UV",uvlog.str());
    if(highUVStretch)setStatus("Auto UV: ready; high stretch detected (see UV log)");
    else setStatus(seamsOnly?"UV Unwrap: ready for Paint":"Auto UV: ready for Paint");
    kuroWriteUVTraceAt("unwrap completed successfully");
}

