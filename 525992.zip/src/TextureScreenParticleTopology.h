#pragma once

// Adjacency-constrained screen-space traversal for projected mesh triangles.
// Projection data is prepared once per visible mesh update; particle ticks do
// only local barycentric tests and never raycast or query the scene BVH.

#include "TextureScreenParticleProjection.h"
#include "TextureScreenParticleVisibility.h"
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <vector>

namespace kuro::texture::screen_particles {

struct ScreenTriangle {
    TriangleProjection projection{};
    // Same convention as surface_particles::Triangle: edge opposite bary[k].
    std::array<std::int32_t,3> neighbor{{-1,-1,-1}};
};

struct LocatedPoint {
    std::uint32_t triangle=std::numeric_limits<std::uint32_t>::max();
    float textureX=0.0f, textureY=0.0f;
};

class TriangleWalker {
public:
    // Follows the edge actually crossed by the screen-space point. This is a
    // bounded walk, not a broad graph search: overlapping triangles elsewhere
    // in screen space cannot steal a particle from its connected surface path.
    static bool locate(const std::vector<ScreenTriangle>& triangles,
                       std::uint32_t currentTriangle,
                       float screenX,float screenY,
                       LocatedPoint& result,
                       std::uint32_t maxHops=12u,
                       const DepthBufferView* visibility=nullptr) noexcept {
        if(currentTriangle>=triangles.size() || maxHops==0u ||
           !std::isfinite(screenX) || !std::isfinite(screenY)) return false;
        std::uint32_t triangleIndex=currentTriangle;
        for(std::uint32_t hop=0u;hop<maxHops;++hop) {
            if(triangleIndex>=triangles.size()) return false;
            const ScreenTriangle& tri=triangles[triangleIndex];
            if(!tri.projection.valid) return false;
            const auto& a=tri.projection.corners[0];
            const auto& b=tri.projection.corners[1];
            const auto& c=tri.projection.corners[2];
            const float den=tri.projection.screenArea2;
            if(!std::isfinite(den) || std::fabs(den)<1.0e-3f) return false;
            const float wb=((screenX-a.screenX)*(c.screenY-a.screenY)-
                            (c.screenX-a.screenX)*(screenY-a.screenY))/den;
            const float wc=((b.screenX-a.screenX)*(screenY-a.screenY)-
                            (screenX-a.screenX)*(b.screenY-a.screenY))/den;
            const std::array<float,3> bary{{1.0f-wb-wc,wb,wc}};
            if(!std::isfinite(bary[0]) || !std::isfinite(bary[1]) || !std::isfinite(bary[2])) return false;
            int crossedEdge=-1;
            float mostNegative=-1.0e-4f;
            for(int k=0;k<3;++k) if(bary[std::size_t(k)]<mostNegative) {
                mostNegative=bary[std::size_t(k)];
                crossedEdge=k;
            }
            if(crossedEdge<0) {
                float u=0.0f,v=0.0f;
                if(!tri.projection.mapInside(screenX,screenY,u,v)) return false;
                if(visibility) {
                    const float depth=bary[0]*a.depth+bary[1]*b.depth+bary[2]*c.depth;
                    if(!visibility->visible(screenX,screenY,depth)) return false;
                }
                result.triangle=triangleIndex;
                result.textureX=u;
                result.textureY=v;
                return true;
            }
            const std::int32_t next=tri.neighbor[std::size_t(crossedEdge)];
            if(next<0 || static_cast<std::size_t>(next)>=triangles.size() ||
               static_cast<std::uint32_t>(next)==triangleIndex) return false;
            triangleIndex=static_cast<std::uint32_t>(next);
        }
        return false;
    }
};

} // namespace kuro::texture::screen_particles
