#pragma once
#include "Mesh.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace kuro::uvmask {
struct Cache {
    int objectId=-1,width=0,height=0,padding=-1;
    uint64_t uvRevision=~uint64_t(0),topologyRevision=~uint64_t(0);
    std::vector<uint8_t> pixels;
    bool valid=false;
};
inline Cache& cache(){ static Cache value; return value; }
// Padding is authored in 1K-texture pixels and scales with the shorter image
// dimension. A positive setting always keeps at least one texel, including
// 32x32 and 64x64 maps; zero explicitly disables the margin.
inline int effectivePadding(int width,int height,int requestedPadding){
    if(width<=0||height<=0||requestedPadding<=0)return 0;
    const int minDim=std::min(width,height);
    const int scaled=(requestedPadding*minDim+512)/1024;
    return std::max(1,scaled);
}
inline const std::vector<uint8_t>& get(const Mesh& mesh,int objectId,int width,int height,int padding,bool* validOut=nullptr){
    Cache& c=cache();
    width=std::clamp(width,1,8192);height=std::clamp(height,1,8192);padding=effectivePadding(width,height,padding);
    if(c.objectId==objectId&&c.width==width&&c.height==height&&c.padding==padding&&c.uvRevision==mesh.uvRevision&&c.topologyRevision==mesh.topologyRevision){if(validOut){*validOut=c.valid;}
    return c.pixels;}
    c.objectId=objectId;c.width=width;c.height=height;c.padding=padding;c.uvRevision=mesh.uvRevision;c.topologyRevision=mesh.topologyRevision;c.valid=false;
    const size_t count=size_t(width)*size_t(height);c.pixels.assign(count,0);
    const auto& uv=mesh.triangleCornerUV;
    if(uv.size()<3||uv.size()%3!=0){if(validOut){*validOut=false;}
        return c.pixels;}
    auto edge=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
    bool hasCoverage=false;
    for(size_t t=0;t+2<uv.size();t+=3){
        const auto a=uv[t],b=uv[t+1],d=uv[t+2];
        const float ax=a.first*float(width),ay=(1.0f-a.second)*float(height);
        const float bx=b.first*float(width),by=(1.0f-b.second)*float(height);
        const float dx=d.first*float(width),dy=(1.0f-d.second)*float(height);
        if(!std::isfinite(ax)||!std::isfinite(ay)||!std::isfinite(bx)||!std::isfinite(by)||!std::isfinite(dx)||!std::isfinite(dy))continue;
        const float area=edge(ax,ay,bx,by,dx,dy);if(std::fabs(area)<1.0e-12f)continue;
        const int x0=std::clamp((int)std::floor(std::min({ax,bx,dx})-1.0f),0,width-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,dx})+1.0f),0,width-1);
        const int y0=std::clamp((int)std::floor(std::min({ay,by,dy})-1.0f),0,height-1),y1=std::clamp((int)std::ceil(std::max({ay,by,dy})+1.0f),0,height-1);
        bool triangleHasCoverage=false;
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){const float px=float(x)+0.5f,py=float(y)+0.5f;const float e0=edge(ax,ay,bx,by,px,py),e1=edge(bx,by,dx,dy,px,py),e2=edge(dx,dy,ax,ay,px,py);if((area>0.0f&&e0>=-1e-4f&&e1>=-1e-4f&&e2>=-1e-4f)||(area<0.0f&&e0<=1e-4f&&e1<=1e-4f&&e2<=1e-4f)){c.pixels[size_t(y)*size_t(width)+size_t(x)]=255;hasCoverage=true;triangleHasCoverage=true;}}
        // Sub-texel triangles can otherwise disappear completely at low
        // resolutions. Give each valid triangle one deterministic nearest seed.
        if(!triangleHasCoverage){
            const float cx=(ax+bx+dx)/3.0f,cy=(ay+by+dy)/3.0f;
            if(cx>=0.0f&&cx<float(width)&&cy>=0.0f&&cy<float(height)){
                const int sx=std::clamp((int)std::floor(cx),0,width-1),sy=std::clamp((int)std::floor(cy),0,height-1);
                c.pixels[size_t(sy)*size_t(width)+size_t(sx)]=255;hasCoverage=true;
            }
        }
    }
    // Track coverage while rasterizing instead of scanning the full 4K mask again.
    c.valid=hasCoverage;
    // Separable square dilation. O(width*height), even at 4K and maximum padding.
    if(c.valid&&padding>0){
        std::vector<uint8_t> temp(count,0);
        for(int y=0;y<height;++y){const size_t row=size_t(y)*size_t(width);int last=-100000;for(int x=0;x<width;++x){if(c.pixels[row+size_t(x)])last=x;if(x-last<=padding)temp[row+size_t(x)]=255;}last=100000;for(int x=width-1;x>=0;--x){if(c.pixels[row+size_t(x)])last=x;if(last-x<=padding)temp[row+size_t(x)]=255;}}
        std::fill(c.pixels.begin(),c.pixels.end(),0);
        for(int x=0;x<width;++x){int last=-100000;for(int y=0;y<height;++y){if(temp[size_t(y)*size_t(width)+size_t(x)])last=y;if(y-last<=padding)c.pixels[size_t(y)*size_t(width)+size_t(x)]=255;}last=100000;for(int y=height-1;y>=0;--y){if(temp[size_t(y)*size_t(width)+size_t(x)])last=y;if(last-y<=padding)c.pixels[size_t(y)*size_t(width)+size_t(x)]=255;}}
    }
    if(validOut){*validOut=c.valid;}
    return c.pixels;
}
// Apply a binary UV coverage mask to RGBA pixels. Empty atlas areas become
// transparent; a small, non-editable color-bleed guard band copies nearby island
// RGB and uses opaque alpha to prevent linear filtering/mipmaps from creating
// transparent fringes. The guard band uses the same square/Chebyshev distance
// as the editable UV mask and scales down for small textures.
inline bool clearAlphaOutsideMask(std::vector<uint8_t>& rgba,int width,int height,const std::vector<uint8_t>& strict,int requestedPadding=8){
    if(width<=0||height<=0||rgba.size()!=size_t(width)*size_t(height)*4u||strict.size()!=size_t(width)*size_t(height))return false;
    const size_t count=size_t(width)*size_t(height);
    if(std::find(strict.begin(),strict.end(),uint8_t(255))==strict.end())return false;
    const int padding=effectivePadding(width,height,requestedPadding);
    if(padding>0){
        std::vector<uint8_t> expanded=strict;
        std::vector<uint32_t> frontier,nextFrontier;
        // Start only at the island boundary, avoiding a full-image queue on dense UVs.
        for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t i=size_t(y)*size_t(width)+size_t(x);if(!strict[i])continue;if((x>0&&!strict[i-1])||(x+1<width&&!strict[i+1])||(y>0&&!strict[i-size_t(width)])||(y+1<height&&!strict[i+size_t(width)]))frontier.push_back((uint32_t)i);}
        for(int step=0;step<padding&&!frontier.empty();++step){nextFrontier.clear();for(uint32_t sourceIndex:frontier){const size_t srcIndex=sourceIndex;const int x=(int)(srcIndex%size_t(width)),y=(int)(srcIndex/size_t(width));for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){if(ox==0&&oy==0)continue;const int nx=x+ox,ny=y+oy;if(nx<0||ny<0||nx>=width||ny>=height)continue;const size_t dstIndex=size_t(ny)*size_t(width)+size_t(nx);if(expanded[dstIndex])continue;uint8_t* dst=rgba.data()+dstIndex*4u;const uint8_t* src=rgba.data()+srcIndex*4u;dst[0]=src[0];dst[1]=src[1];dst[2]=src[2];dst[3]=255;expanded[dstIndex]=255;nextFrontier.push_back((uint32_t)dstIndex);}}frontier.swap(nextFrontier);}
        for(size_t i=0;i<count;++i)if(!expanded[i])rgba[i*4u+3u]=0;
    }else for(size_t i=0;i<count;++i)if(strict[i]==0)rgba[i*4u+3u]=0;
    return true;
}
inline bool clearAlphaOutsideIslandAware(std::vector<uint8_t>& rgba,int width,int height,
                                         const std::vector<const Mesh*>& meshes,int requestedPadding);
// Apply per-island dilation wherever a single mesh supplies the UV topology.
// If topology is unavailable, preserve the legacy binary-mask fallback.
inline bool clearAlphaOutside(const Mesh& mesh,int objectId,std::vector<uint8_t>& rgba,int width,int height,int requestedPadding=8){
    if(width<=0||height<=0||rgba.size()!=size_t(width)*size_t(height)*4u)return false;
    bool valid=false;const auto& strict=get(mesh,objectId,width,height,0,&valid);
    if(!valid||strict.size()!=size_t(width)*size_t(height))return false;
    const std::vector<const Mesh*> meshes{&mesh};
    if(clearAlphaOutsideIslandAware(rgba,width,height,meshes,requestedPadding))return true;
    return clearAlphaOutsideMask(rgba,width,height,strict,requestedPadding);
}

// Island-aware export bleed. Triangles belong to the same UV island only when
// they share a geometric edge and both endpoint UVs agree. Padding propagates
// from each island independently and never overwrites another island's covered
// texels, preventing the common-atlas union mask from mixing island colors.
inline bool clearAlphaOutsideIslandAware(std::vector<uint8_t>& rgba,int width,int height,
                                         const std::vector<const Mesh*>& meshes,int requestedPadding=8){
    if(width<=0||height<=0||rgba.size()!=size_t(width)*size_t(height)*4u||meshes.empty())return false;
    struct Tri { const Mesh* mesh=nullptr; size_t index=0; uint32_t parent=0; uint8_t rank=0; };
    struct EdgeRef { uint32_t tri=0; uint32_t va=0,vb=0; std::pair<float,float> ua{},ub{}; };
    std::vector<Tri> tris;
    std::vector<std::unordered_map<uint64_t,std::vector<EdgeRef>>> edgeMaps(meshes.size());
    auto findRoot=[&](uint32_t x){uint32_t r=x;while(tris[r].parent!=r)r=tris[r].parent;while(tris[x].parent!=x){uint32_t n=tris[x].parent;tris[x].parent=r;x=n;}return r;};
    auto unite=[&](uint32_t a,uint32_t b){a=findRoot(a);b=findRoot(b);if(a==b)return;if(tris[a].rank<tris[b].rank)std::swap(a,b);tris[b].parent=a;if(tris[a].rank==tris[b].rank)++tris[a].rank;};
    auto uvNear=[](const std::pair<float,float>&a,const std::pair<float,float>&b){return std::isfinite(a.first)&&std::isfinite(a.second)&&std::isfinite(b.first)&&std::isfinite(b.second)&&std::fabs(a.first-b.first)<=1.0e-5f&&std::fabs(a.second-b.second)<=1.0e-5f;};
    for(size_t mi=0;mi<meshes.size();++mi){const Mesh* m=meshes[mi];if(!m)continue;const size_t tc=std::min(m->indices.size()/3u,m->triangleCornerUV.size()/3u);auto& em=edgeMaps[mi];
        for(size_t t=0;t<tc;++t){const uint32_t id=(uint32_t)tris.size();tris.push_back({m,t,id,0});for(int e=0;e<3;++e){const int n=(e+1)%3;const uint32_t va=m->indices[t*3u+(size_t)e],vb=m->indices[t*3u+(size_t)n];if(va>=m->vertices.size()||vb>=m->vertices.size()||va==vb)continue;const bool forward=va<vb;const uint32_t a=std::min(va,vb),b=std::max(va,vb);const auto ua=m->triangleCornerUV[t*3u+(size_t)(forward?e:n)],ub=m->triangleCornerUV[t*3u+(size_t)(forward?n:e)];const uint64_t key=(uint64_t(a)<<32)|uint64_t(b);auto& refs=em[key];for(const auto& old:refs)if(uvNear(old.ua,ua)&&uvNear(old.ub,ub))unite(id,old.tri);refs.push_back({id,a,b,ua,ub});}}
    }
    if(tris.empty())return false;
    std::vector<int32_t> rootToIsland(tris.size(),-1);int32_t islandCount=0;for(uint32_t t=0;t<tris.size();++t){uint32_t r=findRoot(t);if(rootToIsland[r]<0)rootToIsland[r]=islandCount++;}
    const size_t count=size_t(width)*size_t(height);std::vector<int32_t> labels(count,-1);
    auto edge=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
    for(uint32_t ti=0;ti<tris.size();++ti){const Tri& tr=tris[ti];const Mesh& m=*tr.mesh;const size_t t=tr.index;const auto a=m.triangleCornerUV[t*3u],b=m.triangleCornerUV[t*3u+1u],c=m.triangleCornerUV[t*3u+2u];const float ax=a.first*width,ay=(1-a.second)*height,bx=b.first*width,by=(1-b.second)*height,cx=c.first*width,cy=(1-c.second)*height;if(!std::isfinite(ax)||!std::isfinite(ay)||!std::isfinite(bx)||!std::isfinite(by)||!std::isfinite(cx)||!std::isfinite(cy))continue;const float area=edge(ax,ay,bx,by,cx,cy);if(std::fabs(area)<1e-8f)continue;const int x0=std::clamp((int)std::floor(std::min({ax,bx,cx})-1),0,width-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,cx})+1),0,width-1),y0=std::clamp((int)std::floor(std::min({ay,by,cy})-1),0,height-1),y1=std::clamp((int)std::ceil(std::max({ay,by,cy})+1),0,height-1);const int32_t island=rootToIsland[findRoot(ti)];for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){const float px=x+0.5f,py=y+0.5f,e0=edge(ax,ay,bx,by,px,py),e1=edge(bx,by,cx,cy,px,py),e2=edge(cx,cy,ax,ay,px,py);if((area>0&&e0>=-1e-4f&&e1>=-1e-4f&&e2>=-1e-4f)||(area<0&&e0<=1e-4f&&e1<=1e-4f&&e2<=1e-4f)){int32_t& dst=labels[size_t(y)*width+x];if(dst<0)dst=island;else if(dst!=island)dst=-2;}}}
    if(std::none_of(labels.begin(),labels.end(),[](int32_t v){return v!=-1;}))return false;
    const int padding=effectivePadding(width,height,requestedPadding);std::vector<uint32_t> frontier,next;frontier.reserve(std::min(count/128u+1u,size_t(1u<<20)));next.reserve(frontier.capacity());
    for(int y=0;y<height;++y)for(int x=0;x<width;++x){const size_t i=size_t(y)*width+x;if(labels[i]<0)continue;bool boundary=false;for(int oy=-1;oy<=1&&!boundary;++oy)for(int ox=-1;ox<=1;++ox){if(!ox&&!oy)continue;const int nx=x+ox,ny=y+oy;if(nx<0||ny<0||nx>=width||ny>=height||labels[size_t(ny)*width+nx]==-1){boundary=true;break;}}if(boundary)frontier.push_back((uint32_t)i);}
    for(int step=0;step<padding&&!frontier.empty();++step){next.clear();for(uint32_t si:frontier){const int x=(int)(si%(uint32_t)width),y=(int)(si/(uint32_t)width);const int32_t island=labels[si];if(island<0)continue;for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){if(!ox&&!oy)continue;const int nx=x+ox,ny=y+oy;if(nx<0||ny<0||nx>=width||ny>=height)continue;const size_t di=size_t(ny)*width+nx;if(labels[di]!=-1)continue;labels[di]=island;uint8_t* dst=rgba.data()+di*4u;const uint8_t* src=rgba.data()+size_t(si)*4u;dst[0]=src[0];dst[1]=src[1];dst[2]=src[2];dst[3]=255;next.push_back((uint32_t)di);}}frontier.swap(next);}
    for(size_t i=0;i<count;++i)if(labels[i]==-1)rgba[i*4u+3u]=0;
    return true;
}

// A paint dab must be clipped to the UV island of the triangle under the
// cursor. The ordinary union mask is useful for canvas/export operations, but
// it allows one dab to paint a nearby, unrelated island when their atlas
// footprints are close. This cache builds geometric/UV-connected islands once
// and rasterizes only the currently active island into one reusable byte mask.
struct PaintIslandMaskCache {
    struct Span { uint16_t y=0,x0=0,x1=0; };
    struct Bounds { int minX=0,minY=0,maxX=-1,maxY=-1; };
    const Mesh* mesh=nullptr;
    int objectId=-1,width=0,height=0;
    uint64_t uvRevision=~uint64_t(0),topologyRevision=~uint64_t(0);
    std::vector<int32_t> triangleIsland;
    std::vector<std::vector<uint32_t>> islandTriangles;
    // Compact per-island scanline runs. This avoids one full atlas allocation
    // per island while making revisits independent of triangle rasterization.
    std::vector<std::vector<Span>> islandSpans;
    std::vector<Bounds> islandBounds;
    std::vector<uint8_t> islandBuilt;
    std::vector<uint8_t> pixels;
    // Packed union coverage: one bit per texel instead of a second full byte mask.
    std::vector<uint64_t> occupied;
    int activeIsland=-1;
    bool valid=false;
};
inline PaintIslandMaskCache& paintIslandMaskCache(){static PaintIslandMaskCache value;return value;}
inline bool paintIslandUVNear(const std::pair<float,float>&a,const std::pair<float,float>&b){
    return std::isfinite(a.first)&&std::isfinite(a.second)&&std::isfinite(b.first)&&std::isfinite(b.second)&&
           std::fabs(a.first-b.first)<=1.0e-5f&&std::fabs(a.second-b.second)<=1.0e-5f;
}
inline const std::vector<uint8_t>& getPaintIslandMask(const Mesh& mesh,int objectId,int width,int height,
                                                       uint32_t triangleIndex,bool* validOut=nullptr){
    static const std::vector<uint8_t> empty;
    PaintIslandMaskCache& c=paintIslandMaskCache();
    width=std::clamp(width,1,8192);height=std::clamp(height,1,8192);
    const size_t triangleCount=std::min(mesh.indices.size()/3u,mesh.triangleCornerUV.size()/3u);
    const bool rebuild=c.mesh!=&mesh||c.objectId!=objectId||c.width!=width||c.height!=height||
        c.uvRevision!=mesh.uvRevision||c.topologyRevision!=mesh.topologyRevision||c.triangleIsland.size()!=triangleCount;
    if(rebuild){
        c.mesh=&mesh;c.objectId=objectId;c.width=width;c.height=height;
        c.uvRevision=mesh.uvRevision;c.topologyRevision=mesh.topologyRevision;
        c.triangleIsland.assign(triangleCount,-1);c.islandTriangles.clear();c.islandSpans.clear();c.islandBounds.clear();c.islandBuilt.clear();
        c.pixels.assign(size_t(width)*size_t(height),0);c.activeIsland=-1;
        bool unionValid=false;const auto& unionMask=get(mesh,objectId,width,height,0,&unionValid);
        c.occupied.clear();
        if(unionValid&&unionMask.size()==size_t(width)*size_t(height)){
            c.occupied.assign((unionMask.size()+63u)/64u,0u);
            for(size_t i=0;i<unionMask.size();++i)if(unionMask[i])c.occupied[i>>6u]|=(uint64_t(1)<<(i&63u));
        }
        std::vector<uint32_t> parent(triangleCount),rank(triangleCount,0u);
        for(uint32_t t=0;t<parent.size();++t)parent[t]=t;
        auto root=[&](uint32_t x){uint32_t r=x;while(parent[r]!=r)r=parent[r];while(parent[x]!=x){uint32_t n=parent[x];parent[x]=r;x=n;}return r;};
        auto unite=[&](uint32_t a,uint32_t b){a=root(a);b=root(b);if(a==b)return;if(rank[a]<rank[b])std::swap(a,b);parent[b]=a;if(rank[a]==rank[b])++rank[a];};
        struct EdgeRef{uint64_t key=0;uint32_t triangle=0;std::pair<float,float> a{},b{};};
        // Keep edge references contiguous. The previous hash-of-vectors layout
        // performed a separate heap allocation for many unique mesh edges; a
        // flat sorted array has predictable storage and better locality on
        // dense meshes with thousands of UV islands.
        std::vector<EdgeRef> edges;edges.reserve(triangleCount*3u);
        for(uint32_t t=0;t<triangleCount;++t){
            const size_t base=size_t(t)*3u;
            for(uint32_t e=0;e<3u;++e){const uint32_t n=(e+1u)%3u,va=mesh.indices[base+e],vb=mesh.indices[base+n];
                if(va>=mesh.vertices.size()||vb>=mesh.vertices.size()||va==vb)continue;
                const bool forward=va<vb;
                const auto ua=mesh.triangleCornerUV[base+(forward?e:n)],ub=mesh.triangleCornerUV[base+(forward?n:e)];
                const uint64_t key=(uint64_t(std::min(va,vb))<<32)|uint64_t(std::max(va,vb));
                edges.push_back({key,t,ua,ub});
            }
        }
        std::sort(edges.begin(),edges.end(),[](const EdgeRef& a,const EdgeRef& b){
            if(a.key!=b.key)return a.key<b.key;
            return a.triangle<b.triangle;
        });
        for(size_t first=0;first<edges.size();){
            size_t last=first+1u;while(last<edges.size()&&edges[last].key==edges[first].key)++last;
            for(size_t i=first;i<last;++i)for(size_t j=first;j<i;++j)
                if(paintIslandUVNear(edges[j].a,edges[i].a)&&paintIslandUVNear(edges[j].b,edges[i].b))unite(edges[i].triangle,edges[j].triangle);
            first=last;
        }
        std::unordered_map<uint32_t,int32_t> rootIds;rootIds.reserve(triangleCount);
        for(uint32_t t=0;t<triangleCount;++t){const uint32_t r=root(t);auto it=rootIds.find(r);if(it==rootIds.end()){const int32_t id=(int32_t)c.islandTriangles.size();it=rootIds.emplace(r,id).first;c.islandTriangles.emplace_back();}c.triangleIsland[t]=it->second;c.islandTriangles[(size_t)it->second].push_back(t);}
        c.islandSpans.resize(c.islandTriangles.size());c.islandBounds.resize(c.islandTriangles.size());c.islandBuilt.assign(c.islandTriangles.size(),0);
        c.valid=!c.islandTriangles.empty();
    }
    if(triangleIndex>=c.triangleIsland.size()||c.triangleIsland[triangleIndex]<0||!c.valid){if(validOut)*validOut=false;return empty;}
    const int32_t island=c.triangleIsland[triangleIndex];
    if(c.activeIsland!=island){
        // Clear only the previous island's occupied runs, not its bounding box.
        if(c.activeIsland>=0&&size_t(c.activeIsland)<c.islandSpans.size()){
            for(const auto& span:c.islandSpans[(size_t)c.activeIsland]){
                const size_t row=size_t(span.y)*size_t(width);
                std::fill(c.pixels.begin()+row+span.x0,c.pixels.begin()+row+size_t(span.x1)+1u,uint8_t(0));
            }
        }
        auto& spans=c.islandSpans[(size_t)island];
        if(c.islandBuilt[(size_t)island]){
            for(const auto& span:spans){const size_t row=size_t(span.y)*size_t(width);std::fill(c.pixels.begin()+row+span.x0,c.pixels.begin()+row+size_t(span.x1)+1u,uint8_t(255));}
        }else{
            PaintIslandMaskCache::Bounds bounds{width,height,-1,-1};
            const auto& triangles=c.islandTriangles[(size_t)island];
            auto edge=[](float ax,float ay,float bx,float by,float px,float py){return (px-ax)*(by-ay)-(py-ay)*(bx-ax);};
            for(uint32_t t:triangles){const size_t base=size_t(t)*3u;const auto a=mesh.triangleCornerUV[base],b=mesh.triangleCornerUV[base+1u],d=mesh.triangleCornerUV[base+2u];
                const float ax=a.first*float(width),ay=(1.0f-a.second)*float(height),bx=b.first*float(width),by=(1.0f-b.second)*float(height),dx=d.first*float(width),dy=(1.0f-d.second)*float(height);
                if(!std::isfinite(ax)||!std::isfinite(ay)||!std::isfinite(bx)||!std::isfinite(by)||!std::isfinite(dx)||!std::isfinite(dy))continue;
                const float area=edge(ax,ay,bx,by,dx,dy);if(std::fabs(area)<1.0e-12f)continue;
                const int x0=std::clamp((int)std::floor(std::min({ax,bx,dx})-1.0f),0,width-1),x1=std::clamp((int)std::ceil(std::max({ax,bx,dx})+1.0f),0,width-1);
                const int y0=std::clamp((int)std::floor(std::min({ay,by,dy})-1.0f),0,height-1),y1=std::clamp((int)std::ceil(std::max({ay,by,dy})+1.0f),0,height-1);
                bounds.minX=std::min(bounds.minX,x0);bounds.maxX=std::max(bounds.maxX,x1);bounds.minY=std::min(bounds.minY,y0);bounds.maxY=std::max(bounds.maxY,y1);
                bool triangleHasCoverage=false;
                for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){const float px=float(x)+0.5f,py=float(y)+0.5f;const float e0=edge(ax,ay,bx,by,px,py),e1=edge(bx,by,dx,dy,px,py),e2=edge(dx,dy,ax,ay,px,py);
                    if((area>0.0f&&e0>=-1e-4f&&e1>=-1e-4f&&e2>=-1e-4f)||(area<0.0f&&e0<=1e-4f&&e1<=1e-4f&&e2<=1e-4f)){c.pixels[size_t(y)*size_t(width)+size_t(x)]=255;triangleHasCoverage=true;}}
                if(!triangleHasCoverage){const float cx=(ax+bx+dx)/3.0f,cy=(ay+by+dy)/3.0f;if(cx>=0.0f&&cx<float(width)&&cy>=0.0f&&cy<float(height))c.pixels[size_t(std::clamp((int)std::floor(cy),0,height-1))*size_t(width)+size_t(std::clamp((int)std::floor(cx),0,width-1))]=255;}
            }
            // Expand by one texel into empty atlas space only; never cross another island.
            if(!c.occupied.empty()&&bounds.maxX>=bounds.minX&&bounds.maxY>=bounds.minY){
                const int oldMinX=bounds.minX,oldMinY=bounds.minY,oldMaxX=bounds.maxX,oldMaxY=bounds.maxY;
                const int rw=oldMaxX-oldMinX+1,rh=oldMaxY-oldMinY+1;std::vector<uint8_t> strict(size_t(rw)*size_t(rh),0);
                for(int y=0;y<rh;++y)std::copy_n(c.pixels.begin()+size_t(oldMinY+y)*size_t(width)+size_t(oldMinX),rw,strict.begin()+size_t(y)*size_t(rw));
                for(int y=oldMinY;y<=oldMaxY;++y)for(int x=oldMinX;x<=oldMaxX;++x){const size_t si=size_t(y-oldMinY)*size_t(rw)+size_t(x-oldMinX);if(!strict[si])continue;
                    for(int oy=-1;oy<=1;++oy)for(int ox=-1;ox<=1;++ox){if(!ox&&!oy)continue;const int nx=x+ox,ny=y+oy;if(nx<0||ny<0||nx>=width||ny>=height)continue;const size_t di=size_t(ny)*size_t(width)+size_t(nx);if((c.occupied[di>>6u]&(uint64_t(1)<<(di&63u)))==0)c.pixels[di]=255;}}
                bounds.minX=std::max(0,oldMinX-1);bounds.minY=std::max(0,oldMinY-1);bounds.maxX=std::min(width-1,oldMaxX+1);bounds.maxY=std::min(height-1,oldMaxY+1);
            }
            // Compress the final editable mask into horizontal spans for cheap reuse.
            if(bounds.maxX>=bounds.minX&&bounds.maxY>=bounds.minY){
                spans.reserve(size_t(bounds.maxY-bounds.minY+1)*4u);
                for(int y=bounds.minY;y<=bounds.maxY;++y){int x=bounds.minX;while(x<=bounds.maxX){while(x<=bounds.maxX&&c.pixels[size_t(y)*size_t(width)+size_t(x)]==0)++x;if(x>bounds.maxX)break;const int x0=x;while(x<=bounds.maxX&&c.pixels[size_t(y)*size_t(width)+size_t(x)]!=0)++x;spans.push_back({(uint16_t)y,(uint16_t)x0,(uint16_t)(x-1)});}}
            }
            c.islandBounds[(size_t)island]=bounds;c.islandBuilt[(size_t)island]=1;
        }
        c.activeIsland=island;
    }
    if(validOut)*validOut=true;
    return c.pixels;
}
inline bool paintIslandMaskAllows(const std::vector<uint8_t>& mask,int width,int height,int x,int y){
    return x>=0&&y>=0&&x<width&&y<height&&mask.size()==size_t(width)*size_t(height)&&mask[size_t(y)*size_t(width)+size_t(x)]!=0;
}
inline bool covered(const std::vector<uint8_t>& mask,int width,int height,int x,int y){return x>=0&&y>=0&&x<width&&y<height&&mask.size()==size_t(width)*size_t(height)&&mask[size_t(y)*size_t(width)+size_t(x)]!=0;}
}
