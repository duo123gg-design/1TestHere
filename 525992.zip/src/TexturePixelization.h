#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <utility>
#include "DitherBlueNoise64.h"

namespace kuro::texture::pixelization {

enum class Mode : int { Pixelate=0, Fake=1, Dither=2 };

struct Params {
    int cellSize=8;
    int levels=6;
    float strength=1.0f;
    Mode mode=Mode::Pixelate;
    int patternType=0; // 0..16, shared with the dithering preview and lighting shader.
    int mapKind=1; // 1 Base Color, 2 Normal, 3 Roughness, 4 Metallic, 5 Emissive.
};

// Normalized [0,1] threshold shared by the texture filter and its UI preview.
// Keeping one implementation prevents the preview from showing a different
// pattern than the pixels written to the texture.
inline float patternThreshold01(int x,int y,int type) noexcept {
    const float fx=float(x&7),fy=float(y&7),parity=float((x+y)&1);
    switch(std::clamp(type,0,16)){
        case 0:{constexpr int bayer[4][4]={{0,8,2,10},{12,4,14,6},{3,11,1,9},{15,7,13,5}};return (float(bayer[y&3][x&3])+0.5f)/16.0f;}
        case 1:return parity*0.72f+0.14f;
        case 2:return float(x&1)*0.72f+0.14f;
        case 3:return float(y&1)*0.72f+0.14f;
        case 4:return (std::min(std::fabs(fx-3.5f),std::fabs(fy-3.5f))<1.0f)?0.18f:0.82f;
        case 5:return float(((x+y)/2)&1)*0.72f+0.14f;
        case 6:return float(((x-y+8)/2)&1)*0.72f+0.14f;
        case 7:{const float a=float(((x+y)/2)&1),b=float(((x-y+8)/2)&1);return std::max(a,b)*0.72f+0.14f;}
        case 8:return std::clamp(std::sqrt((fx-3.5f)*(fx-3.5f)+(fy-3.5f)*(fy-3.5f))/5.0f,0.0f,1.0f);
        case 9:return float((((x+y)/2)+std::abs(x-y)/2)&1)*0.72f+0.14f;
        case 10:return float(((x+y*2)/4)&1)*0.72f+0.14f;
        case 11:return std::fmod(std::sqrt((fx-3.5f)*(fx-3.5f)+(fy-3.5f)*(fy-3.5f))*1.35f,1.0f);
        case 12:{const float n=std::sin((fx+17.0f)*12.9898f+(fy+31.0f)*78.233f)*43758.5453f;return n-std::floor(n);}
        case 13:{const float n=52.9829189f*std::fmod(float(x&7)*0.06711056f+float(y&7)*0.00583715f,1.0f);return n-std::floor(n);}
        case 14:return std::clamp((std::fabs(fx-3.5f)+std::fabs(fy-3.5f))/7.0f,0.0f,1.0f);
        case 16:return float(kKuroBlueNoise64[(y&63)*64+(x&63)])/65535.0f;
        default:{const float angle=std::atan2(fy-3.5f,fx-3.5f),radius=std::sqrt((fx-3.5f)*(fx-3.5f)+(fy-3.5f)*(fy-3.5f));const float v=angle*0.15915494309f+0.5f+radius*0.18f;return v-std::floor(v);}
    }
}
inline float patternThreshold(int x,int y,int type) noexcept {
    return patternThreshold01(x,y,type)-0.5f;
}

inline void decodeNormal(const std::uint8_t* p,float out[3]) noexcept {
    out[0]=float(p[0])/127.5f-1.0f;out[1]=float(p[1])/127.5f-1.0f;out[2]=float(p[2])/127.5f-1.0f;
    const float n=std::sqrt(out[0]*out[0]+out[1]*out[1]+out[2]*out[2]);
    if(n>1.0e-8f){out[0]/=n;out[1]/=n;out[2]/=n;}else{out[0]=out[1]=0.0f;out[2]=1.0f;}
}
inline void encodeNormal(const float in[3],std::uint8_t* p) noexcept {
    float n[3]={in[0],in[1],in[2]};const float l=std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);
    if(l>1.0e-8f){n[0]/=l;n[1]/=l;n[2]/=l;}else{n[0]=n[1]=0.0f;n[2]=1.0f;}
    for(int c=0;c<3;++c)p[c]=static_cast<std::uint8_t>(std::lround(std::clamp(n[c]*0.5f+0.5f,0.0f,1.0f)*255.0f));
}
inline bool isScalarMap(int mapKind) noexcept { return mapKind==3||mapKind==4; }
inline bool isNormalMap(int mapKind) noexcept { return mapKind==2; }

template<class WeightFn>
inline bool applyRegionWeighted(const std::uint8_t* source,std::uint8_t* destination,
                                int width,int height,const Params& input,
                                int x0,int y0,int x1,int y1,
                                const std::uint8_t* validMask,WeightFn&& weightAt) noexcept {
    if(!source||!destination||width<=0||height<=0)return false;
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);
    if(x1<x0||y1<y0)return false;
    const Params p{std::clamp(input.cellSize,2,256),std::clamp(input.levels,2,32),std::clamp(input.strength,0.0f,1.0f),input.mode,std::clamp(input.patternType,0,16),std::clamp(input.mapKind,1,5)};
    if(source!=destination)for(int y=y0;y<=y1;++y){const std::size_t at=(std::size_t(y)*std::size_t(width)+std::size_t(x0))*4u;std::copy(source+at,source+at+std::size_t(x1-x0+1)*4u,destination+at);}
    if(p.strength<=0.0f)return true;
    const bool normal=isNormalMap(p.mapKind),scalar=isScalarMap(p.mapKind);const float invLevels=1.0f/float(p.levels-1);
    auto get=[&](const std::uint8_t* px,float v[3]) noexcept {if(normal)decodeNormal(px,v);else if(scalar){v[0]=v[1]=v[2]=float(px[0])/255.0f;}else{for(int c=0;c<3;++c)v[c]=float(px[c])/255.0f;}};
    auto put=[&](std::uint8_t* px,const float v[3]) noexcept {if(normal)encodeNormal(v,px);else if(scalar){const auto b=static_cast<std::uint8_t>(std::lround(std::clamp(v[0],0.0f,1.0f)*255.0f));px[0]=px[1]=px[2]=b;}else for(int c=0;c<3;++c)px[c]=static_cast<std::uint8_t>(std::lround(std::clamp(v[c],0.0f,1.0f)*255.0f));};
    if(p.mode==Mode::Dither){
        for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){const std::size_t pixel=std::size_t(y)*std::size_t(width)+std::size_t(x);if(validMask&&validMask[pixel]==0u)continue;const std::size_t at=pixel*4u;float original[3],target[3];get(source+at,original);const float threshold=patternThreshold(x/p.cellSize,y/p.cellSize,p.patternType);const int channels=scalar?1:3;for(int c=0;c<channels;++c){const float encoded=normal?original[c]*0.5f+0.5f:original[c];target[c]=std::clamp(std::floor(encoded*float(p.levels-1)+0.5f+threshold),0.0f,float(p.levels-1))*invLevels;if(normal)target[c]=target[c]*2.0f-1.0f;}if(scalar)target[1]=target[2]=target[0];if(normal){const float n=std::sqrt(target[0]*target[0]+target[1]*target[1]+target[2]*target[2]);if(n>1.0e-8f){target[0]/=n;target[1]/=n;target[2]/=n;}else{target[0]=target[1]=0.0f;target[2]=1.0f;}}const float strength=p.strength*std::clamp(float(weightAt(x,y)),0.0f,1.0f);for(int c=0;c<3;++c)target[c]=original[c]+(target[c]-original[c])*strength;put(destination+at,target);destination[at+3u]=source[at+3u];}
        return true;
    }
    const int cell=p.cellSize,firstX=(x0/cell)*cell,firstY=(y0/cell)*cell;
    for(int by=firstY;by<=y1;by+=cell)for(int bx=firstX;bx<=x1;bx+=cell){const int ex=std::min(width,bx+cell),ey=std::min(height,by+cell);double sum[3]={0,0,0},total=0.0;
        for(int y=by;y<ey;++y)for(int x=bx;x<ex;++x){const std::size_t pixel=std::size_t(y)*std::size_t(width)+std::size_t(x);if(validMask&&validMask[pixel]==0u)continue;const std::size_t at=pixel*4u;const double a=double(source[at+3u])/255.0;if(a<=0.0)continue;float v[3];get(source+at,v);total+=a;for(int c=0;c<3;++c)sum[c]+=double(v[c])*a;}
        float average[3]={0,0,1};if(total>1.0e-9)for(int c=0;c<3;++c)average[c]=float(sum[c]/total);if(normal){const float n=std::sqrt(average[0]*average[0]+average[1]*average[1]+average[2]*average[2]);if(n>1.0e-8f){average[0]/=n;average[1]/=n;average[2]/=n;}else{average[0]=average[1]=0;average[2]=1;}}
        float quantized[3];for(int c=0;c<3;++c){const float encoded=normal?average[c]*0.5f+0.5f:average[c];quantized[c]=std::round(std::clamp(encoded,0.0f,1.0f)*float(p.levels-1))*invLevels;if(normal)quantized[c]=quantized[c]*2.0f-1.0f;}if(normal){const float n=std::sqrt(quantized[0]*quantized[0]+quantized[1]*quantized[1]+quantized[2]*quantized[2]);if(n>1.0e-8f){quantized[0]/=n;quantized[1]/=n;quantized[2]/=n;}else{quantized[0]=quantized[1]=0;quantized[2]=1;}}if(scalar)quantized[1]=quantized[2]=quantized[0];
        const int wx0=std::max(bx,x0),wy0=std::max(by,y0),wx1=std::min(ex-1,x1),wy1=std::min(ey-1,y1);
        for(int y=wy0;y<=wy1;++y)for(int x=wx0;x<=wx1;++x){const std::size_t pixel=std::size_t(y)*std::size_t(width)+std::size_t(x);if(validMask&&validMask[pixel]==0u)continue;const std::size_t at=pixel*4u;float original[3],target[3];get(source+at,original);for(int c=0;c<3;++c)target[c]=p.mode==Mode::Fake?quantized[c]:average[c];const float strength=p.strength*std::clamp(float(weightAt(x,y)),0.0f,1.0f)*(p.mode==Mode::Fake?0.52f:1.0f);for(int c=0;c<3;++c)target[c]=original[c]+(target[c]-original[c])*strength;if(normal){const float n=std::sqrt(target[0]*target[0]+target[1]*target[1]+target[2]*target[2]);if(n>1.0e-8f){target[0]/=n;target[1]/=n;target[2]/=n;}else{target[0]=target[1]=0;target[2]=1;}}put(destination+at,target);destination[at+3u]=source[at+3u];}
    }
    return true;
}

template<class WeightFn>
inline bool applyPreviewRegionWeighted(std::uint8_t* pixels,int width,int height,const Params& input,
                                       int x0,int y0,int x1,int y1,int previewStep,
                                       const std::uint8_t* validMask,WeightFn&& weightAt) noexcept {
    if(!pixels||width<=0||height<=0)return false;previewStep=std::clamp(previewStep,1,64);
    if(previewStep==1)return applyRegionWeighted(pixels,pixels,width,height,input,x0,y0,x1,y1,validMask,std::forward<WeightFn>(weightAt));
    x0=std::clamp(x0,0,width-1);y0=std::clamp(y0,0,height-1);x1=std::clamp(x1,0,width-1);y1=std::clamp(y1,0,height-1);if(x1<x0||y1<y0)return false;
    const Params p{std::clamp(input.cellSize,2,256),std::clamp(input.levels,2,32),std::clamp(input.strength,0.0f,1.0f),input.mode,std::clamp(input.patternType,0,16),std::clamp(input.mapKind,1,5)};if(p.strength<=0.0f)return true;
    const bool normal=isNormalMap(p.mapKind),scalar=isScalarMap(p.mapKind);const float invLevels=1.0f/float(p.levels-1);const int gridW=(x1-x0+previewStep)/previewStep,gridH=(y1-y0+previewStep)/previewStep,cellGrid=std::max(1,int(std::lround(float(p.cellSize)/float(previewStep))));
    auto get=[&](const std::uint8_t* px,float v[3]) noexcept {if(normal)decodeNormal(px,v);else if(scalar)v[0]=v[1]=v[2]=float(px[0])/255.0f;else for(int c=0;c<3;++c)v[c]=float(px[c])/255.0f;};
    auto put=[&](std::uint8_t* px,const float v[3]) noexcept {if(normal)encodeNormal(v,px);else if(scalar){const auto b=static_cast<std::uint8_t>(std::lround(std::clamp(v[0],0.0f,1.0f)*255.0f));px[0]=px[1]=px[2]=b;}else for(int c=0;c<3;++c)px[c]=static_cast<std::uint8_t>(std::lround(std::clamp(v[c],0.0f,1.0f)*255.0f));};
    for(int gy0=0;gy0<gridH;gy0+=cellGrid)for(int gx0=0;gx0<gridW;gx0+=cellGrid){const int gy1=std::min(gridH,gy0+cellGrid),gx1=std::min(gridW,gx0+cellGrid);double sum[3]={0,0,0},total=0.0;
        if(p.mode!=Mode::Dither)for(int gy=gy0;gy<gy1;++gy)for(int gx=gx0;gx<gx1;++gx){const int sx=std::min(x1,x0+gx*previewStep),sy=std::min(y1,y0+gy*previewStep);const std::size_t pixel=std::size_t(sy)*std::size_t(width)+std::size_t(sx);if(validMask&&validMask[pixel]==0u)continue;const std::size_t at=pixel*4u;const double a=double(pixels[at+3u])/255.0;if(a<=0.0)continue;float v[3];get(pixels+at,v);total+=a;for(int c=0;c<3;++c)sum[c]+=double(v[c])*a;}
        float average[3]={0,0,1};if(total>1.0e-9)for(int c=0;c<3;++c)average[c]=float(sum[c]/total);if(normal){const float n=std::sqrt(average[0]*average[0]+average[1]*average[1]+average[2]*average[2]);if(n>1.0e-8f){average[0]/=n;average[1]/=n;average[2]/=n;}else{average[0]=average[1]=0;average[2]=1;}}
        float quantized[3];for(int c=0;c<3;++c){const float encoded=normal?average[c]*0.5f+0.5f:average[c];quantized[c]=std::round(std::clamp(encoded,0.0f,1.0f)*float(p.levels-1))*invLevels;if(normal)quantized[c]=quantized[c]*2.0f-1.0f;}if(normal){const float n=std::sqrt(quantized[0]*quantized[0]+quantized[1]*quantized[1]+quantized[2]*quantized[2]);if(n>1.0e-8f){quantized[0]/=n;quantized[1]/=n;quantized[2]/=n;}else{quantized[0]=quantized[1]=0;quantized[2]=1;}}if(scalar)quantized[1]=quantized[2]=quantized[0];
        for(int gy=gy0;gy<gy1;++gy)for(int gx=gx0;gx<gx1;++gx){const int sx=std::min(x1,x0+gx*previewStep),sy=std::min(y1,y0+gy*previewStep),bx1=std::min(x1,sx+previewStep-1),by1=std::min(y1,sy+previewStep-1);const std::size_t sampleAt=(std::size_t(sy)*std::size_t(width)+std::size_t(sx))*4u;float sampleTarget[3];if(p.mode==Mode::Dither){float original[3];get(pixels+sampleAt,original);const float t=patternThreshold(sx/p.cellSize,sy/p.cellSize,p.patternType);for(int c=0;c<3;++c){const float encoded=normal?original[c]*0.5f+0.5f:original[c];sampleTarget[c]=std::clamp(std::floor(encoded*float(p.levels-1)+0.5f+t),0.0f,float(p.levels-1))*invLevels;if(normal)sampleTarget[c]=sampleTarget[c]*2.0f-1.0f;}if(normal){const float n=std::sqrt(sampleTarget[0]*sampleTarget[0]+sampleTarget[1]*sampleTarget[1]+sampleTarget[2]*sampleTarget[2]);if(n>1.0e-8f){sampleTarget[0]/=n;sampleTarget[1]/=n;sampleTarget[2]/=n;}else{sampleTarget[0]=sampleTarget[1]=0;sampleTarget[2]=1;}}if(scalar)sampleTarget[1]=sampleTarget[2]=sampleTarget[0];}
            for(int y=sy;y<=by1;++y)for(int x=sx;x<=bx1;++x){const std::size_t pixel=std::size_t(y)*std::size_t(width)+std::size_t(x);if(validMask&&validMask[pixel]==0u)continue;const std::size_t at=pixel*4u;float original[3],target[3];get(pixels+at,original);for(int c=0;c<3;++c){const float t=p.mode==Mode::Dither?sampleTarget[c]:(p.mode==Mode::Fake?quantized[c]:average[c]);const float strength=p.strength*std::clamp(float(weightAt(x,y)),0.0f,1.0f)*(p.mode==Mode::Fake?0.52f:1.0f);target[c]=original[c]+(t-original[c])*strength;}if(normal){const float n=std::sqrt(target[0]*target[0]+target[1]*target[1]+target[2]*target[2]);if(n>1.0e-8f){target[0]/=n;target[1]/=n;target[2]/=n;}else{target[0]=target[1]=0;target[2]=1;}}put(pixels+at,target);}
        }
    }
    return true;
}

inline bool applyRegion(const std::uint8_t* source,std::uint8_t* destination,int width,int height,const Params& params,int x0,int y0,int x1,int y1,const std::uint8_t* validMask=nullptr) noexcept {
    return applyRegionWeighted(source,destination,width,height,params,x0,y0,x1,y1,validMask,[](int,int) noexcept{return 1.0f;});
}
inline bool apply(const std::uint8_t* source,std::uint8_t* destination,int width,int height,const Params& params) noexcept {
    return applyRegion(source,destination,width,height,params,0,0,width-1,height-1,nullptr);
}

} // namespace kuro::texture::pixelization
