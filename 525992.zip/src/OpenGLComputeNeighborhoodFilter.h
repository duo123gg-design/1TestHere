#pragma once

// GPU executor for the deterministic 3x3 neighborhood filter reference.
// A horizontal integer pass stores weighted RGB sums + weights in RGBA16UI;
// a vertical pass combines them and performs the same integer rounding as CPU.
// This avoids intermediate 8-bit quantization and preserves UV-mask semantics.
#include "TextureNeighborhoodFilterCore.h"
#include "SparseRGBAImage.h"
#include "OpenGLComputeTextureFilter.h"
#include <array>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <vector>

namespace kuro::glcompute::neighborhood_detail {
using Api = texture_filter_detail::Api;
using texture_filter_detail::cachedApi;
using texture_filter_detail::proc;

struct Program { GLuint id=0; GLint size=-1, mode=-1, amount=-1, pass=-1; };
struct TextureSet { GLuint ids[3]={0,0,0}; int width=0,height=0; };
struct Decision { int width=0,height=0,mode=0,amountBits=0,selected=0; };
inline Program& cachedProgram(){ static Program p{}; return p; }
inline TextureSet& cachedTextures(){ static TextureSet t{}; return t; }
inline std::array<Decision,8>& decisions(){ static std::array<Decision,8> d{}; return d; }
inline int bits(float v){ int out=0; std::memcpy(&out,&v,sizeof(out)); return out; }
inline Decision* findDecision(int w,int h,textureneighborhood::Mode mode,float amount){
    for(auto& d:decisions()) if(d.selected && d.width==w && d.height==h && d.mode==int(mode) && d.amountBits==bits(amount)) return &d;
    return nullptr;
}
inline void storeDecision(int w,int h,textureneighborhood::Mode mode,float amount,bool use){
    auto& ds=decisions(); Decision* slot=&ds[0];
    for(auto& d:ds){ if(!d.selected){slot=&d;break;} if(d.width==w&&d.height==h&&d.mode==int(mode)&&d.amountBits==bits(amount)){slot=&d;break;} }
    *slot={w,h,int(mode),bits(amount),use?1:-1};
}
inline Program& program(){
    Program& p=cachedProgram(); if(p.id) return p;
    Api& api=cachedApi(); if(!api.load()) return p;
    constexpr GLenum COMPUTE=0x91B9, COMPILE=0x8B81, LINK=0x8B82;
    const char* src=R"GLSL(#version 430 compatibility
layout(local_size_x=16,local_size_y=16,local_size_z=1) in;
layout(rgba8,binding=0) readonly uniform image2D sourceImage;
layout(rgba16ui,binding=1) uniform uimage2D intermediateImage;
layout(rgba8,binding=2) writeonly uniform image2D outputImage;
uniform ivec2 uSize; uniform int uMode; uniform float uAmount; uniform int uPass;
const int K[3]=int[3](1,2,1);
void main(){
 ivec2 p=ivec2(gl_GlobalInvocationID.xy); if(any(greaterThanEqual(p,uSize))) return;
 if(uPass==0){
  uvec3 sum=uvec3(0u); uint weight=0u;
  for(int k=-1;k<=1;++k){ivec2 q=p+ivec2(k,0);if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,uSize)))continue;
   vec4 s=imageLoad(sourceImage,q);if(s.a<0.999)continue;
   uint w=uint(K[k+1]);sum+=uvec3(round(s.rgb*255.0))*w;weight+=w;
  }
  imageStore(intermediateImage,p,uvec4(sum,weight)); return;
 }
 vec4 center=imageLoad(sourceImage,p);
 if(center.a<0.999){imageStore(outputImage,p,vec4(0.0));return;}
 uvec3 sum=uvec3(0u);uint weight=0u;
 for(int k=-1;k<=1;++k){ivec2 q=p+ivec2(0,k);if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,uSize)))continue;
  uvec4 h=imageLoad(intermediateImage,q);uint w=uint(K[k+1]);sum+=h.rgb*w;weight+=h.a*w;
 }
 uvec3 blur=weight>0u?(sum+uvec3(weight/2u))/weight:uvec3(round(center.rgb*255.0));
 uvec3 result=blur;
 if(uMode==1){vec3 v=vec3(round(center.rgb*255.0));vec3 s=v+(v-vec3(blur))*clamp(uAmount,0.0,2.0);result=uvec3(floor(clamp(s,0.0,255.0)+vec3(0.5)));}
 imageStore(outputImage,p,vec4(vec3(result)/255.0,1.0));
}
)GLSL";
    GLuint sh=api.createShader(COMPUTE); if(!sh) return p;
    api.shaderSource(sh,1,&src,nullptr); api.compileShader(sh); GLint ok=0; api.getShaderiv(sh,COMPILE,&ok);
    if(!ok){api.deleteShader(sh);return p;}
    GLuint id=api.createProgram(); if(!id){api.deleteShader(sh);return p;}
    api.attachShader(id,sh);api.linkProgram(id);api.deleteShader(sh);api.getProgramiv(id,LINK,&ok);
    if(!ok){api.deleteProgram(id);return p;}
    p.id=id;p.size=api.getUniformLocation(id,"uSize");p.mode=api.getUniformLocation(id,"uMode");p.amount=api.getUniformLocation(id,"uAmount");p.pass=api.getUniformLocation(id,"uPass");
    if(p.size<0||p.mode<0||p.amount<0||p.pass<0){api.deleteProgram(id);p=Program{};}
    return p;
}
inline bool run(const uint8_t* rgba,int w,int h,textureneighborhood::Mode mode,float amount,std::vector<uint8_t>& out,double& ms){
    if(!rgba||w<=0||h<=0||w>2048||h>2048||size_t(w)*size_t(h)>size_t(2048)*2048u||
       (mode!=textureneighborhood::Mode::GaussianBlur&&mode!=textureneighborhood::Mode::Sharpen)) return false;
    Api& api=cachedApi();if(!api.load())return false;Program& p=program();if(!p.id)return false;
    GLint units=0;glGetIntegerv(0x8F38,&units);if(units<3)return false;
    constexpr GLenum CURRENT_PROGRAM=0x8B8D,ACTIVE_TEXTURE=0x84E0,TEXTURE_BINDING_2D=0x8069;
    constexpr GLenum IMAGE_NAME=0x8F3A,IMAGE_LEVEL=0x8F3B,IMAGE_LAYERED=0x8F3C,IMAGE_LAYER=0x8F3D,IMAGE_ACCESS=0x8F3E,IMAGE_FORMAT=0x906E;
    constexpr GLenum READ_ONLY=0x88B8,WRITE_ONLY=0x88B9,RGBA8=0x8058,RGBA16UI=0x8D76,RGBA=0x1908,RGBA_INTEGER=0x8D99,UBYTE=0x1401,USHORT=0x1403;
    constexpr GLbitfield IMAGE_BARRIER=0x20,TEXTURE_BARRIER=0x100;
    TextureSet& t=cachedTextures();const bool resize=t.width!=w||t.height!=h||!t.ids[0]||!t.ids[1]||!t.ids[2];
    if(resize){if(t.ids[0]||t.ids[1]||t.ids[2])glDeleteTextures(3,t.ids);t.ids[0]=t.ids[1]=t.ids[2]=0;glGenTextures(3,t.ids);if(!t.ids[0]||!t.ids[1]||!t.ids[2]){glDeleteTextures(3,t.ids);t=TextureSet{};return false;}t.width=w;t.height=h;}
    GLint oldProgram=0,oldActive=0,oldTexture=0,oldUnpack=4,oldPack=4;
    glGetIntegerv(CURRENT_PROGRAM,&oldProgram);glGetIntegerv(ACTIVE_TEXTURE,&oldActive);glGetIntegerv(TEXTURE_BINDING_2D,&oldTexture);glGetIntegerv(0x0CF5,&oldUnpack);glGetIntegerv(0x0D05,&oldPack);
    GLint oldImage[3][6]{};for(GLuint i=0;i<3;++i){api.getIntegeriV(IMAGE_NAME,i,&oldImage[i][0]);api.getIntegeriV(IMAGE_LEVEL,i,&oldImage[i][1]);api.getIntegeriV(IMAGE_LAYERED,i,&oldImage[i][2]);api.getIntegeriV(IMAGE_LAYER,i,&oldImage[i][3]);api.getIntegeriV(IMAGE_ACCESS,i,&oldImage[i][4]);api.getIntegeriV(IMAGE_FORMAT,i,&oldImage[i][5]);}
    while(glGetError()!=GL_NO_ERROR){}
    const auto begin=std::chrono::steady_clock::now();glPixelStorei(0x0CF5,1);glPixelStorei(0x0D05,1);
    for(int i=0;i<3;++i){glBindTexture(GL_TEXTURE_2D,t.ids[i]);if(resize){glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);if(i==1)glTexImage2D(GL_TEXTURE_2D,0,RGBA16UI,w,h,0,RGBA_INTEGER,USHORT,nullptr);else glTexImage2D(GL_TEXTURE_2D,0,RGBA8,w,h,0,RGBA,UBYTE,nullptr);}}
    glBindTexture(GL_TEXTURE_2D,t.ids[0]);glTexSubImage2D(GL_TEXTURE_2D,0,0,0,w,h,RGBA,UBYTE,rgba);
    api.useProgram(p.id);api.uniform2i(p.size,w,h);api.uniform1i(p.mode,int(mode));
    using Uniform1fFn=void(APIENTRY*)(GLint,GLfloat);auto uniform1f=reinterpret_cast<Uniform1fFn>(proc("glUniform1f"));if(!uniform1f){api.useProgram((GLuint)oldProgram);glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);api.activeTexture((GLenum)oldActive);glPixelStorei(0x0CF5,oldUnpack);glPixelStorei(0x0D05,oldPack);return false;}
    uniform1f(p.amount,std::clamp(amount,0.0f,2.0f));
    api.bindImageTexture(0,t.ids[0],0,GL_FALSE,0,READ_ONLY,RGBA8);api.bindImageTexture(1,t.ids[1],0,GL_FALSE,0,WRITE_ONLY,RGBA16UI);
    api.uniform1i(p.pass,0);api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(IMAGE_BARRIER);
    api.bindImageTexture(1,t.ids[1],0,GL_FALSE,0,READ_ONLY,RGBA16UI);api.bindImageTexture(2,t.ids[2],0,GL_FALSE,0,WRITE_ONLY,RGBA8);
    api.uniform1i(p.pass,1);api.dispatchCompute((GLuint(w)+15u)/16u,(GLuint(h)+15u)/16u,1);api.memoryBarrier(IMAGE_BARRIER|TEXTURE_BARRIER);
    out.resize(size_t(w)*size_t(h)*4u);glBindTexture(GL_TEXTURE_2D,t.ids[2]);glGetTexImage(GL_TEXTURE_2D,0,RGBA,UBYTE,out.data());const bool ok=glGetError()==GL_NO_ERROR;
    api.useProgram((GLuint)oldProgram);for(GLuint i=0;i<3;++i){if(oldImage[i][0])api.bindImageTexture(i,(GLuint)oldImage[i][0],oldImage[i][1],(GLboolean)oldImage[i][2],oldImage[i][3],(GLenum)oldImage[i][4],(GLenum)oldImage[i][5]);else api.bindImageTexture(i,0,0,GL_FALSE,0,READ_ONLY,RGBA8);}
    glBindTexture(GL_TEXTURE_2D,(GLuint)oldTexture);api.activeTexture((GLenum)oldActive);glPixelStorei(0x0CF5,oldUnpack);glPixelStorei(0x0D05,oldPack);
    ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();return ok;
}
inline bool cpu(const uint8_t* rgba,int w,int h,textureneighborhood::Mode mode,float amount,std::vector<uint8_t>& out){return textureneighborhood::apply(rgba,w,h,mode,amount,out);}
}

namespace kuro::glcompute {
// Returns true only when the GPU path is selected. If it returns false after
// valid input, output already contains the CPU reference result.
inline bool neighborhoodFilterAuto(const uint8_t* rgba,int width,int height,textureneighborhood::Mode mode,float amount,std::vector<uint8_t>& output){
    using namespace neighborhood_detail;
    if(!rgba||width<=0||height<=0||width>4096||height>4096)return false;
    amount=std::clamp(amount,0.0f,2.0f);
    Decision* cached=findDecision(width,height,mode,amount);
    if(cached&&cached->selected<0)return cpu(rgba,width,height,mode,amount,output)&&false;
    static std::vector<uint8_t> gpu;
    double gpuMs=0.0;
    if(cached&&cached->selected>0){if(run(rgba,width,height,mode,amount,gpu,gpuMs)&&gpu.size()==size_t(width)*size_t(height)*4u){output.swap(gpu);return true;}storeDecision(width,height,mode,amount,false);return cpu(rgba,width,height,mode,amount,output)&&false;}
    std::vector<uint8_t> cpuReference;const auto cpuStart=std::chrono::steady_clock::now();
    if(!cpu(rgba,width,height,mode,amount,cpuReference))return false;
    const double cpuMs=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-cpuStart).count();
    double warmMs=0.0;
    if(!run(rgba,width,height,mode,amount,gpu,warmMs)||gpu.size()!=cpuReference.size()||!run(rgba,width,height,mode,amount,gpu,gpuMs)||gpu.size()!=cpuReference.size()){
        storeDecision(width,height,mode,amount,false);output.swap(cpuReference);return false;
    }
    int maxDiff=0;for(size_t i=0;i<gpu.size();++i)maxDiff=std::max(maxDiff,std::abs(int(gpu[i])-int(cpuReference[i])));
    const bool accurate=maxDiff<=1;const bool faster=gpuMs<cpuMs*0.92;storeDecision(width,height,mode,amount,accurate&&faster);
    if(accurate&&faster){output.swap(gpu);return true;}output.swap(cpuReference);return false;
}
struct NeighborhoodSparseScratch { std::vector<uint8_t> sourceRegion, filteredRegion; };

// Sparse ROI adapter: reads only the requested rectangle plus a one-pixel
// halo from the immutable source, so neighboring 64x64 tiles contribute at
// seams without materializing the full texture. Destination must be a distinct
// COW copy or output image; source remains unchanged while callers process ROIs.
inline bool neighborhoodFilterSparseRectAuto(const SparseRGBAImage& source,SparseRGBAImage& destination,
                                               int x0,int y0,int x1,int y1,
                                               textureneighborhood::Mode mode,float amount,
                                               NeighborhoodSparseScratch& scratch,size_t* changedPixels=nullptr){
    if(changedPixels)*changedPixels=0;
    if(&source==&destination||source.width()<=0||source.height()<=0||
       destination.width()!=source.width()||destination.height()!=source.height()||
       x1<x0||y1<y0||x1<0||y1<0||x0>=source.width()||y0>=source.height()||
       (mode!=textureneighborhood::Mode::GaussianBlur&&mode!=textureneighborhood::Mode::Sharpen))return false;
    x0=std::clamp(x0,0,source.width()-1);y0=std::clamp(y0,0,source.height()-1);
    x1=std::clamp(x1,0,source.width()-1);y1=std::clamp(y1,0,source.height()-1);
    const int rx0=std::max(0,x0-1),ry0=std::max(0,y0-1);
    const int rx1=std::min(source.width()-1,x1+1),ry1=std::min(source.height()-1,y1+1);
    if(!source.readRect(rx0,ry0,rx1,ry1,scratch.sourceRegion))return false;
    // False means CPU was selected; in that case the auto API still fills the
    // output with the reference result. A correctly sized buffer is success.
    neighborhoodFilterAuto(scratch.sourceRegion.data(),rx1-rx0+1,ry1-ry0+1,mode,amount,scratch.filteredRegion);
    if(scratch.filteredRegion.size()!=scratch.sourceRegion.size())return false;
    const size_t rw=size_t(rx1-rx0+1);size_t changed=0;
    for(int y=y0;y<=y1;++y)for(int x=x0;x<=x1;++x){
        const size_t at=(size_t(y-ry0)*rw+size_t(x-rx0))*4u;
        if(destination.setPixel(x,y,scratch.filteredRegion.data()+at))++changed;
    }
    if(changedPixels)*changedPixels=changed;
    return true;
}
inline void shutdownNeighborhoodFilter(){
    auto& t=neighborhood_detail::cachedTextures();if(t.ids[0]||t.ids[1]||t.ids[2])glDeleteTextures(3,t.ids);t=neighborhood_detail::TextureSet{};
    auto& p=neighborhood_detail::cachedProgram();auto& api=texture_filter_detail::cachedApi();if(p.id&&api.deleteProgram)api.deleteProgram(p.id);p=neighborhood_detail::Program{};
}
}
