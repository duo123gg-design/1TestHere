#pragma once
#include <algorithm>
#include <cstdint>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <tuple>
#include <vector>

// Canonical UV topology for meshes whose triangulated UV stream is authoritative.
// Each source polygon corner can reference one or more independent UV pool IDs
// (for example when xatlas splits a polygon across charts).
struct KuroUVIndependentBoundaryEdge { uint32_t uvA=0,uvB=0,sourceA=0,sourceB=0; };
struct KuroUVIndependentTopology {
    std::vector<std::vector<int>> faceAdjacency;
    std::vector<std::vector<std::vector<uint32_t>>> faceCornerVertexIds;
    std::vector<std::vector<std::pair<uint32_t,uint32_t>>> faceBoundaryUVEdges;
    std::vector<std::vector<std::pair<uint32_t,uint32_t>>> faceBoundarySourceEdges;
    std::vector<std::vector<KuroUVIndependentBoundaryEdge>> faceBoundaryEdgeRefs;
    bool valid=false;
};

static inline uint64_t kuroUVIndependentEdgeKey(uint32_t a,uint32_t b){
    if(a>b)std::swap(a,b);
    return (uint64_t(a)<<32)|uint64_t(b);
}

static inline KuroUVIndependentTopology kuroBuildUVIndependentTopology(const Mesh& mesh){
    KuroUVIndependentTopology out;
    const size_t faceCount=mesh.faces.size();
    if(!mesh.triangleCornerUVIndependent || mesh.indices.size()!=mesh.triangleFaces.size()*3u ||
       mesh.triangleCornerUVVertexIndices.size()!=mesh.indices.size() ||
       mesh.triangleCornerUV.size()!=mesh.indices.size() || mesh.faceTriangleOffsets.size()!=faceCount+1u ||
       (mesh.triangleCornerUVMapWide?mesh.triangleCornerUVIndicesWide.size()!=mesh.indices.size():mesh.triangleCornerUVIndices.size()!=mesh.indices.size()) ||
       mesh.uvVertices.empty())return out;

    out.faceCornerVertexIds.resize(faceCount);
    out.faceBoundaryUVEdges.resize(faceCount);out.faceBoundarySourceEdges.resize(faceCount);out.faceBoundaryEdgeRefs.resize(faceCount);
    for(size_t fi=0;fi<faceCount;++fi)out.faceCornerVertexIds[fi].resize(mesh.faces[fi].size());
    for(size_t ti=0;ti<mesh.triangleFaces.size();++ti){
        const int fi=mesh.triangleFaces[ti];
        if(fi<0||(size_t)fi>=faceCount)return KuroUVIndependentTopology{};
        for(size_t k=0;k<3u;++k){
            const size_t at=ti*3u+k;
            const uint32_t local=mesh.triangleCornerUVMapWide?mesh.triangleCornerUVIndicesWide[at]:mesh.triangleCornerUVIndices[at];
            const uint32_t id=mesh.triangleCornerUVVertexIndices[at];
            if(local>=out.faceCornerVertexIds[(size_t)fi].size()||id>=mesh.uvVertices.size())return KuroUVIndependentTopology{};
            auto& ids=out.faceCornerVertexIds[(size_t)fi][local];
            if(std::find(ids.begin(),ids.end(),id)==ids.end())ids.push_back(id);
        }
    }
    // Preserve exact original polygon boundary edge identities. Triangle sides
    // on internal triangulation diagonals are excluded, and corner chart splits
    // remain distinct UV edge pairs.
    for(size_t ti=0;ti<mesh.triangleFaces.size();++ti){
        const int fi=mesh.triangleFaces[ti];if(fi<0||(size_t)fi>=faceCount)continue;
        const size_t n=mesh.faces[(size_t)fi].size();if(n<2u)continue;
        for(size_t k=0;k<3u;++k){const size_t at=ti*3u+k,bt=ti*3u+(k+1u)%3u;
            const uint32_t la=mesh.triangleCornerUVMapWide?mesh.triangleCornerUVIndicesWide[at]:mesh.triangleCornerUVIndices[at];
            const uint32_t lb=mesh.triangleCornerUVMapWide?mesh.triangleCornerUVIndicesWide[bt]:mesh.triangleCornerUVIndices[bt];
            if(la>=n||lb>=n||(((la+1u)%n)!=lb&&((lb+1u)%n)!=la))continue;
            const uint32_t ua=mesh.triangleCornerUVVertexIndices[at],ub=mesh.triangleCornerUVVertexIndices[bt];
            const uint32_t sa=mesh.indices[at],sb=mesh.indices[bt];
            if(ua!=ub&&sa!=sb){
                out.faceBoundaryUVEdges[(size_t)fi].push_back({std::min(ua,ub),std::max(ua,ub)});
                out.faceBoundarySourceEdges[(size_t)fi].push_back({std::min(sa,sb),std::max(sa,sb)});
                out.faceBoundaryEdgeRefs[(size_t)fi].push_back({std::min(ua,ub),std::max(ua,ub),std::min(sa,sb),std::max(sa,sb)});
            }
        }
    }
    for(size_t fi=0;fi<faceCount;++fi){auto& ue=out.faceBoundaryUVEdges[fi];std::sort(ue.begin(),ue.end());ue.erase(std::unique(ue.begin(),ue.end()),ue.end());auto& se=out.faceBoundarySourceEdges[fi];std::sort(se.begin(),se.end());se.erase(std::unique(se.begin(),se.end()),se.end());auto& refs=out.faceBoundaryEdgeRefs[fi];std::sort(refs.begin(),refs.end(),[](const auto&a,const auto&b){return std::tie(a.uvA,a.uvB,a.sourceA,a.sourceB)<std::tie(b.uvA,b.uvB,b.sourceA,b.sourceB);});refs.erase(std::unique(refs.begin(),refs.end(),[](const auto&a,const auto&b){return a.uvA==b.uvA&&a.uvB==b.uvB&&a.sourceA==b.sourceA&&a.sourceB==b.sourceB;}),refs.end());}
    // Build edge adjacency from original mesh edges, but decide UV continuity
    // solely by canonical independent pool IDs. Never consult faceCornerUV here.
    struct EdgeRef{int face;uint32_t uvLo,uvHi;};
    std::unordered_set<uint64_t> seams;seams.reserve(mesh.uvSeams.size()*2u+1u);
    for(const auto& e:mesh.uvSeams)seams.insert(kuroUVIndependentEdgeKey(e.first,e.second));
    std::unordered_map<uint64_t,std::vector<EdgeRef>> refs;
    refs.reserve(mesh.uniqueEdges.size()*2u+faceCount+1u);
    for(size_t fi=0;fi<faceCount;++fi){
        for(const auto& edge:out.faceBoundaryEdgeRefs[fi])
            refs[kuroUVIndependentEdgeKey(edge.sourceA,edge.sourceB)].push_back({(int)fi,edge.uvA,edge.uvB});
    }
    out.faceAdjacency.resize(faceCount);
    for(const auto& entry:refs){
        if(seams.find(entry.first)!=seams.end())continue;
        const auto& list=entry.second;
        for(size_t i=0;i<list.size();++i)for(size_t j=i+1u;j<list.size();++j){
            if(list[i].face==list[j].face||list[i].uvLo!=list[j].uvLo||list[i].uvHi!=list[j].uvHi)continue;
            out.faceAdjacency[(size_t)list[i].face].push_back(list[j].face);
            out.faceAdjacency[(size_t)list[j].face].push_back(list[i].face);
        }
    }
    // A canonical UV pool ID cannot be transformed by two supposedly separate
    // selections. Treat point-only contacts that share the exact pool ID as one
    // selectable component, matching the packing path's rigid-transform rule.
    std::unordered_map<uint32_t,int> firstFaceForUVId;firstFaceForUVId.reserve(mesh.triangleCornerUVVertexIndices.size());
    for(size_t fi=0;fi<out.faceCornerVertexIds.size();++fi)for(const auto& cornerIds:out.faceCornerVertexIds[fi])for(uint32_t id:cornerIds){
        auto inserted=firstFaceForUVId.emplace(id,(int)fi);
        if(!inserted.second&&inserted.first->second!=(int)fi){const int other=inserted.first->second;out.faceAdjacency[fi].push_back(other);out.faceAdjacency[(size_t)other].push_back((int)fi);}
    }
    for(auto& a:out.faceAdjacency){std::sort(a.begin(),a.end());a.erase(std::unique(a.begin(),a.end()),a.end());}
    out.valid=true;
    return out;
}

static inline std::vector<int> kuroUVIndependentFaceComponent(const KuroUVIndependentTopology& topology,const std::vector<int>& seeds){
    std::vector<int> result;
    if(!topology.valid)return result;
    std::vector<uint8_t> seen(topology.faceAdjacency.size(),0u);
    std::vector<int> stack;stack.reserve(seeds.size()+16u);
    for(int fi:seeds)if(fi>=0&&(size_t)fi<seen.size()&&!seen[(size_t)fi]){seen[(size_t)fi]=1u;stack.push_back(fi);}
    while(!stack.empty()){
        const int fi=stack.back();stack.pop_back();result.push_back(fi);
        for(int nb:topology.faceAdjacency[(size_t)fi])if(nb>=0&&(size_t)nb<seen.size()&&!seen[(size_t)nb]){seen[(size_t)nb]=1u;stack.push_back(nb);}
    }
    std::sort(result.begin(),result.end());
    return result;
}
