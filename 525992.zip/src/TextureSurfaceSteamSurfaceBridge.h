#pragma once

// Converts persistent UV-space Steam cells into a bounded set of world-space
// particle spawn requests. No geometry is rebuilt here: callers supply the
// already prepared MeshTopologyCache for the owning object.
#include "TextureSurfaceMaterialState.h"
#include "TextureSurfaceParticleMeshAdapter.h"
#include "TextureSurfaceSteamSimulation.h"
#include <array>
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>

namespace kuro::texture::surface_steam {

struct SurfaceEmitter {
    Vec3 position{};
    Vec3 normal{};
    int mapX=-1,mapY=-1;
    float amount=0.0f;
};

// Visits only allocated material tiles and returns at most Capacity Steam
// sources. cursor rotates through Steam cells so a dense hot patch does not
// monopolize every emission batch. The caller owns particle emission and the
// subsequent Undo-protected source depletion.
template<std::size_t Capacity>
std::size_t gatherMaterialEmitters(
    const kuro::texture::surface_materials::Field& field,
    const kuro::texture::surface_particles::MeshTopologyCache& mesh,
    int objectId,
    kuro::texture::surface_materials::Material sourceMaterial,
    std::size_t& cursor,
    std::array<SurfaceEmitter,Capacity>& out) noexcept {
    static_assert(Capacity>0,"Emitter batch must not be empty");
    if(objectId<0||field.width()<=0||field.height()<=0||!mesh.valid()) return 0u;
    using namespace kuro::texture::surface_materials;
    using namespace kuro::texture::surface_particles;
    std::size_t sourceCount=0u;
    field.forEachAllocatedCell([&](int,int,const Cell& cell){
        if(hasMaterial(cell,sourceMaterial)&&cell.blend>0u) ++sourceCount;
    });
    if(sourceCount==0u){cursor=0u;return 0u;}
    cursor%=sourceCount;
    std::size_t ordinal=0u,written=0u;
    field.forEachAllocatedCell([&](int x,int y,const Cell& cell){
        if(written>=Capacity||!hasMaterial(cell,sourceMaterial)||cell.blend==0u) return;
        const std::size_t current=ordinal++;
        if(current<cursor) return;
        const float u=(float(x)+0.5f)/float(field.width());
        const float v=1.0f-(float(y)+0.5f)/float(field.height());
        std::uint32_t triangleIndex=0u;std::array<float,3> bary{};
        if(!mesh.locateUV(u,v,triangleIndex,bary)) return;
        const Topology& topology=mesh.topology();
        if(triangleIndex>=topology.triangles.size()) return;
        const Triangle& tri=topology.triangles[triangleIndex];
        Vec3 position{};
        for(int k=0;k<3;++k){
            const std::uint32_t vi=tri.vertex[std::size_t(k)];
            if(vi>=topology.vertices.size()) return;
            const auto& vertex=topology.vertices[vi];
            const float weight=bary[std::size_t(k)];
            position+=Vec3{vertex.x*weight,vertex.y*weight,vertex.z*weight};
        }
        SurfaceEmitter& e=out[written++];
        e.position=position;e.normal=Vec3{tri.normal.x,tri.normal.y,tri.normal.z};e.mapX=x;e.mapY=y;
        e.amount=std::clamp(float(cell.blend)/255.0f,0.0f,1.0f);
    });
    // Advance through source-cell ordinals even when a UV cell is not covered
    // by the mesh, so invalid atlas pixels cannot starve later valid sources.
    cursor=(cursor+std::min(Capacity,sourceCount))%sourceCount;
    return written;
}

template<std::size_t Capacity>
std::size_t gatherSurfaceEmitters(
    const kuro::texture::surface_materials::Field& field,
    const kuro::texture::surface_particles::MeshTopologyCache& mesh,
    int objectId,
    std::size_t& cursor,
    std::array<SurfaceEmitter,Capacity>& out) noexcept {
    return gatherMaterialEmitters(field,mesh,objectId,
        kuro::texture::surface_materials::Material::Steam,cursor,out);
}

template<std::size_t Capacity>
std::size_t gatherSmokeEmitters(
    const kuro::texture::surface_materials::Field& field,
    const kuro::texture::surface_particles::MeshTopologyCache& mesh,
    int objectId,
    std::size_t& cursor,
    std::array<SurfaceEmitter,Capacity>& out) noexcept {
    return gatherMaterialEmitters(field,mesh,objectId,
        kuro::texture::surface_materials::Material::Smoke,cursor,out);
}

} // namespace kuro::texture::surface_steam
