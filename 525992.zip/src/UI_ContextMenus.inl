    if(groupContextPending){ImGui::OpenPopup("group_context");groupContextPending=false;}
    if(ImGui::BeginPopup("group_context")){
        int gid=groupContextId;Group* g=scene.groupById(gid);
        if(g){
            ImGui::Text("%s: %s",uiText(languageRussian,"Group","Группа"),g->name.c_str());ImGui::Separator();
            if(!textureMode){
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать")))openRenameGroup(gid);
            if(ImGui::MenuItem(uiText(languageRussian,"Delete Group","Удалить группу")))deleteGroup(gid);
            if(ImGui::MenuItem(g->hidden?"Show":"Hide")){pushUndoState();g->hidden=!g->hidden;if(g->hidden)for(auto&o:scene.objects)if(o.groupId==gid)o.selected=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All Objects","Показать все объекты"))){pushUndoState();for(auto&o:scene.objects)if(o.groupId==gid)o.hidden=false;g->hidden=false;}
            if(ImGui::MenuItem(uiText(languageRussian,"Select All Objects","Выбрать все объекты"))){scene.clearSelection();g->selected=true;for(auto&o:scene.objects)if(o.groupId==gid)o.selected=true;}
            if(ImGui::MenuItem(uiText(languageRussian,"Ungroup","Разгруппировать")))deleteGroup(gid);
            }
        }
        ImGui::EndPopup();
    }
    if(normalsMenuPending){ImGui::OpenPopup("normals_menu");normalsMenuPending=false;}
    if(ImGui::BeginPopup("normals_menu")){
        ImGui::TextUnformatted(uiText(languageRussian,"Normals","Нормали"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
        if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
        if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            if(ImGui::MenuItem(uiText(languageRussian,"Set Normal Direction...","Направление нормалей...")))normalDirectionPopupPending=true;
        ImGui::EndPopup();
    }
    // Match the stable V829 flow: open the viewport popup in the same UI
    // window scope in which BeginPopup() is evaluated. A separate host window
    // with NoInputs changed the popup's parent/interaction context.
    // Do not depend solely on the request being forwarded from handleInput().
    // ImGui's MouseClicked state remains valid throughout this NewFrame, so
    // evaluate the viewport RMB directly in drawUI immediately before opening
    // the popup. This also gives us a definitive log of the entire path.
    const float contextToolbarLeft=showOutliner?342.0f*s:10.0f*s;
    const float contextToolbarRight=showProperties?io.DisplaySize.x-330.0f*s:io.DisplaySize.x-10.0f*s;
    const float contextToolbarTop=io.DisplaySize.y-(editMode?252.0f:232.0f)*s;
    const float contextToolbarBottom=io.DisplaySize.y-56.0f*s;
    const bool contextOverToolbar=showTools && io.MousePos.x>=contextToolbarLeft &&
        io.MousePos.x<contextToolbarRight && io.MousePos.y>=contextToolbarTop && io.MousePos.y<contextToolbarBottom;
    ImGuiWindow* contextHoveredWindow=ImGui::GetCurrentContext()->HoveredWindow;
    const bool contextOverPopup=contextHoveredWindow && (contextHoveredWindow->Flags&ImGuiWindowFlags_Popup)!=0;
    // Mirror the input-router priority here as well: drawUI has a direct RMB
    // fallback for context menus, so it must independently respect the active
    // Fixed Light Ctrl+Shift+RMB gesture.
    const bool fixedLightRotateChordActive = renderMode==ViewRenderMode::Solid &&
        shadingMode==ShadingMode::Lit && solidLightMode==SolidLightMode::Fixed &&
        physicalKeyDown(VK_CONTROL) && physicalKeyDown(VK_SHIFT) && !io.WantTextInput;
    const bool contextRmbViewport =
        io.MouseClicked[ImGuiMouseButton_Right] &&
        io.MousePos.x >= (showOutliner ? 342.0f*s : 0.0f) &&
        io.MousePos.x < (showProperties ? io.DisplaySize.x-330.0f*s : io.DisplaySize.x) &&
        io.MousePos.y >= 86.0f*s && io.MousePos.y < io.DisplaySize.y-46.0f*s &&
        !contextOverToolbar && !contextOverPopup &&
        !ImGui::IsPopupOpen("##brush_shape_menu",ImGuiPopupFlags_AnyPopup) &&
        !ImGui::IsPopupOpen("##brush_stamp_settings",ImGuiPopupFlags_AnyPopup) &&
        !normalDirectionPreviewActive && !transformModal && !extrudeModal &&
        !fixedLightRotateChordActive && scene.selected() && !suppressContextMenuThisFrame;
    if((contextMenuPending || contextRmbViewport) && !suppressContextMenuThisFrame){
        const bool rigBoneContext=animationMode&&animationWorkspace==0&&scene.selected()&&scene.selected()->rigSkeleton&&poseBoneIndex>=0&&size_t(poseBoneIndex)<scene.selected()->rigSkeleton->nodes.size()&&scene.selected()->rigSkeleton->nodes[size_t(poseBoneIndex)].isBone;
        const char* requestedPopup=textureMode?"texture_context":(uvMode?"uv_context":(rigBoneContext?"rig_bone_context":((editMode&&scene.selected()&&mode!=SelectionMode::Object)?"component_context":"object_context")));
        ImGui::OpenPopup(requestedPopup);
        contextMenuPending=false;
    } else if(suppressContextMenuThisFrame){
        contextMenuPending=false;
    }
    // Give the texture brush RMB popup the same charcoal/magenta visual language
    // as the Properties brush controls. Push before BeginPopup so the popup
    // window and every child control inherit the palette.
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding,5.0f*s);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding,3.0f*s);
    ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding,5.0f*s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(12.0f*s,10.0f*s));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing,ImVec2(7.0f*s,6.0f*s));
    ImGui::PushStyleColor(ImGuiCol_PopupBg,IM_COL32(18,19,25,250));
    ImGui::PushStyleColor(ImGuiCol_Border,IM_COL32(104,57,91,235));
    ImGui::PushStyleColor(ImGuiCol_Text,IM_COL32(235,232,241,255));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled,IM_COL32(151,145,160,255));
    ImGui::PushStyleColor(ImGuiCol_Separator,IM_COL32(91,48,78,220));
    ImGui::PushStyleColor(ImGuiCol_FrameBg,IM_COL32(31,32,41,255));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered,IM_COL32(55,39,58,255));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive,IM_COL32(72,43,70,255));
    ImGui::PushStyleColor(ImGuiCol_SliderGrab,IM_COL32(174,77,145,255));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive,IM_COL32(225,111,190,255));
    ImGui::PushStyleColor(ImGuiCol_CheckMark,IM_COL32(225,111,190,255));
    ImGui::PushStyleColor(ImGuiCol_Header,IM_COL32(54,35,57,255));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,IM_COL32(79,45,76,255));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive,IM_COL32(96,49,88,255));
    ImGui::SetNextWindowSize(ImVec2(340.0f*s,0.0f),ImGuiCond_Appearing);
    const bool textureContextPopupBegun=ImGui::BeginPopup("texture_context");
    if(textureContextPopupBegun){
        const bool emissive=textureDisplayKind==6;
        ImGui::TextUnformatted(uiText(languageRussian,"Texture Tool","Инструмент текстурирования"));
        ImGui::Separator();
        const char* toolName=textureToolMode==4?"Path":(textureToolMode==1?"Fill":(textureToolMode==2?"Gradient":(textureBrushType==1?"Eraser":(textureBrushType==2?"Smudge":(textureBrushType==3?"Blur":(textureBrushType==4?"Clone":"Brush"))))));
        ImGui::TextDisabled("%s",toolName);
        ImGui::Separator();
        auto contextBrushSlider=[&](const char* id,const char* en,const char* ru,float* value,float lo,float hi,const char* fmt){
            ImGui::AlignTextToFramePadding();ImGui::TextDisabled("%s",uiText(languageRussian,en,ru));
            ImGui::SameLine(122.0f*s);ImGui::SetNextItemWidth(210.0f*s);
            ImGui::SliderFloat(id,value,lo,hi,fmt);
        };
        if(textureToolMode==0){
            const bool hasBrushColors=(textureDisplayKind==1||textureDisplayKind==6)&&textureBrushType!=1&&textureBrushType!=2&&textureBrushType!=3&&textureBrushType!=4;
            const bool hasBrushShape=textureBrushType!=2&&textureBrushType!=3;
            float* colors=emissive?textureEmissiveBrushColors[0]:textureBrushColors[0];
            float* colorsB=emissive?textureEmissiveBrushColors[1]:textureBrushColors[1];
            // Keep the context-menu brush row aligned with the Properties layout:
            // color swatches first, then the shape picker on the same baseline.
            if(hasBrushColors){
                ImGui::PushID("texture_context_colors");
                for(int ci=0;ci<2;++ci){
                    if(ci)ImGui::SameLine(0.0f,5.0f*s);
                    float* col=ci?colorsB:colors;
                    ImGui::PushID(ci);
                    if(ImGui::ColorButton("##color",ImVec4(col[0],col[1],col[2],col[3]),ImGuiColorEditFlags_NoTooltip,ImVec2(38.0f*s,34.0f*s))){
                        if(emissive)textureEmissiveBrushColorIndex=ci;else textureBrushColorIndex=ci;
                        ImGui::OpenPopup("color_picker");
                    }
                    if(ImGui::BeginPopup("color_picker")){
                        ImGui::ColorPicker4("##picker",col,ImGuiColorEditFlags_NoLabel|ImGuiColorEditFlags_NoSidePreview);
                        ImGui::EndPopup();
                    }
                    ImGui::PopID();
                }
                ImGui::PopID();
            }
            if(hasBrushShape){
                if(hasBrushColors)ImGui::SameLine(0.0f,8.0f*s);
                const ImVec2 shapeButtonSize(42.0f*s,34.0f*s);
                if(ImGui::InvisibleButton("##context_brush_shape_button",shapeButtonSize)){
                    textureBrushShapePickerPending=true;
                    textureBrushShapePickerPopupPosition=io.MousePos;
                    textureBrushShapePickerPopupPositionValid=true;
                    ImGui::CloseCurrentPopup();
                }
                const ImVec2 shapeMin=ImGui::GetItemRectMin(),shapeMax=ImGui::GetItemRectMax();
                ImDrawList* shapeDraw=ImGui::GetWindowDrawList();
                const bool shapeHovered=ImGui::IsItemHovered();
                shapeDraw->AddRectFilled(shapeMin,shapeMax,shapeHovered?IM_COL32(55,39,58,255):IM_COL32(31,32,41,255),4.0f*s);
                shapeDraw->AddRect(shapeMin,shapeMax,shapeHovered?KURO_ACCENT:KURO_BORDER,4.0f*s,1.0f*s);
                kuroDrawBrushShapeIcon(shapeDraw,{(shapeMin.x+shapeMax.x)*0.5f,(shapeMin.y+shapeMax.y)*0.5f},11.0f*s,textureBrushShape,KURO_TEXT,s);
                if(textureBrushShape==1002)kuroDrawRainbowBrushRing(shapeDraw,{(shapeMin.x+shapeMax.x)*0.5f,(shapeMin.y+shapeMax.y)*0.5f},14.0f*s,1.6f*s);
                ImGui::SameLine();ImGui::TextDisabled("%s",textureBrushShape==1000?textureCustomBrushName.c_str():(textureBrushShape==1001?textureAnimatedBrushName.c_str():kuroBrushShapeName(textureBrushShape,languageRussian)));
                if(shapeHovered)ImGui::SetTooltip("%s",uiText(languageRussian,"Brush shape picker","Выбор формы кисти"));
            }
            // Shape-specific options (invert, rotation, follow direction and
            // Rainbow controls) intentionally live only in the shared shape
            // picker settings popup, not in this general brush menu.
            if(hasBrushColors||hasBrushShape)ImGui::Separator();
        }
        if(textureToolMode==0 || textureToolMode==1 || textureToolMode==2){
            float& size=emissive?textureEmissiveBrushSize:textureBrushSize;
            float& strength=emissive?textureEmissiveBrushStrength:textureBrushStrength;
            contextBrushSlider("##context_brush_size","Size","Размер",&size,1.0f,256.0f,"%.0f px");
            contextBrushSlider("##context_brush_strength","Strength","Сила",&strength,0.01f,1.0f,"%.0f%%");
        }
        if(textureToolMode==0){
            contextBrushSlider("##context_brush_spacing","Spacing","Шаг",&textureBrushSpacing,1.0f,1000.0f,"%.0f%%");
            do { const char* modeName=textureBrushAccumulate==0?uiText(languageRussian,"Off","Выкл."):(textureBrushAccumulate==1?uiText(languageRussian,"On","Вкл."):uiText(languageRussian,"Self-overlap","Самопересечение")); ImGui::SetNextItemWidth(-1.0f); if(ImGui::BeginCombo("##brush_accumulation_mode",modeName)){ const char* labels[3]={uiText(languageRussian,"Off","Выкл."),uiText(languageRussian,"On","Вкл."),uiText(languageRussian,"Self-overlap","Самопересечение")}; const char* hints[3]={uiText(languageRussian,"Do not build up within one stroke","Не усиливать внутри одного мазка"),uiText(languageRussian,"Every brush dab builds up","Каждый отпечаток усиливает цвет"),uiText(languageRussian,"Build up only when the stroke retraces itself","Усиливать только при возвращении на свой след")}; for(int mode=0;mode<3;++mode){ImGui::PushID(mode);if(ImGui::Selectable(labels[mode],textureBrushAccumulate==mode))textureBrushAccumulate=mode;if(ImGui::IsItemHovered())ImGui::SetTooltip("%s",hints[mode]);ImGui::PopID();}ImGui::EndCombo();} } while(false);
            contextBrushSlider("##context_brush_softness","Softness","Мягкость",&textureBrushSoftness,0.0f,1.0f,"%.0f%%");
            if(textureBrushType<=1||textureBrushType==4){
                ImGui::Checkbox(uiText(languageRussian,"Straight line (hold Shift)","Прямая линия (удерживать Shift)"),&textureShiftLineEnabled);
                ImGui::Indent(14.0f*s);ImGui::Checkbox(uiText(languageRussian,"Alt: snap to 45°","Alt: шаг 45°"),&textureShiftLineAltSnapEnabled);ImGui::Unindent(14.0f*s);
            }
            if(textureBrushType==4){
                ImGui::TextDisabled("%s",textureCloneSourceValid?uiText(languageRussian,"Clone source is set","Источник клонирования задан"):uiText(languageRussian,"Clone source is not set","Источник клонирования не задан"));
                if(ImGui::Button(uiText(languageRussian,"Reset clone source","Сбросить источник клонирования"),ImVec2(-1.0f,24.0f*s))){textureCloneSourceValid=false;textureCloneSourceWorldValid=false;textureCloneAnchorValid=false;textureCloneTransportValid=false;textureCloneTransportTriangle=SIZE_MAX;textureCloneSourceObjectId=-1;}
            }
            ImGui::Separator();
            const bool contextLagWasEnabled=textureBrushLagEnabled;
            ImGui::Checkbox(uiText(languageRussian,"Brush lag","Сглаживание кисти"),&textureBrushLagEnabled);
            if(contextLagWasEnabled!=textureBrushLagEnabled){textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;}
            if(textureBrushLagEnabled)contextBrushSlider("##context_brush_lag","Lag amount","Сила сглаживания",&textureBrushLagAmount,0.50f,0.97f,"%.2f");
            if(ImGui::Button(uiText(languageRussian,"Reset brush settings","Сбросить настройки кисти"),ImVec2(-1.0f,25.0f*s))){
                float& activeSize=emissive?textureEmissiveBrushSize:textureBrushSize;
                float& activeStrength=emissive?textureEmissiveBrushStrength:textureBrushStrength;
                activeSize=32.0f;activeStrength=1.0f;textureBrushSpacing=18.0f;textureBrushSoftness=0.0f;textureBrushAccumulate=1;
                textureBrushLagAmount=0.88f;textureBrushLagViewportValid=false;textureBrushLagCanvasValid=false;
            }
        }else if(textureToolMode==4){
            ImGui::TextUnformatted(uiText(languageRussian,"Path Settings","Настройки Path"));
            ImGui::SetNextItemWidth(210.0f*s);ImGui::SliderFloat(uiText(languageRussian,"Size","Размер"),&texturePathSize,1.0f,128.0f,"%.0f px");
            ImGui::SetNextItemWidth(210.0f*s);ImGui::SliderFloat(uiText(languageRussian,"Strength","Сила"),&texturePathStrength,0.01f,1.0f,"%.0f%%");
            ImGui::Checkbox(uiText(languageRussian,"Curved Path","Кривая линия"),&texturePathCurved);
            ImGui::Checkbox(uiText(languageRussian,"Closed Path","Замкнутый путь"),&texturePathClosed);
            if(ImGui::MenuItem(uiText(languageRussian,"Clear Path","Очистить Path"),nullptr,false,!texturePathPoints.empty())){texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathSelectedPoint=-1;texturePathClosed=false;texturePathDraggingPoint=false;texturePathRasterHash=0;}
        }else if(textureToolMode==2){
            ImGui::TextDisabled(uiText(languageRussian,"Gradient options are available in the tool settings.","Параметры градиента доступны в настройках инструмента."));
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleColor(14);
    ImGui::PopStyleVar(5);
    const bool uvContextPopupBegun=ImGui::BeginPopup("uv_context");
    if(uvContextPopupBegun){
        Object* uvContextObject=scene.selected();
        ImGui::TextUnformatted(uiText(languageRussian,"UV Editing","Редактирование UV"));
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Select All UVs (A)","Выделить все UV (A)"))){
            uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();
            if(uvContextObject)for(int ci=0;ci<(int)uvContextObject->mesh.faceCornerUV.size();++ci)uvSelectedCorners.push_back(ci);
            setStatus("UV: Select All");
        }
        if(ImGui::MenuItem(uiText(languageRussian,"Deselect All (Alt+A)","Снять выделение (Alt+A)"))){uvSelectedCorners.clear();uvSelectedEdges.clear();uvSelectedFaces.clear();uvActiveCorner=-1;setStatus("UV: deselect all");}
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Auto Unwrap","Авторазвёртка"),nullptr,false,uvContextObject!=nullptr)){autoUnwrapSelected();setStatus("UV: Auto UV");}
        if(ImGui::MenuItem(uiText(languageRussian,"Unwrap by Seams","Развёртка по швам"),nullptr,false,uvContextObject!=nullptr)){unwrapByMarkedSeamsSelected();setStatus("UV: Unwrap by seams");}
        if(ImGui::MenuItem(uiText(languageRussian,"From View","Из вида"),nullptr,false,uvContextObject!=nullptr)){projectUVSelected(0);}
        if(ImGui::MenuItem(uiText(languageRussian,"Box Projection","Кубическая проекция"),nullptr,false,uvContextObject!=nullptr)){projectUVSelected(1);}
        if(ImGui::MenuItem(uiText(languageRussian,"Cylindrical Projection","Цилиндрическая проекция"),nullptr,false,uvContextObject!=nullptr)){projectUVSelected(2);}
        if(ImGui::MenuItem(uiText(languageRussian,"Spherical Projection","Сферическая проекция"),nullptr,false,uvContextObject!=nullptr)){projectUVSelected(3);}
        if(ImGui::MenuItem(uiText(languageRussian,"Mark Seam","Пометить шов"),nullptr,false,uvContextObject!=nullptr)){markUVSeamsFromSelection(false);setStatus("UV: seam marked");}
        if(ImGui::MenuItem(uiText(languageRussian,"Clear Seams","Снять швы"),nullptr,false,uvContextObject!=nullptr)){markUVSeamsFromSelection(true);setStatus("UV: seams cleared");}
        ImGui::EndPopup();
    }
    const bool componentContextPopupBegun=ImGui::BeginPopup("component_context");
    if(componentContextPopupBegun){
        auto*co=scene.selected();
        if(co&&editMode&&mode!=SelectionMode::Object){
            const char*kind=mode==SelectionMode::Vertex?"Vertices":mode==SelectionMode::Edge?"Edges":"Faces";
            ImGui::Text("%s",kind);ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Dissolve","Растворить")))dissolveSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Subdivide…","Подразделить…")))subdividePopupPending=true;
            if(mode==SelectionMode::Face){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangles to Quads","Из треугольников в квадраты")))trianglesToQuadsSelected();
                if(ImGui::MenuItem(uiText(languageRussian,"Triangulate Faces","Триангулировать")))triangulateSelectedFaces();
                if(ImGui::MenuItem(uiText(languageRussian,"Poke Faces","Poke Faces")))pokeSelectedFaces();
            }
            if(mode==SelectionMode::Vertex){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Shrink/Fatten (Alt+S)","Shrink/Fatten (Alt+S)")))pendingComponentTransform=4;
                if(ImGui::MenuItem(uiText(languageRussian,"To Sphere (Shift+Alt+S)","To Sphere (Shift+Alt+S)")))pendingComponentTransform=5;
            }
            if(mode!=SelectionMode::Face&&ImGui::MenuItem(uiText(languageRussian,"Fill (F)","Fill (F)")))fillSelected();
            if(mode==SelectionMode::Edge){
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Seam","Пометить шов")))markUVSeamsFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Seam","Снять шов")))markUVSeamsFromSelection(true);
                ImGui::Separator();
                if(ImGui::MenuItem(uiText(languageRussian,"Mark Sharp","Пометить острые рёбра")))markSharpEdgesFromSelection(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Clear Sharp","Снять пометку острых рёбер")))markSharpEdgesFromSelection(true);
            }
            ImGui::Separator();
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            if(ImGui::MenuItem(uiText(languageRussian,"Set Normal Direction...","Направление нормалей...")))normalDirectionPopupPending=true;
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Merge (M)","Merge (M)"))){
                if(favoriteMenuItem("At Center","At Center",1000))mergeSelected(0);
                if(favoriteMenuItem("At Cursor","At 3D Cursor",1001))mergeSelected(1);
                if(favoriteMenuItem("Collapse","Collapse",1002))mergeSelected(2);
                if(favoriteMenuItem("At First","At First",1003))mergeSelected(3);
                if(favoriteMenuItem("At Last","At Last",1004))mergeSelected(5);
                if(favoriteMenuItem("By Distance","By Distance",1005))mergeSelected(4);
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Separate (P)","Separate (P)"))){
                if(favoriteMenuItem("Selection","Selection",1100))separateSelected(0);
                if(favoriteMenuItem("By Material","By Material",1101))separateSelected(1);
                if(favoriteMenuItem("By Loose Parts","By Loose Parts",1102))separateSelected(2);
                ImGui::EndMenu();
            }
        }
        ImGui::EndPopup();
    }
    // Open the Subdivide options only after the component context popup has
    // finished. Opening a second popup from inside the first one was unreliable
    // with the viewport input capture and made the item appear to do nothing.
    if(subdividePopupPending){
        subdivideCuts=1;
        beginSubdividePreview();
        ImGui::OpenPopup("subdivide_options");
        subdividePopupPending=false;
    }
    bool subdividePopupOpen=ImGui::BeginPopup("subdivide_options");
    if(subdividePopupOpen){
        subdividePreviewPopupSeen=true;
        ImGui::TextUnformatted(uiText(languageRussian,"Subdivide","Подразделить"));
        ImGui::Separator();
        ImGui::TextUnformatted(uiText(languageRussian,"Number of Cuts","Количество разрезов"));
        int oldCuts=subdivideCuts;
        ImGui::BeginGroup();
        if(ImGui::ArrowButton("##subdivide_cuts_down",ImGuiDir_Left))subdivideCuts=std::max(1,subdivideCuts-1);
        ImGui::SameLine(0,4);
        ImGui::SetNextItemWidth(150.0f);
        ImGui::DragInt("##subdivide_cuts",&subdivideCuts,1.0f,1,32,"%d");
        ImGui::SameLine(0,4);
        if(ImGui::ArrowButton("##subdivide_cuts_up",ImGuiDir_Right))subdivideCuts=std::min(32,subdivideCuts+1);
        ImGui::EndGroup();
        subdivideCuts=std::clamp(subdivideCuts,1,32);
        if(subdivideCuts!=oldCuts)updateSubdividePreview(subdivideCuts);
        ImGui::TextDisabled(uiText(languageRussian,"Drag or use the arrows; changes are applied immediately.","Drag or use the arrows; changes are applied immediately."));
        ImGui::EndPopup();
    }
    if(subdividePreviewActive && subdividePreviewPopupSeen && !ImGui::IsPopupOpen("subdivide_options"))
        finishSubdividePreview();
    if(ImGui::BeginPopup("rig_bone_context")){
        const RigSkeleton* rig=scene.selected()&&scene.selected()->rigSkeleton?scene.selected()->rigSkeleton.get():nullptr;
        const char* boneName=(rig&&poseBoneIndex>=0&&size_t(poseBoneIndex)<rig->nodes.size())?rig->nodes[size_t(poseBoneIndex)].name.c_str():"Bone";
        ImGui::Text("Bone: %s",boneName);ImGui::Separator();
        if(rigSelectedBones.size()>1){if(ImGui::MenuItem(uiText(languageRussian,"Make Active Bone Parent","Сделать активную кость родителем"),"Ctrl+P"))rigMakeParentSelectionRequested=true;}
        else if(ImGui::MenuItem(uiText(languageRussian,"Make Parent...","Назначить родителя..."),"Ctrl+P")){rigParentPopupChild=poseBoneIndex;rigParentPopupRequested=true;}
        if(ImGui::MenuItem(uiText(languageRussian,"Clear Parent","Убрать родителя"),"Alt+P"))rigClearParentSelectionRequested=true;
        ImGui::Separator();
        if(ImGui::MenuItem(uiText(languageRussian,"Select Only This Bone","Выбрать только эту кость"))){rigSelectedBones.clear();if(poseBoneIndex>=0)rigSelectedBones.push_back(poseBoneIndex);}
        if(ImGui::MenuItem(uiText(languageRussian,"Clear Bone Selection","Снять выделение костей"))){rigSelectedBones.clear();poseBoneIndex=-1;}
        ImGui::EndPopup();
    }
    if(rigParentPopupRequested){ImGui::OpenPopup("rig_parent_picker");rigParentPopupRequested=false;}
    if(ImGui::BeginPopup("rig_parent_picker")){
        Object* rigObject=scene.selected();const int child=rigParentPopupChild;
        if(rigObject&&rigObject->rigSkeleton&&child>=0&&size_t(child)<rigObject->rigSkeleton->nodes.size()&&rigObject->rigSkeleton->nodes[size_t(child)].isBone){
            ImGui::TextUnformatted("Choose parent bone");ImGui::Separator();
            auto setParent=[&](int parent){if(rigObject->rigSkeletonRef<0||size_t(rigObject->rigSkeletonRef)>=scene.rigSkeletons.size())return;auto edited=std::make_shared<RigSkeleton>(*rigObject->rigSkeleton);auto clips=scene.animations;if(!rigReparentPreserveAnimation(*edited,clips,rigObject->rigSkeletonRef,uint32_t(child),parent)){setStatus("Parent change rejected: cycle, unsupported scale or invalid transform");return;}if(rigObject->rigSkeleton->nodes[size_t(child)].parent==parent)return;pushUndoState();scene.animations=std::move(clips);rigObject->rigSkeleton=edited;scene.rigSkeletons[size_t(rigObject->rigSkeletonRef)]=edited;for(auto& other:scene.objects)if(other.rigSkeletonRef==rigObject->rigSkeletonRef)other.rigSkeleton=edited;projectDirty=true;++rigPoseRevision;setStatus(parent<0?"Bone parent cleared":"Bone parent updated");};
            if(ImGui::MenuItem("(Root)"))setParent(-1);
            for(size_t pi=0;pi<rigObject->rigSkeleton->nodes.size();++pi)if(rigObject->rigSkeleton->nodes[pi].isBone&&int(pi)!=child)if(ImGui::MenuItem(rigObject->rigSkeleton->nodes[pi].name.c_str()))setParent(int(pi));
        }else ImGui::TextDisabled("No active bone");
        ImGui::EndPopup();
    }
    const bool objectContextPopupBegun=ImGui::BeginPopup("object_context");
    if(objectContextPopupBegun){
        auto*co=scene.selected();
        if(co){
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co->name.c_str());ImGui::Separator();
            if(co->imageReference){
                ImGui::TextDisabled(uiText(languageRussian,"Image Reference — transform only","Image Reference — только трансформации"));
                if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){int oi=scene.selectedIndex();if(oi>=0)openRenameObject(oi);}
                if(ImGui::MenuItem(uiText(languageRussian,"Delete Reference","Удалить референс")))deleteSelected();
            }else{
            if(textureMode&&textureToolMode==4){
                if(ImGui::BeginMenu("Path")){
                    const bool hasPoints=!texturePathPoints.empty();
                    if(ImGui::MenuItem(uiText(languageRussian,"Delete selected point (Ctrl+Click)","Удалить выбранную точку (Ctrl+клик)"),nullptr,false,texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size())){
                        const size_t pi=(size_t)texturePathSelectedPoint;texturePathPoints.erase(texturePathPoints.begin()+pi);if(pi<texturePathWorldPoints.size())texturePathWorldPoints.erase(texturePathWorldPoints.begin()+pi);if(pi<texturePathWorldPointValid.size())texturePathWorldPointValid.erase(texturePathWorldPointValid.begin()+pi);texturePathSelectedPoint=-1;texturePathDraggingPoint=false;texturePathRasterHash=0;
                    }
                    if(ImGui::MenuItem(uiText(languageRussian,"Break connection at selected point (V)","Разомкнуть соединение у выбранной точки (V)"),nullptr,false,texturePathSelectedPoint>=0&&texturePathSelectedPoint<(int)texturePathPoints.size())){
                        if(texturePathClosed&&texturePathPoints.size()>2){texturePathClosed=false;texturePathRasterHash=0;setStatus("Path closure removed at selected point");}else setStatus("Path is already open; select a closed endpoint to break the connection");
                    }
                    ImGui::Separator();
                    if(ImGui::MenuItem(texturePathCurved?uiText(languageRussian,"Use straight segments","Использовать прямые сегменты"):uiText(languageRussian,"Use curved path","Использовать кривую линию")))texturePathCurved=!texturePathCurved;
                    if(ImGui::MenuItem(texturePathClosed?uiText(languageRussian,"Open path","Разомкнуть путь"):uiText(languageRussian,"Close path","Замкнуть путь"),nullptr,false,texturePathPoints.size()>2))texturePathClosed=!texturePathClosed;
                    if(ImGui::MenuItem(texturePathVisible?uiText(languageRussian,"Hide Path","Скрыть Path"):uiText(languageRussian,"Show Path","Показать Path")))texturePathVisible=!texturePathVisible;
                    if(ImGui::MenuItem(uiText(languageRussian,"Clear Path","Очистить Path"),nullptr,false,hasPoints)){texturePathPoints.clear();texturePathWorldPoints.clear();texturePathWorldPointValid.clear();texturePathSelectedPoint=-1;texturePathClosed=false;texturePathDraggingPoint=false;texturePathRasterHash=0;}
                    ImGui::EndMenu();
                }
                ImGui::Separator();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){int oi=scene.selectedIndex();if(oi>=0)openRenameObject(oi);}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить")))deleteSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать")))duplicateSelected();
            if(ImGui::MenuItem(uiText(languageRussian,"Join (Ctrl+J)","Join (Ctrl+J)")))joinSelectedObjects();
            if(ImGui::BeginMenu(uiText(languageRussian,"Origin","Origin"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to Geometry","Origin к геометрии"))){originToGeometry();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Geometry to Origin","Геометрия к Origin"))){geometryToOrigin();ImGui::CloseCurrentPopup();}
                if(ImGui::MenuItem(uiText(languageRussian,"Origin to World","Origin в мир (0,0,0)"))){originToWorld();ImGui::CloseCurrentPopup();}
                ImGui::EndMenu();
            }
            if(co->groupId>=0&&ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы")))removeSelectedFromGroup();
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str()))addSelectedToGroup(gg.id);if(scene.groups.empty())ImGui::TextDisabled("No groups");ImGui::EndMenu();}
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного")))createGroupFromSelected("Group");
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){setObjectSmoothShading(*co,false);}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){setObjectSmoothShading(*co,true);}
            if(ImGui::BeginMenu(uiText(languageRussian,"Auto Smooth","Автосглаживание"))){
                const float angles[]={30.0f,45.0f,60.0f,90.0f};
                const char* en[]={"30°","45°","60°","90°"};
                const char* ru[]={"30°","45°","60°","90°"};
                for(int ai=0;ai<4;++ai){
                    if(ImGui::MenuItem(uiText(languageRussian,en[ai],ru[ai]))){setObjectAutoSmooth(*co,angles[ai]);}
                }
                ImGui::EndMenu();
            }
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            if(ImGui::MenuItem(uiText(languageRussian,"Set Normal Direction...","Направление нормалей...")))normalDirectionPopupPending=true;
                ImGui::EndMenu();
            }
            }
            }
        ImGui::EndPopup();
    }
    if(outlinerContextPending){ImGui::OpenPopup("outliner_object_context");outlinerContextPending=false;}
    if(ImGui::BeginPopup("outliner_object_context")){
        int oi=outlinerContextIndex;
        if(oi>=0&&oi<(int)scene.objects.size()){
            auto &co=scene.objects[oi];
            ImGui::Text("%s: %s",uiText(languageRussian,"Object","Объект"),co.name.c_str()); ImGui::Separator();
            if(co.imageReference){
                ImGui::TextDisabled(uiText(languageRussian,"Image Reference — transform only","Image Reference — только трансформации"));
                if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){openRenameObject(oi);outlinerContextIndex=-1;}
                if(ImGui::MenuItem(uiText(languageRussian,"Delete Reference","Удалить референс"))){deleteSelected();outlinerContextIndex=-1;}
            }else{
            if(ImGui::MenuItem(uiText(languageRussian,"Rename","Переименовать"))){openRenameObject(oi);outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Delete","Удалить"))){deleteSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Duplicate","Дублировать"))){duplicateSelected();outlinerContextIndex=-1;}
            if(ImGui::MenuItem(co.hidden?"Show":"Hide")){pushUndoState();co.hidden=!co.hidden;if(co.hidden){co.selected=false;if(editMode){editMode=false;mode=SelectionMode::Object;}}setStatus(co.hidden?"Object hidden":"Object shown");outlinerContextIndex=-1;}
            if(co.groupId>=0){if(ImGui::MenuItem(uiText(languageRussian,"Remove from Group","Убрать из группы"))){removeSelectedFromGroup();outlinerContextIndex=-1;}}
            if(ImGui::BeginMenu(uiText(languageRussian,"Add to Group","Добавить в группу"))){
                for(auto &gg:scene.groups)if(ImGui::MenuItem(gg.name.c_str())){addSelectedToGroup(gg.id);outlinerContextIndex=-1;ImGui::CloseCurrentPopup();}
                if(scene.groups.empty())ImGui::TextDisabled("No groups");
                ImGui::EndMenu();
            }
            if(ImGui::MenuItem(uiText(languageRussian,"Create Group from Selected","Создать группу из выбранного"))){createGroupFromSelected("Group");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Hide Others","Скрыть остальные"))){pushUndoState();for(int j=0;j<(int)scene.objects.size();++j)if(j!=oi)scene.objects[j].hidden=true;co.hidden=false;scene.clearSelection();co.selected=true;setStatus("Other objects hidden");outlinerContextIndex=-1;}
            if(ImGui::MenuItem(uiText(languageRussian,"Show All","Показать всё"))){for(auto &x:scene.objects)x.hidden=false;setStatus("All objects shown");outlinerContextIndex=-1;}
            ImGui::Separator();
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Flat","Плоское затенение"))){setObjectSmoothShading(co,false);}
            if(ImGui::MenuItem(uiText(languageRussian,"Shade Smooth","Сглаженное затенение"))){setObjectSmoothShading(co,true);}
            if(ImGui::BeginMenu(uiText(languageRussian,"Normals","Нормали"))){
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Outside (Shift+N)","Recalculate Outside (Shift+N)")))recalculateNormals(false);
                if(ImGui::MenuItem(uiText(languageRussian,"Recalculate Inside (Ctrl+Shift+N)","Recalculate Inside (Ctrl+Shift+N)")))recalculateNormals(true);
                if(ImGui::MenuItem(uiText(languageRussian,"Flip","Перевернуть")))flipNormals();
            if(ImGui::MenuItem(uiText(languageRussian,"Set Normal Direction...","Направление нормалей...")))normalDirectionPopupPending=true;
                ImGui::EndMenu();
            }
            }
        }
        ImGui::EndPopup();
    }

